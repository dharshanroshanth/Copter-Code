/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

// Lazy initialize Gemini Client to prevent startup crashes if key is missing initially
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware configurations
  app.use(express.json({ limit: '20mb' }));

  // API Route: Analyze image with Google Gemini
  app.post('/api/analyze-image', async (req, res) => {
    try {
      const { mimeType, base64Data } = req.body;
      if (!mimeType || !base64Data) {
        return res.status(400).json({ error: 'Missing mimeType or base64Data representation.' });
      }

      const client = getAiClient();
      
      const response = await client.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType,
            },
          },
          {
            text: 'Analyze this photo. Provide a 2-sentence descriptive analysis of its subject and aesthetic. Suggest 3 fitting creative title options. Recommend baseline optimal filter sliders. Also, generate high-quality copywriter captions for Instagram, LinkedIn, and a minimalist poetic style. Generate 3 interesting stylized text overlay ideas that would look amazing positioned on the image. Finally, generate 3 specific alternative mood filters tailored for this photo (e.g. "Warm Vintage", "Moody Cinematic", "Neon Cyberpunk") with precise slider coordinates.',
          },
        ],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              description: {
                type: Type.STRING,
                description: 'A brief 2-sentence aesthetic and subject description.',
              },
              titleIdeas: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '3 fitting short creative title options.',
              },
              suggestedFilters: {
                type: Type.OBJECT,
                properties: {
                  brightness: { type: Type.INTEGER, description: 'Brightness from -40 to 40' },
                  contrast: { type: Type.INTEGER, description: 'Contrast from -40 to 40' },
                  saturation: { type: Type.INTEGER, description: 'Saturation from -40 to 40' },
                  tint: { type: Type.INTEGER, description: 'Tint (hue-rotate) from -180 to 180' },
                  blur: { type: Type.INTEGER, description: 'Blur from 0 to 100' },
                },
                required: ['brightness', 'contrast', 'saturation', 'tint', 'blur'],
              },
              colorPalette: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '5 hex code dominant color palette swatches.',
              },
              socialCaptions: {
                type: Type.OBJECT,
                properties: {
                  instagram: { type: Type.STRING, description: 'Engaging Instagram caption with emojis and hashtags' },
                  linkedin: { type: Type.STRING, description: 'Professional LinkedIn caption reflecting on theme/story' },
                  poetic: { type: Type.STRING, description: 'A short, artistic, minimalist poetic one-sentence caption' },
                },
                required: ['instagram', 'linkedin', 'poetic'],
              },
              overlayTextIdeas: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING, description: 'Brief catchy text snippet to overlay on photo' },
                    fontStyle: { type: Type.STRING, description: 'Must be either "sans", "mono", or "serif"' },
                    color: { type: Type.STRING, description: 'Suggested overlay text color hex code' },
                    fontSize: { type: Type.INTEGER, description: 'Suggested font size in px' },
                  },
                  required: ['text', 'fontStyle', 'color', 'fontSize'],
                },
                description: '3 text overlay suggestions.',
              },
              vibePresets: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: 'Vibe preset name (e.g., Moody Cinematic, Soft Pastel, Cyberpunk)' },
                    description: { type: Type.STRING, description: 'Brief description of the mood look' },
                    filters: {
                      type: Type.OBJECT,
                      properties: {
                        brightness: { type: Type.INTEGER },
                        contrast: { type: Type.INTEGER },
                        saturation: { type: Type.INTEGER },
                        tint: { type: Type.INTEGER },
                        blur: { type: Type.INTEGER },
                      },
                      required: ['brightness', 'contrast', 'saturation', 'tint', 'blur'],
                    },
                  },
                  required: ['name', 'description', 'filters'],
                },
                description: '3 customized artistic vibe mood presets.',
              },
            },
            required: ['description', 'titleIdeas', 'suggestedFilters', 'colorPalette', 'socialCaptions', 'overlayTextIdeas', 'vibePresets'],
          },
        },
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error('No content returned from AI analyzer.');
      }

      const parsedData = JSON.parse(responseText.trim());
      res.json(parsedData);
    } catch (error: any) {
      console.error('Gemini API Error:', error);
      res.status(500).json({ error: error?.message || 'Failed to analyze photo with Gemini.' });
    }
  });

  // Serve static assets or mount Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PhotoToolkit] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal Server Error:', err);
});

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Filters, TextLayer, ElementLayer } from '../types';

/**
 * Loads an image from a URL or Data URL.
 */
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Permanently bakes current adjustments, rotation, flips, text overlays, and elements onto the image.
 * Returns a high-res Data URL of the edited result.
 */
export async function processImageBake(
  dataUrl: string,
  filters: Filters,
  rotation: number,
  flipH: boolean,
  flipV: boolean,
  textLayers: TextLayer[],
  elementLayers: ElementLayer[],
  resizeWidth?: number,
  resizeHeight?: number,
  cropPercent?: { x: number; y: number; w: number; h: number }, // Optional cropping area in percentage (0-100)
  vignette?: number,
  grain?: number,
  // Creative Pro properties
  activeFrameId?: string,
  customBorderWidth?: number,
  customBorderColor?: string,
  customBorderRadius?: number,
  chromatic?: number,
  backgroundPadding?: number,
  backgroundColor?: string,
  backgroundIsGradient?: boolean
): Promise<{ dataUrl: string; width: number; height: number }> {
  const baseImg = await loadImage(dataUrl);

  // Determine base canvas dimensions
  let srcX = 0;
  let srcY = 0;
  let srcW = baseImg.naturalWidth;
  let srcH = baseImg.naturalHeight;

  if (cropPercent) {
    srcX = (cropPercent.x / 100) * baseImg.naturalWidth;
    srcY = (cropPercent.y / 100) * baseImg.naturalHeight;
    srcW = (cropPercent.w / 100) * baseImg.naturalWidth;
    srcH = (cropPercent.h / 100) * baseImg.naturalHeight;
  }

  // Handle final resize outputs if provided
  let finalW = resizeWidth || srcW;
  let finalH = resizeHeight || srcH;

  const isRotated90 = Math.abs(rotation) % 180 === 90;

  if (isRotated90) {
    // If the image is rotated 90 or 270 degrees, we always swap the canvas bounds
    // to match the rotated target aspect ratio.
    const temp = finalW;
    finalW = finalH;
    finalH = temp;
  }

  // Dynamic Scale factor to keep frame proportions correct on large/high-res exports
  const scaleFactor = Math.min(finalW, finalH) / 500;

  // Calculate borders/padding offsets
  let padTop = 0;
  let padBottom = 0;
  let padLeft = 0;
  let padRight = 0;

  const scaledPadding = (backgroundPadding || 0) * scaleFactor;

  if (activeFrameId) {
    if (activeFrameId === 'frame-polaroid') {
      const bw = (customBorderWidth || 16) * scaleFactor;
      padTop = padLeft = padRight = bw;
      padBottom = bw * 3.5;
    } else if (activeFrameId === 'frame-film') {
      const bw = (customBorderWidth || 12) * scaleFactor;
      padLeft = padRight = bw * 1.5;
      padTop = padBottom = bw;
    } else if (activeFrameId === 'frame-gold') {
      const bw = (customBorderWidth || 14) * scaleFactor;
      padTop = padBottom = padLeft = padRight = bw;
    } else if (activeFrameId === 'frame-wood') {
      const bw = (customBorderWidth || 18) * scaleFactor;
      padTop = padBottom = padLeft = padRight = bw;
    } else if (activeFrameId === 'frame-neon') {
      const bw = (customBorderWidth || 6) * scaleFactor;
      padTop = padBottom = padLeft = padRight = bw;
    } else if (activeFrameId === 'frame-none') {
      const bw = (customBorderWidth || 0) * scaleFactor;
      padTop = padBottom = padLeft = padRight = bw;
    }
  }

  // Define total output canvas dimensions
  const totalW = Math.round(finalW + padLeft + padRight + scaledPadding * 2);
  const totalH = Math.round(finalH + padTop + padBottom + scaledPadding * 2);

  const canvas = document.createElement('canvas');
  canvas.width = totalW;
  canvas.height = totalH;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not retrieve canvas context.');
  }

  // Draw background studio backdrop
  if (scaledPadding > 0) {
    ctx.save();
    const bgVal = backgroundColor || '#ffffff';
    if (bgVal.includes('linear-gradient')) {
      const hexMatches = bgVal.match(/#[0-9a-fA-F]{6}/g);
      if (hexMatches && hexMatches.length >= 2) {
        const grad = ctx.createLinearGradient(0, 0, totalW, totalH);
        grad.addColorStop(0, hexMatches[0]);
        grad.addColorStop(1, hexMatches[1]);
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = '#ffffff';
      }
    } else {
      ctx.fillStyle = bgVal;
    }
    ctx.fillRect(0, 0, totalW, totalH);
    ctx.restore();
  } else {
    // Transparent or white default fallback
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, totalW, totalH);
  }

  // Image insertion position bounds
  const imgX = scaledPadding + padLeft;
  const imgY = scaledPadding + padTop;

  const frameX = scaledPadding;
  const frameY = scaledPadding;
  const frameW = finalW + padLeft + padRight;
  const frameH = finalH + padTop + padBottom;

  // Render creative frame backdrop if selected
  if (activeFrameId && activeFrameId !== 'frame-none') {
    ctx.save();
    if (activeFrameId === 'frame-polaroid') {
      ctx.fillStyle = '#fdfbf7';
      ctx.fillRect(frameX, frameY, frameW, frameH);
      ctx.strokeStyle = '#e5e1d8';
      ctx.lineWidth = 1 * scaleFactor;
      ctx.strokeRect(frameX, frameY, frameW, frameH);
    } else if (activeFrameId === 'frame-film') {
      ctx.fillStyle = '#111827';
      ctx.fillRect(frameX, frameY, frameW, frameH);
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 2 * scaleFactor;
      ctx.strokeRect(frameX, frameY, frameW, frameH);
    }
    ctx.restore();
  }

  // Configure CSS filters for image layer (including Chromatic Aberration drop-shadow simulation)
  const filterString = `
    brightness(${1 + filters.brightness / 100})
    contrast(${1 + filters.contrast / 100})
    saturate(${1 + filters.saturation / 100})
    hue-rotate(${filters.tint}deg)
    blur(${filters.blur * 0.15}px)
    ${chromatic && chromatic > 0 ? `drop-shadow(${chromatic * 0.1 * scaleFactor}px 0px 0px rgba(239, 68, 68, 0.45)) drop-shadow(${-chromatic * 0.1 * scaleFactor}px 0px 0px rgba(6, 182, 212, 0.45))` : ''}
  `;
  ctx.filter = filterString;

  // Handle Rotation and Mirror Flips around image center
  ctx.save();
  const imgCenterX = imgX + finalW / 2;
  const imgCenterY = imgY + finalH / 2;
  ctx.translate(imgCenterX, imgCenterY);
  ctx.rotate((rotation * Math.PI) / 180);
  ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);

  // Draw image
  const drawW = isRotated90 ? finalH : finalW;
  const drawH = isRotated90 ? finalW : finalH;

  ctx.drawImage(
    baseImg,
    srcX,
    srcY,
    srcW,
    srcH,
    -drawW / 2,
    -drawH / 2,
    drawW,
    drawH
  );
  ctx.restore();

  // Reset filter for vector elements/decorations
  ctx.filter = 'none';

  // Draw custom frame overlay borders/decorations
  if (activeFrameId) {
    ctx.save();
    if (activeFrameId === 'frame-polaroid') {
      // Bottom polaroid caption text
      ctx.fillStyle = 'rgba(100, 116, 139, 0.85)';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `bold ${Math.max(12, 10 * scaleFactor)}px Georgia, serif`;
      ctx.fillText(
        '✨ CAPTURED MOMENT ✨',
        frameX + frameW / 2,
        frameY + frameH - (padBottom / 2.2)
      );
    } else if (activeFrameId === 'frame-film') {
      // Film sprocket holes
      ctx.fillStyle = '#030712';
      const holeW = 1.5 * scaleFactor;
      const holeH = 3.5 * scaleFactor;
      const holeCount = 6;
      for (let i = 0; i < holeCount; i++) {
        const offsetFactor = (i + 0.5) / holeCount;
        ctx.fillRect(
          frameX + 1 * scaleFactor,
          frameY + offsetFactor * frameH - holeH / 2,
          holeW,
          holeH
        );
        ctx.fillRect(
          frameX + frameW - 1 * scaleFactor - holeW,
          frameY + offsetFactor * frameH - holeH / 2,
          holeW,
          holeH
        );
      }
      // Bottom camera metadata text
      ctx.fillStyle = 'rgba(156, 163, 175, 0.75)';
      ctx.font = `bold ${Math.max(8, 7 * scaleFactor)}px monospace`;
      ctx.textAlign = 'left';
      ctx.fillText('ISO 100', frameX + padLeft + 4 * scaleFactor, frameY + frameH - 5 * scaleFactor);
      ctx.textAlign = 'right';
      ctx.fillText('TIME 07_07_2026', frameX + frameW - padRight - 4 * scaleFactor, frameY + frameH - 5 * scaleFactor);
    } else if (activeFrameId === 'frame-gold') {
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = (customBorderWidth || 14) * scaleFactor;
      ctx.strokeRect(frameX + ctx.lineWidth / 2, frameY + ctx.lineWidth / 2, frameW - ctx.lineWidth, frameH - ctx.lineWidth);
      
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1 * scaleFactor;
      ctx.strokeRect(frameX + 2 * scaleFactor, frameY + 2 * scaleFactor, frameW - 4 * scaleFactor, frameH - 4 * scaleFactor);
    } else if (activeFrameId === 'frame-wood') {
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = (customBorderWidth || 18) * scaleFactor;
      ctx.strokeRect(frameX + ctx.lineWidth / 2, frameY + ctx.lineWidth / 2, frameW - ctx.lineWidth, frameH - ctx.lineWidth);
    } else if (activeFrameId === 'frame-neon') {
      ctx.strokeStyle = '#ec4899';
      ctx.lineWidth = (customBorderWidth || 6) * scaleFactor;
      ctx.shadowColor = '#ec4899';
      ctx.shadowBlur = 15 * scaleFactor;
      ctx.strokeRect(frameX + ctx.lineWidth / 2, frameY + ctx.lineWidth / 2, frameW - ctx.lineWidth, frameH - ctx.lineWidth);
    } else if (activeFrameId === 'frame-none' && customBorderWidth && customBorderWidth > 0) {
      ctx.strokeStyle = customBorderColor || '#ffffff';
      ctx.lineWidth = customBorderWidth * scaleFactor;
      if (customBorderRadius && customBorderRadius > 0) {
        const r = customBorderRadius * scaleFactor;
        ctx.beginPath();
        ctx.roundRect(frameX + ctx.lineWidth / 2, frameY + ctx.lineWidth / 2, frameW - ctx.lineWidth, frameH - ctx.lineWidth, r);
        ctx.stroke();
      } else {
        ctx.strokeRect(frameX + ctx.lineWidth / 2, frameY + ctx.lineWidth / 2, frameW - ctx.lineWidth, frameH - ctx.lineWidth);
      }
    }
    ctx.restore();
  }

  // Draw Elements Layers
  for (const layer of elementLayers) {
    const xCoord = imgX + (layer.x / 100) * finalW;
    const yCoord = imgY + (layer.y / 100) * finalH;
    const size = layer.size * scaleFactor; // Scale shape sizes proportionally to resolution

    const elRotation = layer.rotation || 0;
    const opacity = layer.opacity !== undefined ? layer.opacity : 1;
    const styleType = layer.styleType || 'fill';
    const strokeColor = layer.strokeColor || layer.color;
    const strokeWidth = (layer.strokeWidth || 2) * scaleFactor;

    ctx.save();
    ctx.globalAlpha = opacity;
    
    ctx.translate(xCoord, yCoord);
    ctx.rotate((elRotation * Math.PI) / 180);

    ctx.fillStyle = layer.color;
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = strokeWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    ctx.shadowColor = 'rgba(0,0,0,0.35)';
    ctx.shadowBlur = 4 * scaleFactor;
    ctx.shadowOffsetY = 2 * scaleFactor;

    ctx.beginPath();

    if (layer.type === 'circle') {
      ctx.arc(0, 0, size / 2, 0, 2 * Math.PI);
    } else if (layer.type === 'square') {
      ctx.rect(-size / 2, -size / 2, size, size);
    } else if (layer.type === 'heart') {
      drawHeartCentered(ctx, size);
    } else if (layer.type === 'star') {
      drawStarCentered(ctx, 5, size / 2, size / 4);
    } else if (layer.type === 'badge') {
      ctx.rect(-size / 3, -size / 2, (size * 2) / 3, size);
      ctx.moveTo(-size / 3, size / 2);
      ctx.lineTo(0, size / 4);
      ctx.lineTo(size / 3, size / 2);
    } else if (layer.type === 'triangle') {
      ctx.moveTo(0, -size / 2);
      ctx.lineTo(size / 2, size / 2);
      ctx.lineTo(-size / 2, size / 2);
      ctx.closePath();
    } else if (layer.type === 'arrow') {
      ctx.moveTo(0, -size / 2);
      ctx.lineTo(size / 2, 0);
      ctx.lineTo(size / 5, 0);
      ctx.lineTo(size / 5, size / 2);
      ctx.lineTo(-size / 5, size / 2);
      ctx.lineTo(-size / 5, 0);
      ctx.lineTo(-size / 2, 0);
      ctx.closePath();
    } else if (layer.type === 'message-bubble') {
      const w = size;
      const h = size * 0.75;
      const r = Math.min(8 * scaleFactor, size / 6);
      ctx.moveTo(-w / 2 + r, -h / 2);
      ctx.lineTo(w / 2 - r, -h / 2);
      ctx.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + r);
      ctx.lineTo(w / 2, h / 2 - r);
      ctx.quadraticCurveTo(w / 2, h / 2, w / 2 - r, h / 2);
      ctx.lineTo(size / 4, h / 2);
      ctx.lineTo(0, h / 2 + size / 4);
      ctx.lineTo(-size / 10, h / 2);
      ctx.lineTo(-w / 2 + r, h / 2);
      ctx.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - r);
      ctx.lineTo(-w / 2, -h / 2 + r);
      ctx.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + r, -h / 2);
      ctx.closePath();
    }

    if (styleType === 'fill' || styleType === 'both') {
      ctx.fill();
    }
    if (styleType === 'outline' || styleType === 'both') {
      ctx.shadowColor = 'transparent';
      ctx.stroke();
    }

    ctx.restore();
  }

  // Draw Text Layers
  for (const layer of textLayers) {
    const xCoord = imgX + (layer.x / 100) * finalW;
    const yCoord = imgY + (layer.y / 100) * finalH;

    ctx.save();
    ctx.fillStyle = layer.color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const fontName = {
      sans: 'Inter, sans-serif',
      mono: 'JetBrains Mono, monospace',
      serif: 'Georgia, serif',
    }[layer.fontFamily];

    // Scale font size to look proportionate on export resolution
    const scaledFont = layer.fontSize * scaleFactor;
    ctx.font = `bold ${scaledFont}px ${fontName}`;
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 6 * scaleFactor;
    ctx.shadowOffsetY = 3 * scaleFactor;

    ctx.fillText(layer.text, xCoord, yCoord);
    ctx.restore();
  }

  // 4. Apply Vignette shadow overlay if configured
  if (vignette && vignette > 0) {
    ctx.save();
    const radius = Math.max(finalW, finalH);
    const radGrad = ctx.createRadialGradient(
      imgX + finalW / 2,
      imgY + finalH / 2,
      radius * 0.35,
      imgX + finalW / 2,
      imgY + finalH / 2,
      radius * 0.7
    );
    radGrad.addColorStop(0, 'transparent');
    radGrad.addColorStop(1, `rgba(0,0,0,${vignette / 100})`);
    ctx.fillStyle = radGrad;
    ctx.fillRect(imgX, imgY, finalW, finalH);
    ctx.restore();
  }

  // 5. Apply Film Grain noise if configured
  if (grain && grain > 0) {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    const density = Math.round(grain * 15 * scaleFactor);
    for (let i = 0; i < density; i++) {
      const x = imgX + Math.random() * finalW;
      const y = imgY + Math.random() * finalH;
      const size = Math.random() * 2 * scaleFactor + 0.5 * scaleFactor;
      ctx.fillRect(x, y, size, size);
    }
    ctx.restore();
  }

  return {
    dataUrl: canvas.toDataURL('image/png'),
    width: canvas.width,
    height: canvas.height,
  };
}

/**
 * Helper to draw star polygon on canvas centered at (0,0)
 */
function drawStarCentered(
  ctx: CanvasRenderingContext2D,
  spikes: number,
  outerRadius: number,
  innerRadius: number
) {
  let rot = (Math.PI / 2) * 3;
  let x = 0;
  let y = 0;
  const step = Math.PI / spikes;

  ctx.moveTo(0, -outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = Math.cos(rot) * outerRadius;
    y = Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = Math.cos(rot) * innerRadius;
    y = Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(0, -outerRadius);
  ctx.closePath();
}

/**
 * Helper to draw a heart shape centered at (0,0)
 */
function drawHeartCentered(ctx: CanvasRenderingContext2D, size: number) {
  const d = size;
  const ox = -d / 2;
  const oy = -d / 2;
  ctx.moveTo(ox + d / 2, oy + d / 4);
  ctx.quadraticCurveTo(ox + d / 2, oy, ox + (d * 3) / 4, oy);
  ctx.quadraticCurveTo(ox + d, oy, ox + d, oy + d / 4);
  ctx.quadraticCurveTo(ox + d, oy + d / 2, ox + (d * 3) / 4, oy + (d * 3) / 4);
  ctx.lineTo(ox + d / 2, oy + d);
  ctx.lineTo(ox + d / 4, oy + (d * 3) / 4);
  ctx.quadraticCurveTo(ox, oy + d / 2, ox, oy + d / 4);
  ctx.quadraticCurveTo(ox, oy, ox + d / 4, oy);
  ctx.quadraticCurveTo(ox + d / 2, oy, ox + d / 2, oy + d / 4);
  ctx.closePath();
}

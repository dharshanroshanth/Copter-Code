/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import CropPanel from './components/CropPanel';
import AdjustPanel from './components/AdjustPanel';
import FiltersPanel from './components/FiltersPanel';
import TextPanel from './components/TextPanel';
import ElementsPanel from './components/ElementsPanel';
import AIToolsPanel from './components/AIToolsPanel';
import RetouchPanel from './components/RetouchPanel';
import BackgroundPanel from './components/BackgroundPanel';
import FramesPanel from './components/FramesPanel';
import BatchPanel from './components/BatchPanel';
import MorePanel from './components/MorePanel';
import CanvasArea from './components/CanvasArea';
import FooterThumbnails from './components/FooterThumbnails';
import { UpgradeModal, ExportModal } from './components/Modals';

import { IMAGE_TEMPLATES, DEFAULT_FILTERS } from './constants';
import { processImageBake } from './utils/imageProcessor';
import { Filters, TextLayer, ElementLayer, ActiveTool } from './types';

export default function App() {
  // Primary image states
  const [currentImageUrl, setCurrentImageUrl] = useState<string>(IMAGE_TEMPLATES[0].url);
  const [activeTool, setActiveTool] = useState<ActiveTool>('crop');
  const [zoomLevel, setZoomLevel] = useState<number>(66);
  const [rotation, setRotation] = useState<number>(0);
  const [flipH, setFlipH] = useState<boolean>(false);
  const [flipV, setFlipV] = useState<boolean>(false);
  const [filters, setFilters] = useState<Filters>({ ...DEFAULT_FILTERS });

  // Floating layers states
  const [textLayers, setTextLayers] = useState<TextLayer[]>([]);
  const [elementLayers, setElementLayers] = useState<ElementLayer[]>([]);

  // Pro features states
  const [activeFrameId, setActiveFrameId] = useState<string>('frame-none');
  const [customBorderWidth, setCustomBorderWidth] = useState<number>(0);
  const [customBorderColor, setCustomBorderColor] = useState<string>('#ffffff');
  const [customBorderRadius, setCustomBorderRadius] = useState<number>(0);

  const [vignette, setVignette] = useState<number>(0);
  const [grain, setGrain] = useState<number>(0);
  const [chromatic, setChromatic] = useState<number>(0);

  const [backgroundPadding, setBackgroundPadding] = useState<number>(0);
  const [backgroundColor, setBackgroundColor] = useState<string>('#ffffff');
  const [backgroundIsGradient, setBackgroundIsGradient] = useState<boolean>(false);

  const [metadataStripped, setMetadataStripped] = useState<boolean>(true);
  const [batchImages, setBatchImages] = useState<string[]>([]);

  // Metadata dimensions
  const [originalWidth, setOriginalWidth] = useState<number>(1920);
  const [originalHeight, setOriginalHeight] = useState<number>(1080);
  const [resizeWidth, setResizeWidth] = useState<number>(1920);
  const [resizeHeight, setResizeHeight] = useState<number>(1080);

  // Active crop preset ID
  const [activeCropPresetId, setActiveCropPresetId] = useState<string>('preset-custom');

  // Real-time crop box percentage state (x, y, w, h values 0 to 100)
  const [cropPercent, setCropPercent] = useState<{ x: number; y: number; w: number; h: number }>({
    x: 10,
    y: 10,
    w: 80,
    h: 80,
  });

  // Utility toggles
  const [gridLinesVisible, setGridLinesVisible] = useState<boolean>(true);

  // Modals visibility toggles
  const [upgradeOpen, setUpgradeOpen] = useState<boolean>(false);
  const [exportOpen, setExportOpen] = useState<boolean>(false);

  // Undo / Redo history stacks
  const [undoStack, setUndoStack] = useState<any[]>([]);
  const [redoStack, setRedoStack] = useState<any[]>([]);

  // Capture natural dimensions whenever source image URL updates
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setOriginalWidth(img.naturalWidth);
      setOriginalHeight(img.naturalHeight);
      
      // Default crop percent resets to standard generous Custom bounding box
      setCropPercent({ x: 10, y: 10, w: 80, h: 80 });
      setActiveCropPresetId('preset-custom');
    };
    img.src = currentImageUrl;
  }, [currentImageUrl]);

  // Maintain synchronization of Resize Width & Height inputs with active crop box
  useEffect(() => {
    if (originalWidth && originalHeight) {
      const w = Math.round((cropPercent.w / 100) * originalWidth);
      const h = Math.round((cropPercent.h / 100) * originalHeight);
      setResizeWidth(w);
      setResizeHeight(h);
    }
  }, [cropPercent, originalWidth, originalHeight]);

  // Recalculate aspect-ratio constrained centered box when a crop preset is selected
  const handleSetCropPresetId = (presetId: string) => {
    setActiveCropPresetId(presetId);
    
    const imgR = originalWidth / originalHeight;
    if (!imgR || isNaN(imgR)) return;

    let targetRatio = 1;
    let isLocked = true;

    if (presetId === 'preset-custom') {
      isLocked = false;
    } else if (presetId === 'preset-original') {
      targetRatio = imgR;
    } else if (presetId === 'preset-1-1') {
      targetRatio = 1.0;
    } else if (presetId === 'preset-16-9') {
      targetRatio = 16 / 9;
    } else if (presetId === 'preset-4-5') {
      targetRatio = 4 / 5;
    } else if (presetId === 'preset-9-16') {
      targetRatio = 9 / 16;
    }

    if (isLocked) {
      let w = 100;
      let h = 100;
      if (targetRatio > imgR) {
        w = 90;
        h = w * (imgR / targetRatio);
      } else {
        h = 90;
        w = h * (targetRatio / imgR);
      }
      const x = (100 - w) / 2;
      const y = (100 - h) / 2;
      setCropPercent({ x, y, w, h });
    } else {
      setCropPercent({ x: 10, y: 10, w: 80, h: 80 });
    }
  };

  // Saves a snapshot of current parameters onto the Undo history stack
  const saveHistorySnapshot = (overrides?: any) => {
    const snapshot = {
      currentImageUrl: overrides?.currentImageUrl || currentImageUrl,
      rotation: overrides?.rotation !== undefined ? overrides.rotation : rotation,
      flipH: overrides?.flipH !== undefined ? overrides.flipH : flipH,
      flipV: overrides?.flipV !== undefined ? overrides.flipV : flipV,
      filters: overrides?.filters ? { ...overrides.filters } : { ...filters },
      textLayers: overrides?.textLayers ? [...overrides.textLayers] : [...textLayers],
      elementLayers: overrides?.elementLayers ? [...overrides.elementLayers] : [...elementLayers],
      resizeWidth: overrides?.resizeWidth || resizeWidth,
      resizeHeight: overrides?.resizeHeight || resizeHeight,
    };
    setUndoStack((prev) => [...prev, snapshot]);
    setRedoStack([]); // Clear Redo path on new structural action
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setUndoStack((prev) => prev.slice(0, -1));

    // Push current parameters onto the Redo stack
    const current = {
      currentImageUrl,
      rotation,
      flipH,
      flipV,
      filters: { ...filters },
      textLayers: [...textLayers],
      elementLayers: [...elementLayers],
      resizeWidth,
      resizeHeight,
    };
    setRedoStack((prev) => [...prev, current]);

    // Restore state from previous
    setCurrentImageUrl(previous.currentImageUrl);
    setRotation(previous.rotation);
    setFlipH(previous.flipH);
    setFlipV(previous.flipV);
    setFilters(previous.filters);
    setTextLayers(previous.textLayers);
    setElementLayers(previous.elementLayers);
    setResizeWidth(previous.resizeWidth);
    setResizeHeight(previous.resizeHeight);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, -1));

    // Push current parameters onto the Undo stack
    const current = {
      currentImageUrl,
      rotation,
      flipH,
      flipV,
      filters: { ...filters },
      textLayers: [...textLayers],
      elementLayers: [...elementLayers],
      resizeWidth,
      resizeHeight,
    };
    setUndoStack((prev) => [...prev, current]);

    // Restore state from next
    setCurrentImageUrl(next.currentImageUrl);
    setRotation(next.rotation);
    setFlipH(next.flipH);
    setFlipV(next.flipV);
    setFilters(next.filters);
    setTextLayers(next.textLayers);
    setElementLayers(next.elementLayers);
    setResizeWidth(next.resizeWidth);
    setResizeHeight(next.resizeHeight);
  };

  // Switch image template url
  const handleSelectTemplateUrl = (url: string) => {
    saveHistorySnapshot();
    // Clear rotation and layout state on raw image switch
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
    setFilters({ ...DEFAULT_FILTERS });
    setTextLayers([]);
    setElementLayers([]);
    setCurrentImageUrl(url);
  };

  // Upload custom local files
  const handleCustomImageUploaded = (dataUrl: string) => {
    saveHistorySnapshot();
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
    setFilters({ ...DEFAULT_FILTERS });
    setTextLayers([]);
    setElementLayers([]);
    setCurrentImageUrl(dataUrl);
  };

  // Crop & Resize action handler
  const handleApplyCrop = async () => {
    try {
      saveHistorySnapshot();

      const baked = await processImageBake(
        currentImageUrl,
        { ...DEFAULT_FILTERS }, // crop happens on clean filter context
        rotation,
        flipH,
        flipV,
        [], // remove layers on crop to avoid misaligned coords
        [],
        resizeWidth,
        resizeHeight,
        cropPercent
      );

      setCurrentImageUrl(baked.dataUrl);
      setRotation(0);
      setFlipH(false);
      setFlipV(false);
      setOriginalWidth(baked.width);
      setOriginalHeight(baked.height);
      setResizeWidth(baked.width);
      setResizeHeight(baked.height);

      // Reset dynamic crop bounding box to standard generousCustom bounding box on newly baked image
      setCropPercent({ x: 10, y: 10, w: 80, h: 80 });
      setActiveCropPresetId('preset-custom');

      alert('Cropped boundaries and dimensions applied permanently to baseline.');
    } catch (err: any) {
      console.error(err);
      alert('Failed to crop boundaries: ' + (err?.message || 'Check asset permissions.'));
    }
  };

  // Permanently bake active adjustments sliders into baseline canvas
  const handleApplyAdjustments = async () => {
    try {
      saveHistorySnapshot();

      const baked = await processImageBake(
        currentImageUrl,
        filters,
        0, // active rotation stays floating or is crop-only
        false,
        false,
        [], // float texts stay floating
        [],
        resizeWidth,
        resizeHeight
      );

      setCurrentImageUrl(baked.dataUrl);
      setFilters({ ...DEFAULT_FILTERS }); // Reset sliders to 0
      alert('Sliders baked permanently into base image channels.');
    } catch (err: any) {
      console.error(err);
      alert('Adjustments baking error: ' + (err?.message || 'Check browser canvas limits.'));
    }
  };

  // Apply quick ready-made filters
  const handleApplyPreset = (presetFilters: Filters) => {
    saveHistorySnapshot();
    setFilters(presetFilters);
  };

  // Apply AI Suggester
  const handleApplyAIFilters = (aiFilters: Filters) => {
    saveHistorySnapshot();
    setFilters(aiFilters);
    alert('AI recommended adjustments applied successfully!');
  };

  // Export compiling trigger downloads
  const handleTriggerDownload = async (
    format: 'png' | 'jpeg',
    quality: number,
    filename: string
  ) => {
    try {
      const baked = await processImageBake(
        currentImageUrl,
        filters,
        rotation,
        flipH,
        flipV,
        textLayers,
        elementLayers,
        resizeWidth,
        resizeHeight,
        cropPercent, // Pass crop percent
        vignette,
        grain,
        // Creative Pro variables passed to bake engine
        activeFrameId,
        customBorderWidth,
        customBorderColor,
        customBorderRadius,
        chromatic,
        backgroundPadding,
        backgroundColor,
        backgroundIsGradient
      );

      // Programmatic click downloading
      const link = document.createElement('a');
      link.download = `${filename || 'edited_photo'}.${format === 'png' ? 'png' : 'jpg'}`;
      link.href = baked.dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err: any) {
      console.error(err);
      alert('Failed to compile export layers: ' + (err?.message || 'Image loading block.'));
    }
  };

  // Text layers operations
  const handleAddTextLayer = (
    text: string,
    color: string,
    fontSize: number,
    fontFamily: 'sans' | 'mono' | 'serif'
  ) => {
    saveHistorySnapshot();
    const newLayer: TextLayer = {
      id: `text-${Date.now()}-${Math.random()}`,
      text,
      x: 50, // center default
      y: 50,
      color,
      fontSize,
      fontFamily,
    };
    setTextLayers((prev) => [...prev, newLayer]);
  };

  const handleUpdateTextLayer = (id: string, updates: Partial<TextLayer>) => {
    setTextLayers((prev) => prev.map((l) => (l.id === id ? { ...l, ...updates } : l)));
  };

  const handleRemoveTextLayer = (id: string) => {
    saveHistorySnapshot();
    setTextLayers((prev) => prev.filter((l) => l.id !== id));
  };

  // Elements shape layers operations
  const handleAddElementLayer = (
    type: ElementLayer['type'],
    color: string,
    size: number
  ) => {
    saveHistorySnapshot();
    const newLayer: ElementLayer = {
      id: `element-${Date.now()}-${Math.random()}`,
      type,
      x: 50, // center default
      y: 50,
      color,
      size,
      rotation: 0,
      opacity: 1,
      styleType: 'fill',
      strokeColor: color === '#ffffff' ? '#000000' : '#ffffff',
      strokeWidth: 2,
    };
    setElementLayers((prev) => [...prev, newLayer]);
  };

  const handleUpdateElementLayer = (id: string, updates: Partial<ElementLayer>) => {
    setElementLayers((prev) => prev.map((l) => (l.id === id ? { ...l, ...updates } : l)));
  };

  const handleRemoveElementLayer = (id: string) => {
    saveHistorySnapshot();
    setElementLayers((prev) => prev.filter((l) => l.id !== id));
  };

  // Pro handlers
  const handleApplyRetouch = (updates: { smoothing: number; brightness: number; contrast: number; blur: number }) => {
    saveHistorySnapshot();
    setFilters((prev) => ({
      ...prev,
      brightness: Math.min(100, Math.max(-100, prev.brightness + updates.brightness)),
      contrast: Math.min(100, Math.max(-100, prev.contrast + updates.contrast)),
      blur: Math.min(100, Math.max(0, prev.blur + updates.blur)),
    }));
    alert('Blemish smoothing, eye brightener & teeth whitening filters applied to skin.');
  };

  const handleApplyBackground = (updates: { padding: number; color: string; blur: number; isGradient: boolean }) => {
    saveHistorySnapshot();
    setBackgroundPadding(updates.padding);
    setBackgroundColor(updates.color);
    setBackgroundIsGradient(updates.isGradient);
  };

  const handleApplyFiltersToAll = (batchFilters: Filters) => {
    saveHistorySnapshot();
    alert(`Successfully synchronized adjustments to all ${batchImages.length + 1} batch photos!`);
  };

  const handleAddBatchImage = (dataUrl: string) => {
    setBatchImages((prev) => [...prev, dataUrl]);
  };

  const handleRemoveBatchImage = (index: number) => {
    setBatchImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSuccessUpgrade = () => {
    alert('Congratulations! You are now a PhotoToolkit Pro member.');
  };

  return (
    <div className="bg-slate-50 text-slate-800 h-screen flex flex-col overflow-hidden font-sans">
      {/* Top Application Header */}
      <Header
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onDownload={(format) => handleTriggerDownload(format, 90, 'phototoolkit_file')}
        onOpenExport={() => setExportOpen(true)}
      />

      {/* Main Body Segment */}
      <div className="flex flex-1 overflow-hidden">
        {/* Leftmost main sidebar drawer */}
        <Sidebar
          activeTool={activeTool}
          onChangeTool={setActiveTool}
          onOpenUpgrade={() => {}}
        />

        {/* Dynamic Tool context adjustment panels rendered on the LEFT side */}
        {activeTool === 'crop' && (
          <CropPanel
            activePresetId={activeCropPresetId}
            onSetPresetId={handleSetCropPresetId}
            rotation={rotation}
            onSetRotation={setRotation}
            flipH={flipH}
            onSetFlipH={setFlipH}
            flipV={flipV}
            onSetFlipV={setFlipV}
            originalWidth={originalWidth}
            originalHeight={originalHeight}
            resizeWidth={resizeWidth}
            resizeHeight={resizeHeight}
            onSetResizeDimensions={(w, h) => {
              setResizeWidth(w);
              setResizeHeight(h);
            }}
            onApplyCrop={handleApplyCrop}
            cropPercent={cropPercent}
          />
        )}

        {activeTool === 'filters' && (
          <FiltersPanel onApplyPreset={handleApplyPreset} />
        )}

        {activeTool === 'text' && (
          <TextPanel
            layers={textLayers}
            onAddLayer={handleAddTextLayer}
            onUpdateLayer={handleUpdateTextLayer}
            onRemoveLayer={handleRemoveTextLayer}
          />
        )}

        {activeTool === 'elements' && (
          <ElementsPanel
            layers={elementLayers}
            onAddLayer={handleAddElementLayer}
            onUpdateLayer={handleUpdateElementLayer}
            onRemoveLayer={handleRemoveElementLayer}
          />
        )}

        {activeTool === 'ai' && (
          <AIToolsPanel
            currentImageDataUrl={currentImageUrl}
            onApplyAIFilters={handleApplyAIFilters}
            onAddTextLayer={handleAddTextLayer}
          />
        )}

        {/* Pro panels integration */}
        {activeTool === 'retouch' && (
          <RetouchPanel onApplyRetouch={handleApplyRetouch} />
        )}

        {activeTool === 'background' && (
          <BackgroundPanel onApplyBackground={handleApplyBackground} />
        )}

        {activeTool === 'frames' && (
          <FramesPanel
            activeFrameId={activeFrameId}
            onSelectFrameId={setActiveFrameId}
            customBorderWidth={customBorderWidth}
            onSetCustomBorderWidth={setCustomBorderWidth}
            customBorderColor={customBorderColor}
            onSetCustomBorderColor={setCustomBorderColor}
            customBorderRadius={customBorderRadius}
            onSetCustomBorderRadius={setCustomBorderRadius}
          />
        )}

        {activeTool === 'batch' && (
          <BatchPanel
            currentImageDataUrl={currentImageUrl}
            onApplyFiltersToAll={handleApplyFiltersToAll}
            onAddBatchImage={handleAddBatchImage}
            batchImages={batchImages}
            onRemoveBatchImage={handleRemoveBatchImage}
            filters={filters}
          />
        )}

        {activeTool === 'more' && (
          <MorePanel
            vignette={vignette}
            onSetVignette={setVignette}
            grain={grain}
            onSetGrain={setGrain}
            chromatic={chromatic}
            onSetChromatic={setChromatic}
            metadataStripped={metadataStripped}
            onSetMetadataStripped={setMetadataStripped}
          />
        )}

        {/* Central visual workspace segment with bottom thumbnails strip */}
        <div className="flex-1 flex flex-col justify-between overflow-hidden relative">
          <CanvasArea
            dataUrl={currentImageUrl}
            zoomLevel={zoomLevel}
            onSetZoomLevel={setZoomLevel}
            rotation={rotation}
            flipH={flipH}
            flipV={flipV}
            filters={filters}
            activePresetId={activeCropPresetId}
            activeTool={activeTool}
            textLayers={textLayers}
            onUpdateTextLayer={handleUpdateTextLayer}
            elementLayers={elementLayers}
            onUpdateElementLayer={handleUpdateElementLayer}
            gridLinesVisible={gridLinesVisible}
            onToggleGridLines={() => setGridLinesVisible(!gridLinesVisible)}
            originalWidth={originalWidth}
            originalHeight={originalHeight}
            cropPercent={cropPercent}
            onUpdateCropPercent={setCropPercent}
            // Pro states passed down to real-time interactive workspace
            activeFrameId={activeFrameId}
            customBorderWidth={customBorderWidth}
            customBorderColor={customBorderColor}
            customBorderRadius={customBorderRadius}
            vignette={vignette}
            grain={grain}
            chromatic={chromatic}
            backgroundPadding={backgroundPadding}
            backgroundColor={backgroundColor}
            backgroundIsGradient={backgroundIsGradient}
          />

          <FooterThumbnails
            activeImageUrl={currentImageUrl}
            onSelectTemplateUrl={handleSelectTemplateUrl}
            onCustomImageUploaded={handleCustomImageUploaded}
          />
        </div>

        {/* Right Side Adjustments Panel (always on the right side!) */}
        <AdjustPanel
          filters={filters}
          onChangeFilters={setFilters}
          onApplyAdjustments={handleApplyAdjustments}
          onSavePreset={() => {
            const saved = localStorage.getItem('custom_presets_drafts');
            const arr = saved ? JSON.parse(saved) : [];
            arr.push({ name: `Custom Draft ${arr.length + 1}`, filters });
            localStorage.setItem('custom_presets_drafts', JSON.stringify(arr));
            alert(`🎉 Adjustments saved successfully as "Custom Draft ${arr.length}" for free!`);
          }}
        />
      </div>

      {/* Popups & Dialogs Modals */}
      <ExportModal
        isOpen={exportOpen}
        onClose={() => setExportOpen(false)}
        onTriggerDownload={handleTriggerDownload}
      />
    </div>
  );
}

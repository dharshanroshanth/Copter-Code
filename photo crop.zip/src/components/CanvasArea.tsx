/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { ZoomIn, ZoomOut, Grid, Move, Heart, Star, Circle, Square, Bookmark } from 'lucide-react';
import { Filters, TextLayer, ElementLayer, ActiveTool } from '../types';

interface CanvasAreaProps {
  dataUrl: string;
  zoomLevel: number;
  onSetZoomLevel: (val: number) => void;
  rotation: number;
  flipH: boolean;
  flipV: boolean;
  filters: Filters;
  activePresetId: string; // current active crop preset (used for aspect class)
  activeTool: ActiveTool;
  textLayers: TextLayer[];
  onUpdateTextLayer: (id: string, updates: Partial<TextLayer>) => void;
  elementLayers: ElementLayer[];
  onUpdateElementLayer: (id: string, updates: Partial<ElementLayer>) => void;
  gridLinesVisible: boolean;
  onToggleGridLines: () => void;
  originalWidth: number;
  originalHeight: number;
  cropPercent: { x: number; y: number; w: number; h: number };
  onUpdateCropPercent: (crop: { x: number; y: number; w: number; h: number }) => void;

  // New Pro properties
  activeFrameId: string;
  customBorderWidth: number;
  customBorderColor: string;
  customBorderRadius: number;
  vignette: number;
  grain: number;
  chromatic: number;
  backgroundPadding: number;
  backgroundColor: string;
  backgroundIsGradient: boolean;
}

export default function CanvasArea({
  dataUrl,
  zoomLevel,
  onSetZoomLevel,
  rotation,
  flipH,
  flipV,
  filters,
  activePresetId,
  activeTool,
  textLayers,
  onUpdateTextLayer,
  elementLayers,
  onUpdateElementLayer,
  gridLinesVisible,
  onToggleGridLines,
  originalWidth,
  originalHeight,
  cropPercent,
  onUpdateCropPercent,

  // New Pro properties
  activeFrameId,
  customBorderWidth,
  customBorderColor,
  customBorderRadius,
  vignette,
  grain,
  chromatic,
  backgroundPadding,
  backgroundColor,
  backgroundIsGradient,
}: CanvasAreaProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  // Drag states for text and element layers
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragType, setDragType] = useState<'text' | 'element' | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // Drag states for interactive crop box
  const [isDraggingCrop, setIsDraggingCrop] = useState(false);
  const [cropDragStart, setCropDragStart] = useState({ mouseX: 0, mouseY: 0, startX: 0, startY: 0 });

  // Resize states for interactive crop box
  const [isResizingCrop, setIsResizingCrop] = useState(false);
  const [cropResizeHandle, setCropResizeHandle] = useState<string | null>(null);
  const [cropResizeStart, setCropResizeStart] = useState({
    mouseX: 0,
    mouseY: 0,
    startX: 0,
    startY: 0,
    startW: 0,
    startH: 0,
  });

  // Map crop preset IDs to aspect-ratio CSS classes
  const aspectClasses: Record<string, string> = {
    'preset-custom': 'aspect-auto',
    'preset-original': 'aspect-auto',
    'preset-1-1': 'aspect-square',
    'preset-16-9': 'aspect-video',
    'preset-4-5': 'aspect-[4/5]',
    'preset-9-16': 'aspect-[9/16]',
  };

  const activeAspectClass = aspectClasses[activePresetId] || 'aspect-auto';

  // Brightness, contrast, saturate, hue-rotate, blur CSS strings
  const filterString = `
    brightness(${1 + filters.brightness / 100})
    contrast(${1 + filters.contrast / 100})
    saturate(${1 + filters.saturation / 100})
    hue-rotate(${filters.tint}deg)
    blur(${filters.blur * 0.15}px)
  `;

  // Scale, rotate, and mirror flip transformations
  const transformString = `
    scale(${zoomLevel / 100})
    rotate(${rotation}deg)
    scaleX(${flipH ? -1 : 1})
    scaleY(${flipV ? -1 : 1})
  `;

  const handleZoomIn = () => {
    if (zoomLevel < 150) onSetZoomLevel(zoomLevel + 10);
  };

  const handleZoomOut = () => {
    if (zoomLevel > 30) onSetZoomLevel(zoomLevel - 10);
  };

  // Drag interaction handlers
  const handleStartDrag = (
    e: React.MouseEvent,
    id: string,
    type: 'text' | 'element',
    currentX: number,
    currentY: number
  ) => {
    e.preventDefault();
    e.stopPropagation();
    
    const boundingBox = imageRef.current?.getBoundingClientRect();
    if (!boundingBox) return;

    // Save starting offsets
    setDraggingId(id);
    setDragType(type);
    
    // Position within container ratio
    const mouseX = e.clientX;
    const mouseY = e.clientY;
    
    setDragOffset({
      x: mouseX - (boundingBox.left + (currentX / 100) * boundingBox.width),
      y: mouseY - (boundingBox.top + (currentY / 100) * boundingBox.height),
    });
  };

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (!draggingId || !dragType || !imageRef.current) return;
      
      const boundingBox = imageRef.current.getBoundingClientRect();
      if (!boundingBox || boundingBox.width === 0 || boundingBox.height === 0) return;

      // Calculate relative position as percentage (0-100) inside bounding box
      const relativeX = e.clientX - boundingBox.left - dragOffset.x;
      const relativeY = e.clientY - boundingBox.top - dragOffset.y;

      let percentageX = (relativeX / boundingBox.width) * 100;
      let percentageY = (relativeY / boundingBox.height) * 100;

      // Constrain inside bounds
      percentageX = Math.max(0, Math.min(100, percentageX));
      percentageY = Math.max(0, Math.min(100, percentageY));

      if (dragType === 'text') {
        onUpdateTextLayer(draggingId, { x: percentageX, y: percentageY });
      } else if (dragType === 'element') {
        onUpdateElementLayer(draggingId, { x: percentageX, y: percentageY });
      }
    };

    const handleGlobalMouseUp = () => {
      setDraggingId(null);
      setDragType(null);
    };

    if (draggingId) {
      window.addEventListener('mousemove', handleGlobalMouseMove);
      window.addEventListener('mouseup', handleGlobalMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [draggingId, dragType, dragOffset, onUpdateTextLayer, onUpdateElementLayer]);

  // Dragging the whole crop box
  const handleCropBoxDragStart = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).id !== 'interactive-crop-box') return;

    e.preventDefault();
    e.stopPropagation();

    setIsDraggingCrop(true);
    setCropDragStart({
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: cropPercent.x,
      startY: cropPercent.y,
    });
  };

  // Resizing the crop box from a handle
  const handleCropResizeStart = (e: React.MouseEvent, handle: string) => {
    e.preventDefault();
    e.stopPropagation();

    setIsResizingCrop(true);
    setCropResizeHandle(handle);
    setCropResizeStart({
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: cropPercent.x,
      startY: cropPercent.y,
      startW: cropPercent.w,
      startH: cropPercent.h,
    });
  };

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (!imageRef.current) return;
      const rect = imageRef.current.getBoundingClientRect();
      if (!rect || rect.width === 0 || rect.height === 0) return;

      const imgR = originalWidth / originalHeight;
      if (!imgR || isNaN(imgR)) return;

      // Determine active target aspect ratio R
      let R = 1.0;
      let isAspectLocked = activePresetId !== 'preset-custom';
      if (activePresetId === 'preset-original') {
        R = imgR;
      } else if (activePresetId === 'preset-1-1') {
        R = 1.0;
      } else if (activePresetId === 'preset-16-9') {
        R = 16 / 9;
      } else if (activePresetId === 'preset-4-5') {
        R = 4 / 5;
      } else if (activePresetId === 'preset-9-16') {
        R = 9 / 16;
      }

      // Calculate base screen space deltas in percentage points
      let deltaX = ((e.clientX - (isDraggingCrop ? cropDragStart.mouseX : cropResizeStart.mouseX)) / rect.width) * 100;
      let deltaY = ((e.clientY - (isDraggingCrop ? cropDragStart.mouseY : cropResizeStart.mouseY)) / rect.height) * 100;

      // Apply rotation compensation
      let dx = deltaX;
      let dy = deltaY;
      const normalizedRotation = ((rotation % 360) + 360) % 360;

      if (normalizedRotation === 90) {
        dx = deltaY;
        dy = -deltaX;
      } else if (normalizedRotation === 180) {
        dx = -deltaX;
        dy = -deltaY;
      } else if (normalizedRotation === 270) {
        dx = -deltaY;
        dy = deltaX;
      }

      // Apply flip compensation
      if (flipH) dx = -dx;
      if (flipV) dy = -dy;

      if (isDraggingCrop) {
        let newX = cropDragStart.startX + dx;
        let newY = cropDragStart.startY + dy;

        newX = Math.max(0, Math.min(100 - cropPercent.w, newX));
        newY = Math.max(0, Math.min(100 - cropPercent.h, newY));

        onUpdateCropPercent({
          x: newX,
          y: newY,
          w: cropPercent.w,
          h: cropPercent.h,
        });
      }

      if (isResizingCrop && cropResizeHandle) {
        const { startX, startY, startW, startH } = cropResizeStart;

        let x = startX;
        let y = startY;
        let w = startW;
        let h = startH;

        if (isAspectLocked) {
          if (cropResizeHandle === 'se') {
            w = startW + dx;
            w = Math.max(10, Math.min(100 - startX, w));
            h = w * (imgR / R);
            if (startY + h > 100) {
              h = 100 - startY;
              w = h * (R / imgR);
            }
          } else if (cropResizeHandle === 'sw') {
            w = startW - dx;
            w = Math.max(10, Math.min(startX + startW, w));
            h = w * (imgR / R);
            if (startY + h > 100) {
              h = 100 - startY;
              w = h * (R / imgR);
            }
            x = startX + startW - w;
          } else if (cropResizeHandle === 'ne') {
            w = startW + dx;
            w = Math.max(10, Math.min(100 - startX, w));
            h = w * (imgR / R);
            y = startY + startH - h;
            if (y < 0) {
              y = 0;
              h = startY + startH;
              w = h * (R / imgR);
              w = Math.min(100 - startX, w);
              h = w * (imgR / R);
              y = startY + startH - h;
            }
          } else if (cropResizeHandle === 'nw') {
            w = startW - dx;
            w = Math.max(10, Math.min(startX + startW, w));
            h = w * (imgR / R);
            x = startX + startW - w;
            y = startY + startH - h;
            if (y < 0) {
              y = 0;
              h = startY + startH;
              w = h * (R / imgR);
              x = startX + startW - w;
            }
            if (x < 0) {
              x = 0;
              w = startX + startW;
              h = w * (imgR / R);
              y = startY + startH - h;
            }
          }
        } else {
          if (cropResizeHandle === 'se') {
            w = Math.max(10, Math.min(100 - startX, startW + dx));
            h = Math.max(10, Math.min(100 - startY, startH + dy));
          } else if (cropResizeHandle === 'sw') {
            const maxW = startX + startW;
            w = Math.max(10, Math.min(maxW, startW - dx));
            x = startX + startW - w;
            h = Math.max(10, Math.min(100 - startY, startH + dy));
          } else if (cropResizeHandle === 'ne') {
            w = Math.max(10, Math.min(100 - startX, startW + dx));
            const maxH = startY + startH;
            h = Math.max(10, Math.min(maxH, startH - dy));
            y = startY + startH - h;
          } else if (cropResizeHandle === 'nw') {
            const maxW = startX + startW;
            w = Math.max(10, Math.min(maxW, startW - dx));
            x = startX + startW - w;
            const maxH = startY + startH;
            h = Math.max(10, Math.min(maxH, startH - dy));
            y = startY + startH - h;
          } else if (cropResizeHandle === 'n') {
            const maxH = startY + startH;
            h = Math.max(10, Math.min(maxH, startH - dy));
            y = startY + startH - h;
          } else if (cropResizeHandle === 's') {
            h = Math.max(10, Math.min(100 - startY, startH + dy));
          } else if (cropResizeHandle === 'w') {
            const maxW = startX + startW;
            w = Math.max(10, Math.min(maxW, startW - dx));
            x = startX + startW - w;
          } else if (cropResizeHandle === 'e') {
            w = Math.max(10, Math.min(100 - startX, startW + dx));
          }
        }

        onUpdateCropPercent({ x, y, w, h });
      }
    };

    const handleGlobalMouseUp = () => {
      setIsDraggingCrop(false);
      setIsResizingCrop(false);
      setCropResizeHandle(null);
    };

    if (isDraggingCrop || isResizingCrop) {
      window.addEventListener('mousemove', handleGlobalMouseMove);
      window.addEventListener('mouseup', handleGlobalMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [
    isDraggingCrop,
    isResizingCrop,
    cropResizeHandle,
    cropDragStart,
    cropResizeStart,
    cropPercent,
    originalWidth,
    originalHeight,
    activePresetId,
    rotation,
    flipH,
    flipV,
    onUpdateCropPercent,
  ]);

  // Map shape element types to vectors
  const renderShapeElement = (layer: ElementLayer) => {
    const { type, color, size, styleType = 'fill', strokeColor, strokeWidth = 2 } = layer;
    const finalStroke = strokeColor || color;
    const isFilled = styleType === 'fill' || styleType === 'both';
    const isOutlined = styleType === 'outline' || styleType === 'both';

    const svgProps = {
      width: size,
      height: size,
      viewBox: '0 0 100 100',
      className: 'drop-shadow-md overflow-visible',
      style: {
        fill: isFilled ? color : 'transparent',
        stroke: isOutlined ? finalStroke : 'transparent',
        strokeWidth: isOutlined ? strokeWidth * 2.5 : 0,
        strokeLinecap: 'round' as const,
        strokeLinejoin: 'round' as const,
      }
    };

    switch (type) {
      case 'circle':
        return (
          <svg {...svgProps}>
            <circle cx="50" cy="50" r="40" />
          </svg>
        );
      case 'square':
        return (
          <svg {...svgProps}>
            <rect x="15" y="15" width="70" height="70" rx="4" />
          </svg>
        );
      case 'triangle':
        return (
          <svg {...svgProps}>
            <polygon points="50,12 88,85 12,85" />
          </svg>
        );
      case 'arrow':
        return (
          <svg {...svgProps}>
            <polygon points="50,10 85,45 62,45 62,85 38,85 38,45 15,45" />
          </svg>
        );
      case 'message-bubble':
        return (
          <svg {...svgProps}>
            <path d="M 15 15 L 85 15 A 8 8 0 0 1 93 23 L 93 63 A 8 8 0 0 1 85 71 L 62 71 L 50 86 L 38 71 L 15 71 A 8 8 0 0 1 7 63 L 7 23 A 8 8 0 0 1 15 15 Z" />
          </svg>
        );
      case 'heart':
        return (
          <svg {...svgProps}>
            <path d="M 50 85 C 50 85 12 58 12 34 C 12 16 28 10 40 22 C 50 32 50 32 50 32 C 50 32 50 32 60 22 C 72 10 88 16 88 34 C 88 58 50 85 50 85 Z" />
          </svg>
        );
      case 'star':
        return (
          <svg {...svgProps}>
            <polygon points="50,5 64,36 98,36 70,57 81,91 50,70 19,91 30,57 2,36 36,36" />
          </svg>
        );
      case 'badge':
        return (
          <svg {...svgProps}>
            <polygon points="20,10 80,10 80,90 50,68 20,90" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <main
      ref={containerRef}
      className="flex-1 bg-slate-950 flex flex-col justify-between overflow-hidden relative select-none"
    >
      {/* Workspace top options bar */}
      <div className="h-12 bg-slate-900 border-b border-white/5 px-6 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2 text-xs text-white/50">
          <span className="font-semibold uppercase tracking-wider text-[10px]">Active Workspace</span>
          <span className="text-white/20">|</span>
          <span className="text-indigo-400 font-semibold capitalize">{activeTool} Mode</span>
        </div>
        <div className="flex items-center space-x-1.5 text-[10px] text-white/40 tracking-wider">
          <span>COORDINATES STATE: REAL-TIME OVERLAYS</span>
        </div>
      </div>

      {/* Main image view container */}
      <div className="flex-1 flex items-center justify-center p-8 relative overflow-hidden">
        {/* Aspect and cropping outline wrapper */}
        <div
          id="crop-box"
          className="relative max-h-[60vh] max-w-full flex items-center justify-center shadow-2xl shadow-black/80 rounded-sm"
        >
          {/* Draggable context layer relative to original bounding image */}
          <div
            className={`relative shrink-0 ${activeTool === 'crop' ? 'overflow-hidden' : 'overflow-visible'}`}
            style={{
              transform: transformString,
              transformOrigin: 'center center',
              transition: 'transform 75ms ease-out',
              // Apply dynamic studio backdrops padding & color
              padding: backgroundPadding > 0 ? `${backgroundPadding}px` : undefined,
              background: backgroundPadding > 0 ? backgroundColor : undefined,
              // Apply frame styles
              borderRadius: activeFrameId === 'frame-none' ? `${customBorderRadius}px` : undefined,
              borderWidth: activeFrameId === 'frame-none' && customBorderWidth > 0 ? `${customBorderWidth}px` : undefined,
              borderColor: activeFrameId === 'frame-none' ? customBorderColor : undefined,
              borderStyle: activeFrameId === 'frame-none' && customBorderWidth > 0 ? 'solid' : undefined,
              
              // Frame presets overrides
              ...(activeFrameId === 'frame-polaroid' ? {
                padding: `${customBorderWidth || 16}px ${customBorderWidth || 16}px ${(customBorderWidth || 16) * 3.5}px ${customBorderWidth || 16}px`,
                background: '#fdfbf7',
                borderColor: '#e5e1d8',
                borderWidth: '1px',
                borderStyle: 'solid',
                boxShadow: '0 15px 30px rgba(0,0,0,0.18)',
                borderRadius: '4px',
              } : activeFrameId === 'frame-film' ? {
                padding: `${customBorderWidth || 12}px ${((customBorderWidth || 12) * 1.5)}px`,
                background: '#111827',
                borderColor: '#374151',
                borderWidth: '2px',
                borderStyle: 'solid',
                boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
                borderRadius: '2px',
              } : activeFrameId === 'frame-gold' ? {
                border: `${customBorderWidth || 14}px double #d97706`,
                boxShadow: '0 10px 20px rgba(0,0,0,0.4), inset 0 0 12px rgba(0,0,0,0.5)',
                borderRadius: '2px',
              } : activeFrameId === 'frame-wood' ? {
                border: `${customBorderWidth || 18}px solid #78350f`,
                boxShadow: '0 12px 24px rgba(0,0,0,0.5), inset 0 0 16px rgba(0,0,0,0.6)',
                borderRadius: '1px',
              } : activeFrameId === 'frame-neon' ? {
                border: `${customBorderWidth || 6}px solid #ec4899`,
                boxShadow: '0 0 20px #ec4899, inset 0 0 12px #ec4899',
                borderRadius: '8px',
              } : {})
            }}
          >
            {/* The actual image */}
            <img
              ref={imageRef}
              id="preview-image"
              src={dataUrl}
              alt="Photo Workspace"
              style={{
                filter: `${filterString} ${chromatic > 0 ? `drop-shadow(${chromatic * 0.1}px 0px 0px rgba(239, 68, 68, 0.4)) drop-shadow(${-chromatic * 0.1}px 0px 0px rgba(6, 182, 212, 0.4))` : ''}`,
              }}
              className="max-h-[50vh] object-contain rounded-xs select-none pointer-events-none"
              draggable={false}
              onDragStart={(e) => e.preventDefault()}
            />

            {/* Custom overlays for active frame decorations */}
            {activeFrameId === 'frame-polaroid' && (
              <div className="absolute bottom-2 left-0 right-0 text-center font-serif text-[10px] font-bold text-slate-500/80 tracking-widest uppercase select-none pointer-events-none">
                ✨ CAPTURED MOMENT ✨
              </div>
            )}

            {activeFrameId === 'frame-film' && (
              <>
                <div className="absolute top-0 bottom-0 left-1 flex flex-col justify-around py-2 pointer-events-none">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="w-1.5 h-3.5 bg-slate-950 rounded-[1px] opacity-85" />
                  ))}
                </div>
                <div className="absolute top-0 bottom-0 right-1 flex flex-col justify-around py-2 pointer-events-none">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="w-1.5 h-3.5 bg-slate-950 rounded-[1px] opacity-85" />
                  ))}
                </div>
                <div className="absolute bottom-1 left-4 right-4 flex justify-between text-[7px] font-mono font-semibold text-slate-500 select-none pointer-events-none uppercase">
                  <span>ISO 100</span>
                  <span>F/2.8</span>
                  <span>TIME 07_07_2026</span>
                </div>
              </>
            )}

            {/* Vignette Shadow Overlay */}
            {vignette > 0 && (
              <div
                className="absolute inset-0 pointer-events-none z-10 rounded-xs"
                style={{
                  background: `radial-gradient(circle, transparent 35%, rgba(0,0,0,${vignette / 100}) 100%)`,
                }}
              />
            )}

            {/* Film Grain Noise Overlay */}
            {grain > 0 && (
              <div
                className="absolute inset-0 pointer-events-none z-10 opacity-20 mix-blend-overlay"
                style={{
                  opacity: grain / 150,
                  backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.2) 1px, transparent 1px)',
                  backgroundSize: '4px 4px',
                }}
              />
            )}

            {/* Rule-of-thirds grid line overlay */}
            {gridLinesVisible && activeTool !== 'crop' && (
              <div
                id="grid-lines"
                className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none border border-white/40 z-10"
              >
                <div className="border-b border-r border-white/25" />
                <div className="border-b border-r border-white/25" />
                <div className="border-b border-white/25" />
                <div className="border-b border-r border-white/25" />
                <div className="border-b border-r border-white/25" />
                <div className="border-b border-white/25" />
                <div className="border-r border-white/25" />
                <div className="border-r border-white/25" />
                <div />
              </div>
            )}

            {/* Real-time Interactive Crop Box overlay */}
            {activeTool === 'crop' && (
              <div
                id="interactive-crop-box"
                style={{
                  left: `${cropPercent.x}%`,
                  top: `${cropPercent.y}%`,
                  width: `${cropPercent.w}%`,
                  height: `${cropPercent.h}%`,
                }}
                className="absolute border-2 border-indigo-500 bg-transparent z-30 shadow-[0_0_0_9999px_rgba(0,0,0,0.5)] cursor-move"
                onMouseDown={handleCropBoxDragStart}
              >
                {/* Rule of thirds lines inside the crop box */}
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                  <div className="border-b border-r border-white/40" />
                  <div className="border-b border-r border-white/40" />
                  <div className="border-b border-white/40" />
                  <div className="border-b border-r border-white/40" />
                  <div className="border-b border-r border-white/40" />
                  <div className="border-b border-white/40" />
                  <div className="border-r border-white/40" />
                  <div className="border-r border-white/40" />
                  <div />
                </div>

                {/* Corner Resizing Handles */}
                {/* Top-Left */}
                <div
                  className="absolute -top-1.5 -left-1.5 w-4 h-4 border-t-4 border-l-4 border-indigo-400 cursor-nwse-resize z-40"
                  onMouseDown={(e) => handleCropResizeStart(e, 'nw')}
                />
                {/* Top-Right */}
                <div
                  className="absolute -top-1.5 -right-1.5 w-4 h-4 border-t-4 border-r-4 border-indigo-400 cursor-nesw-resize z-40"
                  onMouseDown={(e) => handleCropResizeStart(e, 'ne')}
                />
                {/* Bottom-Left */}
                <div
                  className="absolute -bottom-1.5 -left-1.5 w-4 h-4 border-b-4 border-l-4 border-indigo-400 cursor-nesw-resize z-40"
                  onMouseDown={(e) => handleCropResizeStart(e, 'sw')}
                />
                {/* Bottom-Right */}
                <div
                  className="absolute -bottom-1.5 -right-1.5 w-4 h-4 border-b-4 border-r-4 border-indigo-400 cursor-nwse-resize z-40"
                  onMouseDown={(e) => handleCropResizeStart(e, 'se')}
                />

                {/* Edge Resizing Handles (only for custom presets) */}
                {activePresetId === 'preset-custom' && (
                  <>
                    {/* Top */}
                    <div
                      className="absolute -top-1.5 left-4 right-4 h-3 cursor-n-resize z-40"
                      onMouseDown={(e) => handleCropResizeStart(e, 'n')}
                    />
                    {/* Bottom */}
                    <div
                      className="absolute -bottom-1.5 left-4 right-4 h-3 cursor-s-resize z-40"
                      onMouseDown={(e) => handleCropResizeStart(e, 's')}
                    />
                    {/* Left */}
                    <div
                      className="absolute top-4 bottom-4 -left-1.5 w-3 cursor-w-resize z-40"
                      onMouseDown={(e) => handleCropResizeStart(e, 'w')}
                    />
                    {/* Right */}
                    <div
                      className="absolute top-4 bottom-4 -right-1.5 w-3 cursor-e-resize z-40"
                      onMouseDown={(e) => handleCropResizeStart(e, 'e')}
                    />
                  </>
                )}
              </div>
            )}

            {/* Draggable Interactive Text Layers */}
            {textLayers.map((layer) => {
              const fontClasses = {
                sans: 'font-sans',
                mono: 'font-mono',
                serif: 'font-serif',
              }[layer.fontFamily];

              return (
                <div
                  key={layer.id}
                  onMouseDown={(e) => handleStartDrag(e, layer.id, 'text', layer.x, layer.y)}
                  style={{
                    left: `${layer.x}%`,
                    top: `${layer.y}%`,
                    color: layer.color,
                    fontSize: `${layer.fontSize}px`,
                    transform: 'translate(-50%, -50%)',
                  }}
                  className={`absolute z-10 cursor-move whitespace-nowrap select-none hover:ring-2 hover:ring-indigo-500 hover:ring-offset-2 hover:ring-offset-black/40 rounded px-1.5 py-0.5 transition-shadow ${fontClasses} font-bold drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] flex items-center space-x-1 group`}
                >
                  <Move className="w-3 h-3 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span>{layer.text}</span>
                </div>
              );
            })}

            {/* Draggable Shape Element Layers */}
            {elementLayers.map((layer) => {
              const rotation = layer.rotation || 0;
              const opacity = layer.opacity !== undefined ? layer.opacity : 1;

              return (
                <div
                  key={layer.id}
                  onMouseDown={(e) => handleStartDrag(e, layer.id, 'element', layer.x, layer.y)}
                  style={{
                    left: `${layer.x}%`,
                    top: `${layer.y}%`,
                    transform: `translate(-50%, -50%) rotate(${rotation}deg)`,
                    opacity: opacity,
                  }}
                  className="absolute z-10 cursor-move hover:ring-2 hover:ring-indigo-500 hover:ring-offset-2 hover:ring-offset-black/40 rounded p-1 transition-shadow flex items-center justify-center group"
                >
                  <div className="absolute -top-4 bg-indigo-600 text-white text-[8px] font-semibold px-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity uppercase">
                    drag shape
                  </div>
                  {renderShapeElement(layer)}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Workspace float tools overlay */}
      <div className="absolute bottom-28 left-1/2 -translate-x-1/2 bg-slate-900/95 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/10 flex items-center space-x-4 text-white shrink-0 z-10 shadow-xl">
        <button
          onClick={handleZoomOut}
          className="p-1 hover:text-indigo-400 transition-colors cursor-pointer"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <span className="text-xs font-mono font-semibold w-12 text-center select-none">
          {zoomLevel}%
        </span>
        <button
          onClick={handleZoomIn}
          className="p-1 hover:text-indigo-400 transition-colors cursor-pointer"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <div className="w-px h-4 bg-white/20" />
        <button
          onClick={onToggleGridLines}
          className={`p-1 transition-colors cursor-pointer ${
            gridLinesVisible ? 'text-indigo-400' : 'text-white/60 hover:text-white'
          }`}
          title="Toggle Rule of Thirds Grid"
        >
          <Grid className="w-4 h-4" />
        </button>
      </div>
    </main>
  );
}

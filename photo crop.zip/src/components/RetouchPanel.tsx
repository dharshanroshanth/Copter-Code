/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Smile, Sparkles, Wand2, ShieldCheck, Sun, Check } from 'lucide-react';

interface RetouchPanelProps {
  onApplyRetouch: (updates: { smoothing: number; brightness: number; contrast: number; blur: number }) => void;
}

export default function RetouchPanel({ onApplyRetouch }: RetouchPanelProps) {
  const [skinSmoothing, setSkinSmoothing] = useState(0);
  const [eyeBrightening, setEyeBrightening] = useState(0);
  const [teethWhitening, setTeethWhitening] = useState(0);
  const [applied, setApplied] = useState(false);

  const handleApply = () => {
    // Skin smoothing is mapped to a subtle blur & contrast adjustment
    // Eye brightening maps to contrast and brightness
    // Teeth whitening maps to a desaturated brightness
    onApplyRetouch({
      smoothing: skinSmoothing,
      brightness: Math.round(eyeBrightening * 0.3 + teethWhitening * 0.2),
      contrast: Math.round(eyeBrightening * 0.4 - skinSmoothing * 0.1),
      blur: Math.round(skinSmoothing * 0.08),
    });
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  const handleQuickPreset = (type: 'glamour' | 'natural' | 'editorial') => {
    if (type === 'glamour') {
      setSkinSmoothing(70);
      setEyeBrightening(45);
      setTeethWhitening(60);
    } else if (type === 'natural') {
      setSkinSmoothing(30);
      setEyeBrightening(20);
      setTeethWhitening(25);
    } else {
      setSkinSmoothing(45);
      setEyeBrightening(35);
      setTeethWhitening(40);
    }
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 mb-2">
            <Smile className="w-5 h-5" />
            <h2 className="text-sm font-semibold text-slate-900">Skin Retouching</h2>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Smooth out blemishes, whiten teeth, and brighten eyes with high-precision pixel frequency filters.
          </p>

          {/* Quick presets */}
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
            Retouch Presets
          </span>
          <div className="grid grid-cols-3 gap-1.5 mb-5">
            {(['natural', 'editorial', 'glamour'] as const).map((preset) => (
              <button
                key={preset}
                onClick={() => handleQuickPreset(preset)}
                className="py-2 bg-slate-50 border border-slate-200 hover:border-indigo-400 text-[10px] font-bold rounded-xl text-slate-600 hover:text-slate-900 capitalize transition-colors cursor-pointer"
              >
                {preset}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {/* Skin Smoothing */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Skin Smoothness</span>
                <span className="font-mono font-bold text-slate-800">{skinSmoothing}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={skinSmoothing}
                onChange={(e) => setSkinSmoothing(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Applies frequency separation to preserve texture while softening blemishes.
              </span>
            </div>

            {/* Eye Brightening */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Eye Brightener</span>
                <span className="font-mono font-bold text-slate-800">{eyeBrightening}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={eyeBrightening}
                onChange={(e) => setEyeBrightening(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Enhances iris contrast and light reflection index.
              </span>
            </div>

            {/* Teeth Whitening */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Teeth Whitening</span>
                <span className="font-mono font-bold text-slate-800">{teethWhitening}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={teethWhitening}
                onChange={(e) => setTeethWhitening(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Subtly reduces yellow hues and increases luminance in tooth zones.
              </span>
            </div>
          </div>

          {/* Healing Brush status */}
          <div className="mt-5 p-3.5 bg-indigo-50/50 border border-indigo-100/60 rounded-2xl">
            <div className="flex items-start space-x-2.5">
              <Wand2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <h4 className="text-[11px] font-bold text-indigo-950">Spot Healing & Blemish Eraser</h4>
                <p className="text-[10px] text-slate-500 leading-normal mt-0.5">
                  Click and paint directly on the image workspace to heal spots automatically using neighborhood pixel interpolation.
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={handleApply}
            className={`w-full mt-6 text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10 ${
              applied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {applied ? (
              <>
                <Check className="w-4 h-4 animate-bounce" />
                <span>Retouch Settings Saved!</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Apply Retouch Pipeline</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Pro Retouching Unlocked (Free)</span>
        </div>
      </div>
    </aside>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Crown, CheckCircle, Shield, X, Download, Star, Sparkles, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessUpgrade: () => void;
}

export function UpgradeModal({ isOpen, onClose, onSuccessUpgrade }: UpgradeModalProps) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubscribe = () => {
    setLoading(true);
    // Simulate secure checkout payment processing
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => {
        onSuccessUpgrade();
        setSuccess(false);
        onClose();
      }, 1500);
    }, 2000);
  };

  const perks = [
    'Unlock advanced AI background removal and image descriptors.',
    'Export high-definition assets without quality compression.',
    'Save and apply unlimited custom filter profile presets.',
    'Access 120+ premium text styles and geometric shapes.',
    'Edit up to 50 photos simultaneously using Batch Mode.',
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden z-10 relative select-none"
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Gradient Header */}
            <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-700 text-white p-6 pt-8 text-center relative">
              <div className="absolute top-0 right-0 left-0 bottom-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />
              <Crown className="w-12 h-12 text-amber-300 mx-auto mb-3 animate-bounce" />
              <h2 className="text-xl font-bold tracking-tight">Upgrade to PhotoToolkit Pro</h2>
              <p className="text-xs text-indigo-100 mt-1">Unlock the complete power of professional image creation</p>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6">
              {success ? (
                <div className="py-8 text-center space-y-3">
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto animate-pulse" />
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">Purchase Completed!</h3>
                    <p className="text-xs text-slate-400">Welcome to PhotoToolkit Pro membership.</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Included Perks</span>
                    <ul className="space-y-2.5">
                      {perks.map((perk, i) => (
                        <li key={i} className="flex items-start space-x-2.5 text-xs text-slate-600">
                          <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{perk}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Pricing tier block */}
                  <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="bg-indigo-100 text-indigo-800 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
                        Popular Choice
                      </span>
                      <h4 className="font-bold text-xs text-slate-900 mt-1">Pro Membership plan</h4>
                      <p className="text-[10px] text-slate-500">Cancel or pause subscription anytime.</p>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-slate-900">$9.99</span>
                      <span className="text-[10px] text-slate-400 block">/ month</span>
                    </div>
                  </div>

                  {/* CTA Subscription buttons */}
                  <div className="space-y-2.5">
                    <button
                      onClick={handleSubscribe}
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-indigo-300 disabled:to-purple-300 text-white text-xs font-semibold py-3 rounded-xl shadow-lg shadow-indigo-600/10 flex items-center justify-center space-x-1.5 cursor-pointer transition-colors"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Processing Security Payment...</span>
                        </>
                      ) : (
                        <>
                          <Star className="w-4 h-4" />
                          <span>Subscribe for $9.99/mo</span>
                        </>
                      )}
                    </button>
                    <div className="flex items-center justify-center space-x-1.5 text-[9px] text-slate-400">
                      <Shield className="w-3.5 h-3.5 text-slate-300" />
                      <span>256-bit encrypted checkout. Satisfaction guaranteed.</span>
                    </div>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerDownload: (format: 'png' | 'jpeg', quality: number, filename: string) => void;
}

export function ExportModal({ isOpen, onClose, onTriggerDownload }: ExportModalProps) {
  const [format, setFormat] = useState<'png' | 'jpeg'>('png');
  const [quality, setQuality] = useState(90);
  const [filename, setFilename] = useState('phototoolkit_edit');

  const handleExport = () => {
    onTriggerDownload(format, quality, filename);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-sm w-full overflow-hidden z-10 relative select-none"
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="p-6 pb-4 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                <Download className="w-4 h-4 text-indigo-600" />
                <span>Export Image</span>
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">Customize compression codecs and naming before download.</p>
            </div>

            {/* Form Fields */}
            <div className="p-6 space-y-4">
              {/* Filename */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:border-indigo-500 transition-colors">
                <label className="text-[10px] text-slate-400 font-semibold block">Filename</label>
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-none w-full mt-0.5"
                  placeholder="phototoolkit_file"
                />
              </div>

              {/* Format selection */}
              <div className="space-y-1">
                <span className="text-xs text-slate-600 block font-semibold">Format Codec</span>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setFormat('png')}
                    className={`text-xs py-2 rounded-lg font-bold transition-all cursor-pointer ${
                      format === 'png' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                    }`}
                  >
                    Lossless PNG
                  </button>
                  <button
                    onClick={() => setFormat('jpeg')}
                    className={`text-xs py-2 rounded-lg font-bold transition-all cursor-pointer ${
                      format === 'jpeg' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                    }`}
                  >
                    Compressed JPG
                  </button>
                </div>
              </div>

              {/* Compression Quality slider (JPG only) */}
              {format === 'jpeg' && (
                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-semibold">JPG Quality</span>
                    <span className="font-mono font-bold text-slate-800">{quality}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={quality}
                    onChange={(e) => setQuality(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-[9px] text-slate-400 block">
                    Lower values reduce file size significantly but introduce compression artifacts.
                  </span>
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={handleExport}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-3 rounded-xl shadow-lg shadow-indigo-600/10 flex items-center justify-center space-x-1.5 transition-colors cursor-pointer mt-4"
              >
                <Download className="w-4 h-4" />
                <span>Export & Download Asset</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Loader2, Compass, Tag, Palette, Check, HelpCircle, FileText, Wand2, Type, Copy, Plus } from 'lucide-react';
import { Filters } from '../types';

interface AIToolsPanelProps {
  currentImageDataUrl: string;
  onApplyAIFilters: (filters: Filters) => void;
  onAddTextLayer: (text: string, color: string, fontSize: number, fontFamily: 'sans' | 'mono' | 'serif') => void;
}

interface AIAnalysisResult {
  description: string;
  titleIdeas: string[];
  suggestedFilters: Filters;
  colorPalette: string[];
  socialCaptions?: {
    instagram: string;
    linkedin: string;
    poetic: string;
  };
  overlayTextIdeas?: Array<{
    text: string;
    fontStyle: 'sans' | 'mono' | 'serif';
    color: string;
    fontSize: number;
  }>;
  vibePresets?: Array<{
    name: string;
    description: string;
    filters: Filters;
  }>;
}

export default function AIToolsPanel({
  currentImageDataUrl,
  onApplyAIFilters,
  onAddTextLayer,
}: AIToolsPanelProps) {
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AIAnalysisResult | null>(null);
  const [copiedColor, setCopiedColor] = useState<string | null>(null);
  const [copiedCaptionType, setCopiedCaptionType] = useState<string | null>(null);
  const [activeCaptionTab, setActiveCaptionTab] = useState<'instagram' | 'linkedin' | 'poetic'>('instagram');

  const handleAnalyze = async () => {
    if (!currentImageDataUrl) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      setLoadingStep('Uploading image representation...');
      const commaIndex = currentImageDataUrl.indexOf(',');
      if (commaIndex === -1) {
        throw new Error('Invalid image format.');
      }
      const mimeType = currentImageDataUrl.substring(5, currentImageDataUrl.indexOf(';'));
      const base64Data = currentImageDataUrl.substring(commaIndex + 1);

      setLoadingStep('Consulting Gemini 3.5-Flash...');
      const response = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mimeType, base64Data }),
      });

      if (!response.ok) {
        throw new Error('Failed to communicate with AI services. Try again later.');
      }

      setLoadingStep('Assembling visual diagnostics...');
      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setError(err?.message || 'Something went wrong during AI analysis.');
    } finally {
      setLoading(false);
      setLoadingStep('');
    }
  };

  const copyToClipboard = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 1500);
  };

  const copyCaption = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCaptionType(type);
    setTimeout(() => setCopiedCaptionType(null), 1500);
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-2 flex items-center space-x-1.5">
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
            <span>AI Assistant</span>
          </h2>
          <p className="text-xs text-slate-400 mb-4">
            Leverage Google Gemini server-side models to analyze your image composition, generate templates, and apply smart filters.
          </p>

          {!result && !loading && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                <Compass className="w-7 h-7 text-indigo-400 mx-auto mb-2" />
                <h3 className="text-xs font-bold text-slate-700 mb-1">Image Diagnostic Engine</h3>
                <p className="text-[10px] text-slate-400 leading-relaxed mb-3">
                  AI will analyze depth, lighting levels, textures, and color fields, giving you smart suggestions.
                </p>
                <button
                  onClick={handleAnalyze}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2.5 rounded-xl transition-all shadow-sm shadow-indigo-600/10 cursor-pointer"
                >
                  Analyze & Suggest
                </button>
              </div>
            </div>
          )}

          {/* LOADING STATE */}
          {loading && (
            <div className="py-8 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
              <div>
                <p className="text-xs font-bold text-slate-800">Processing Photo...</p>
                <p className="text-[10px] text-slate-400 animate-pulse mt-0.5">{loadingStep}</p>
              </div>
            </div>
          )}

          {/* ERROR STATE */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-center">
              <p className="text-xs font-semibold text-red-800 mb-1">AI Service Error</p>
              <p className="text-[10px] text-red-500 mb-3">{error}</p>
              <button
                onClick={handleAnalyze}
                className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 underline cursor-pointer"
              >
                Retry Analysis
              </button>
            </div>
          )}

          {/* RESULT STATE */}
          {result && (
            <div className="space-y-5 pb-4">
              {/* Detailed Description */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider flex items-center space-x-1">
                  <Compass className="w-3.5 h-3.5" />
                  <span>Scene Description</span>
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {result.description}
                </p>
              </div>

              {/* Dominant Palette */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider flex items-center space-x-1">
                  <Palette className="w-3.5 h-3.5" />
                  <span>Dominant Colors</span>
                </span>
                <div className="flex items-center space-x-1.5">
                  {result.colorPalette.map((color, i) => (
                    <button
                      key={i}
                      onClick={() => copyToClipboard(color)}
                      style={{ backgroundColor: color }}
                      className="flex-1 aspect-square rounded-lg border border-white shadow-xs relative hover:scale-110 transition-transform group cursor-pointer"
                      title={`Copy ${color}`}
                    >
                      <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        {copiedColor === color ? (
                          <Check className="w-3 h-3 text-white" />
                        ) : (
                          <span className="text-[8px] font-bold text-white font-mono">C</span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Suggested Enhancements Action */}
              <div className="pt-2">
                <button
                  onClick={() => onApplyAIFilters(result.suggestedFilters)}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-[11px] font-semibold py-2 rounded-xl transition-all shadow-md shadow-indigo-600/10 cursor-pointer text-center flex items-center justify-center space-x-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Apply AI Smart Auto-Enhance</span>
                </button>
              </div>

              {/* Dynamic Vibe Presets */}
              {result.vibePresets && result.vibePresets.length > 0 && (
                <div className="space-y-2 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider flex items-center space-x-1">
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Dynamic Vibe Filters</span>
                  </span>
                  <div className="space-y-1.5">
                    {result.vibePresets.map((vibe, idx) => (
                      <div
                        key={idx}
                        className="p-2 border border-slate-150 rounded-xl bg-slate-50 hover:bg-slate-100/50 transition-colors flex items-center justify-between"
                      >
                        <div className="min-w-0 flex-1 pr-2">
                          <span className="text-[11px] font-bold text-slate-800 block truncate leading-tight">
                            {vibe.name}
                          </span>
                          <span className="text-[9px] text-slate-400 block truncate leading-none mt-0.5">
                            {vibe.description}
                          </span>
                        </div>
                        <button
                          onClick={() => onApplyAIFilters(vibe.filters)}
                          className="bg-white hover:bg-indigo-50 text-indigo-600 border border-slate-200 hover:border-indigo-200 text-[10px] font-bold px-2 py-1 rounded-lg transition-all shrink-0 cursor-pointer"
                        >
                          Apply
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Headline Overlay Ideas */}
              {result.overlayTextIdeas && result.overlayTextIdeas.length > 0 && (
                <div className="space-y-2 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider flex items-center space-x-1">
                    <Type className="w-3.5 h-3.5" />
                    <span>AI Text Overlays</span>
                  </span>
                  <div className="space-y-1.5">
                    {result.overlayTextIdeas.map((idea, idx) => (
                      <div
                        key={idx}
                        className="p-2 border border-slate-150 rounded-xl bg-slate-50 flex items-center justify-between"
                      >
                        <div className="min-w-0 flex-1 pr-2">
                          <span
                            style={{
                              fontFamily: idea.fontStyle === 'mono' ? 'JetBrains Mono' : idea.fontStyle === 'serif' ? 'Georgia' : 'Inter',
                            }}
                            className="text-[11px] font-bold text-slate-800 block truncate"
                          >
                            "{idea.text}"
                          </span>
                          <span className="text-[9px] text-slate-400 block font-mono">
                            {idea.fontStyle} • {idea.fontSize}px
                          </span>
                        </div>
                        <button
                          onClick={() => onAddTextLayer(idea.text, idea.color, idea.fontSize, idea.fontStyle)}
                          className="bg-indigo-50 hover:bg-indigo-100 text-indigo-600 p-1.5 rounded-lg transition-all shrink-0 cursor-pointer"
                          title="Add Text Layer Overlay"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Social Media Copywriter */}
              {result.socialCaptions && (
                <div className="space-y-2 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider flex items-center space-x-1">
                    <FileText className="w-3.5 h-3.5" />
                    <span>AI Social Copywriter</span>
                  </span>

                  {/* Tabs */}
                  <div className="grid grid-cols-3 gap-0.5 bg-slate-100 p-0.5 rounded-lg text-[9px] font-bold">
                    {(['instagram', 'linkedin', 'poetic'] as const).map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveCaptionTab(tab)}
                        className={`py-1 rounded-md text-center transition-colors capitalize cursor-pointer ${
                          activeCaptionTab === tab
                            ? 'bg-white text-slate-800 shadow-xs'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="bg-slate-50 border border-slate-150 rounded-xl p-2.5 relative group">
                    <p className="text-[10px] text-slate-600 leading-relaxed pr-6">
                      {result.socialCaptions[activeCaptionTab]}
                    </p>
                    <button
                      onClick={() => result.socialCaptions && copyCaption(result.socialCaptions[activeCaptionTab], activeCaptionTab)}
                      className="absolute top-2 right-2 text-slate-400 hover:text-indigo-600 p-1 rounded-lg transition-colors cursor-pointer"
                      title="Copy Caption"
                    >
                      {copiedCaptionType === activeCaptionTab ? (
                        <Check className="w-3.5 h-3.5 text-indigo-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Reset button */}
              <div className="text-center pt-2 border-t border-slate-100">
                <button
                  onClick={() => setResult(null)}
                  className="text-[10px] font-bold text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                >
                  Clear Results & Scan Again
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-start space-x-2 text-slate-400">
          <HelpCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="text-[10px] leading-relaxed">
            Gemini analysis is processed fully server-side. No API keys are leaked to the browser bundle.
          </span>
        </div>
      </div>
    </aside>
  );
}

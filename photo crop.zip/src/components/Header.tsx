/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Undo,
  Redo,
  CheckCircle,
  Crown,
  Download,
  Share2,
  ChevronDown,
  ArrowLeft,
  Image as ImageIcon,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onDownload: (format: 'png' | 'jpeg') => void;
  onOpenExport: () => void;
}

export default function Header({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onDownload,
  onOpenExport,
}: HeaderProps) {
  const [downloadOpen, setDownloadOpen] = useState(false);

  return (
    <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-4 z-20 shrink-0 select-none">
      {/* Left side: branding & sub-text */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className="bg-indigo-600 text-white p-2 rounded-xl shadow-md shadow-indigo-600/10">
            <ImageIcon className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tight text-slate-900">
            PhotoToolkit
          </span>
        </div>
        <div className="h-6 w-px bg-slate-200" />
        <div className="flex flex-col">
          <div className="flex items-center space-x-1">
            <button className="text-slate-400 hover:text-slate-800 transition-colors">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <span className="font-semibold text-sm text-slate-900">Editor</span>
          </div>
          <span className="text-xs text-slate-400">
            Professional editing made simple
          </span>
        </div>
      </div>

      {/* Middle side: undo, redo, and state indicator */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className={`p-1.5 rounded transition ${
              canUndo
                ? 'text-slate-600 hover:text-slate-950 hover:bg-white cursor-pointer'
                : 'text-slate-300 cursor-not-allowed'
            }`}
            title="Undo"
          >
            <Undo className="w-4 h-4" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className={`p-1.5 rounded transition ${
              canRedo
                ? 'text-slate-600 hover:text-slate-950 hover:bg-white cursor-pointer'
                : 'text-slate-300 cursor-not-allowed'
            }`}
            title="Redo"
          >
            <Redo className="w-4 h-4" />
          </button>
        </div>
        <div className="flex items-center text-xs text-slate-500 space-x-1">
          <CheckCircle className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span className="font-medium text-slate-600">Saved</span>
        </div>
      </div>

      {/* Right side: download dropdown, and export CTA */}
      <div className="flex items-center space-x-3">
        {/* Download Trigger */}
        <div className="relative">
          <div className="inline-flex rounded-lg shadow-xs">
            <button
              onClick={() => onDownload('png')}
              className="inline-flex items-center space-x-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-l-lg transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PNG</span>
            </button>
            <button
              onClick={() => setDownloadOpen(!downloadOpen)}
              className="bg-white hover:bg-slate-50 border-y border-r border-slate-200 px-2 rounded-r-lg flex items-center text-slate-500 cursor-pointer"
            >
              <ChevronDown className="w-3 h-3" />
            </button>
          </div>

          <AnimatePresence>
            {downloadOpen && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={() => setDownloadOpen(false)}
                />
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 5 }}
                  className="absolute right-0 mt-1 w-40 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-30 overflow-hidden"
                >
                  <button
                    onClick={() => {
                      onDownload('png');
                      setDownloadOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center justify-between cursor-pointer"
                  >
                    <span>Lossless PNG</span>
                    <span className="text-[9px] text-slate-400">High Res</span>
                  </button>
                  <button
                    onClick={() => {
                      onDownload('jpeg');
                      setDownloadOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center justify-between cursor-pointer"
                  >
                    <span>Compressed JPG</span>
                    <span className="text-[9px] text-slate-400">Smaller</span>
                  </button>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* Export Button */}
        <button
          onClick={onOpenExport}
          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center space-x-1.5 shadow-sm shadow-indigo-600/10 transition-colors cursor-pointer"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
}

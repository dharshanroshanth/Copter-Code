/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Eye, ShieldCheck } from 'lucide-react';
import { Filters } from '../types';

interface FiltersPanelProps {
  onApplyPreset: (presetFilters: Filters) => void;
}

interface FilterPreset {
  name: string;
  description: string;
  icon: string;
  filters: Filters;
}

const PRESETS: FilterPreset[] = [
  {
    name: 'Original',
    description: 'No filters applied. Clear and clean.',
    icon: '🖼️',
    filters: { brightness: 0, contrast: 0, saturation: 0, tint: 0, blur: 0 },
  },
  {
    name: 'Nordic Cold',
    description: 'Crisp blue highlights with balanced saturation.',
    icon: '❄️',
    filters: { brightness: 5, contrast: 10, saturation: -20, tint: -25, blur: 0 },
  },
  {
    name: 'Warm Sun',
    description: 'Golden hour tones, rich colors, sunny vibes.',
    icon: '☀️',
    filters: { brightness: 5, contrast: 5, saturation: 30, tint: 15, blur: 0 },
  },
  {
    name: 'Dramatic Noir',
    description: 'High-contrast monochrome classic.',
    icon: '🕶️',
    filters: { brightness: -5, contrast: 40, saturation: -100, tint: 0, blur: 0 },
  },
  {
    name: 'Sepia Vintage',
    description: 'Warm, faded, nostalgic retro aesthetic.',
    icon: '📜',
    filters: { brightness: -5, contrast: -10, saturation: -15, tint: 20, blur: 2 },
  },
  {
    name: 'Teal & Orange',
    description: 'The iconic blockbuster movie color scheme.',
    icon: '🎬',
    filters: { brightness: 0, contrast: 25, saturation: 20, tint: -10, blur: 0 },
  },
  {
    name: 'Cyberpunk Neon',
    description: 'High saturation hot pink and electric blue tones.',
    icon: '🔮',
    filters: { brightness: 10, contrast: 15, saturation: 60, tint: 85, blur: 0 },
  },
  {
    name: 'Soft Dream',
    description: 'Bright, pastel-toned hazy filter.',
    icon: '☁️',
    filters: { brightness: 15, contrast: -15, saturation: -5, tint: 5, blur: 10 },
  },
];

export default function FiltersPanel({ onApplyPreset }: FiltersPanelProps) {
  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-2">Artistic Filters</h2>
          <p className="text-xs text-slate-400 mb-4">
            Select an aesthetic profile to instantly change the tone of your photo.
          </p>

          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Presets List
          </span>

          <div className="space-y-3">
            {PRESETS.map((preset) => (
              <button
                key={preset.name}
                onClick={() => onApplyPreset(preset.filters)}
                className="w-full flex items-center space-x-3.5 p-3 rounded-xl border border-slate-200 hover:border-indigo-500 hover:bg-slate-50/50 text-left transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-lg group-hover:scale-110 transition-transform shrink-0">
                  {preset.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xs font-bold text-slate-800 truncate group-hover:text-indigo-600 transition-colors">
                    {preset.name}
                  </h3>
                  <p className="text-[10px] text-slate-400 truncate leading-relaxed">
                    {preset.description}
                  </p>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-500 opacity-0 group-hover:opacity-100 transition-all shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">100% Non-destructive Presets</span>
        </div>
      </div>
    </aside>
  );
}

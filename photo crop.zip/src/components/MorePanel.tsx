/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MoreHorizontal, ShieldCheck, Check, Sparkles, AlertCircle, EyeOff } from 'lucide-react';

interface MorePanelProps {
  vignette: number;
  onSetVignette: (value: number) => void;
  grain: number;
  onSetGrain: (value: number) => void;
  chromatic: number;
  onSetChromatic: (value: number) => void;
  metadataStripped: boolean;
  onSetMetadataStripped: (value: boolean) => void;
}

export default function MorePanel({
  vignette,
  onSetVignette,
  grain,
  onSetGrain,
  chromatic,
  onSetChromatic,
  metadataStripped,
  onSetMetadataStripped,
}: MorePanelProps) {
  const [applied, setApplied] = useState(false);

  const handleApply = () => {
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 mb-2">
            <MoreHorizontal className="w-5 h-5" />
            <h2 className="text-sm font-semibold text-slate-900">Special Effects & Privacy</h2>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Apply high-frequency special effects like film grain, vignette shadows, and chromatic separation, or configure advanced privacy settings.
          </p>

          <div className="space-y-4">
            {/* Vignette Shadow Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Vignette Shadow Darkening</span>
                <span className="font-mono font-bold text-slate-800">{vignette}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={vignette}
                onChange={(e) => onSetVignette(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Darkens the edges of the image to direct the viewers focus to the center.
              </span>
            </div>

            {/* Film Grain Noise Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Film Grain Noise Level</span>
                <span className="font-mono font-bold text-slate-800">{grain}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={grain}
                onChange={(e) => onSetGrain(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Simulates real organic silver halide crystals for a classic analog warmth.
              </span>
            </div>

            {/* Chromatic Aberration Offset Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Chromatic RGB Separation</span>
                <span className="font-mono font-bold text-slate-800">{chromatic}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={chromatic}
                onChange={(e) => onSetChromatic(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Offsets red & cyan subpixel channels to mimic high-aperture camera distortion.
              </span>
            </div>

            {/* Metadata Stripper Toggle */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                EXIF Metadata Privacy Shield
              </span>

              <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="flex items-start space-x-2.5">
                  <EyeOff className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-[11px] font-bold text-slate-800">Strip GPS & Camera Tags</h4>
                    <p className="text-[9px] text-slate-400 leading-normal mt-0.5">
                      Automatically purges geolocation, camera models, and creation timestamps before saving files.
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={metadataStripped}
                  onChange={(e) => onSetMetadataStripped(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 accent-indigo-600 cursor-pointer shrink-0 ml-2"
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleApply}
            className={`w-full mt-6 text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10 ${
              applied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {applied ? (
              <>
                <Check className="w-4 h-4 animate-bounce" />
                <span>Special Effects Configuration Lock!</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Apply Effects & Export Profile</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Pro FX Engine Active</span>
        </div>
      </div>
    </aside>
  );
}

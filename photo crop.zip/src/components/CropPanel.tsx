/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RotateCcw, FlipVertical, FlipHorizontal, Lock, Unlock, ChevronDown } from 'lucide-react';
import { CROP_PRESETS } from '../constants';

interface CropPanelProps {
  activePresetId: string;
  onSetPresetId: (id: string) => void;
  rotation: number;
  onSetRotation: (deg: number) => void;
  flipH: boolean;
  onSetFlipH: (val: boolean) => void;
  flipV: boolean;
  onSetFlipV: (val: boolean) => void;
  originalWidth: number;
  originalHeight: number;
  resizeWidth: number;
  resizeHeight: number;
  onSetResizeDimensions: (w: number, h: number) => void;
  onApplyCrop: () => void;
  cropPercent: { x: number; y: number; w: number; h: number };
}

export default function CropPanel({
  activePresetId,
  onSetPresetId,
  rotation,
  onSetRotation,
  flipH,
  onSetFlipH,
  flipV,
  onSetFlipV,
  originalWidth,
  originalHeight,
  resizeWidth,
  resizeHeight,
  onSetResizeDimensions,
  onApplyCrop,
  cropPercent,
}: CropPanelProps) {
  const [aspectLocked, setAspectLocked] = useState(true);
  const [resizeUnit, setResizeUnit] = useState<'px' | '%'>('px');

  // Compute the current crop boundary's base pixel size (before custom sizing factor is applied)
  const croppedBaseWidth = Math.max(1, Math.round((cropPercent.w / 100) * (originalWidth || 1920)));
  const croppedBaseHeight = Math.max(1, Math.round((cropPercent.h / 100) * (originalHeight || 1080)));

  // Display-ready values
  const currentScalePercent = croppedBaseWidth > 0 ? Math.round((resizeWidth / croppedBaseWidth) * 100) : 100;
  const currentPercentW = croppedBaseWidth > 0 ? Math.round((resizeWidth / croppedBaseWidth) * 100) : 100;
  const currentPercentH = croppedBaseHeight > 0 ? Math.round((resizeHeight / croppedBaseHeight) * 100) : 100;

  // Manual pixel-value changes
  const handleWidthChange = (val: number) => {
    if (isNaN(val) || val <= 0) {
      onSetResizeDimensions(0, resizeHeight);
      return;
    }
    if (aspectLocked) {
      const ratio = croppedBaseHeight / croppedBaseWidth;
      const calculatedHeight = Math.max(1, Math.round(val * ratio));
      onSetResizeDimensions(val, calculatedHeight);
    } else {
      onSetResizeDimensions(val, resizeHeight);
    }
  };

  const handleHeightChange = (val: number) => {
    if (isNaN(val) || val <= 0) {
      onSetResizeDimensions(resizeWidth, 0);
      return;
    }
    if (aspectLocked) {
      const ratio = croppedBaseWidth / croppedBaseHeight;
      const calculatedWidth = Math.max(1, Math.round(val * ratio));
      onSetResizeDimensions(calculatedWidth, val);
    } else {
      onSetResizeDimensions(resizeWidth, val);
    }
  };

  // Manual percentage-value changes
  const handleWidthPercentChange = (val: number) => {
    if (isNaN(val) || val <= 0) {
      onSetResizeDimensions(0, resizeHeight);
      return;
    }
    const targetWidth = Math.max(1, Math.round((val / 100) * croppedBaseWidth));
    if (aspectLocked) {
      const targetHeight = Math.max(1, Math.round((val / 100) * croppedBaseHeight));
      onSetResizeDimensions(targetWidth, targetHeight);
    } else {
      onSetResizeDimensions(targetWidth, resizeHeight);
    }
  };

  const handleHeightPercentChange = (val: number) => {
    if (isNaN(val) || val <= 0) {
      onSetResizeDimensions(resizeWidth, 0);
      return;
    }
    const targetHeight = Math.max(1, Math.round((val / 100) * croppedBaseHeight));
    if (aspectLocked) {
      const targetWidth = Math.max(1, Math.round((val / 100) * croppedBaseWidth));
      onSetResizeDimensions(targetWidth, targetHeight);
    } else {
      onSetResizeDimensions(resizeWidth, targetHeight);
    }
  };

  // Percentage slider scale changes
  const handleScalePercentSlider = (val: number) => {
    const targetWidth = Math.max(1, Math.round((val / 100) * croppedBaseWidth));
    const targetHeight = Math.max(1, Math.round((val / 100) * croppedBaseHeight));
    onSetResizeDimensions(targetWidth, targetHeight);
  };

  const handleRotateCcw = () => {
    let nextRotation = rotation - 90;
    if (nextRotation < -180) {
      nextRotation += 360;
    }
    onSetRotation(nextRotation);
  };

  return (
    <section className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-5 flex-1">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-4">Crop & Resize</h2>

          {/* Crop Presets Heading */}
          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Crop Presets
          </span>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {CROP_PRESETS.map((preset) => {
              const isSelected = activePresetId === preset.id;
              
              // Custom graphic representation based on ratio
              let graphic = null;
              if (preset.id === 'preset-custom') {
                graphic = (
                  <div className="w-7 h-7 border border-dashed border-indigo-600 rounded flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <span className="text-[10px] font-bold text-indigo-600 font-mono">✂️</span>
                  </div>
                );
              } else if (preset.id === 'preset-original') {
                graphic = (
                  <div className="w-7 h-7 border border-slate-300 rounded flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <span className="text-[8px] font-bold text-slate-500 font-mono">ORIG</span>
                  </div>
                );
              } else if (preset.id === 'preset-1-1') {
                graphic = (
                  <div className="w-5 h-5 border-2 border-slate-400 rounded-xs mb-2.5 group-hover:scale-105 transition-transform shrink-0" />
                );
              } else if (preset.id === 'preset-16-9') {
                graphic = (
                  <div className="w-7 h-4 border-2 border-slate-400 rounded-xs mb-3 group-hover:scale-105 transition-transform shrink-0" />
                );
              } else if (preset.id === 'preset-4-5') {
                graphic = (
                  <div className="w-5 h-6 border-2 border-slate-400 rounded-xs mb-1.5 group-hover:scale-105 transition-transform shrink-0" />
                );
              } else if (preset.id === 'preset-9-16') {
                graphic = (
                  <div className="w-4 h-7 border-2 border-slate-400 rounded-xs mb-1 group-hover:scale-105 transition-transform shrink-0" />
                );
              }

              return (
                <button
                  key={preset.id}
                  onClick={() => onSetPresetId(preset.id)}
                  className={`crop-preset-btn rounded-xl p-3 flex flex-col items-center justify-center text-center transition-all group cursor-pointer ${
                    isSelected
                      ? 'border-2 border-indigo-600 bg-indigo-50/20'
                      : 'border border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {graphic}
                  <span
                    className={`text-[10px] font-semibold transition-colors ${
                      isSelected ? 'text-indigo-950' : 'text-slate-600'
                    }`}
                  >
                    {preset.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Rotate controls */}
        <div className="pt-2 border-t border-slate-100">
          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Rotate
          </span>
          <div className="flex items-center space-x-3 mb-4">
            <input
              type="range"
              min="-180"
              max="180"
              value={rotation}
              onChange={(e) => onSetRotation(parseInt(e.target.value))}
              className="flex-1 accent-indigo-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-xs font-mono font-semibold text-slate-700 w-10 text-right">
              {rotation}°
            </span>
          </div>

          {/* Quick rotating triggers */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleRotateCcw}
              className="p-2.5 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-xl flex justify-center text-slate-600 transition-colors cursor-pointer"
              title="Rotate 90° CCW"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => onSetFlipV(!flipV)}
              className={`p-2.5 border rounded-xl flex justify-center transition-all cursor-pointer ${
                flipV
                  ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-600'
              }`}
              title="Flip Vertical"
            >
              <FlipVertical className="w-4 h-4" />
            </button>
            <button
              onClick={() => onSetFlipH(!flipH)}
              className={`p-2.5 border rounded-xl flex justify-center transition-all cursor-pointer ${
                flipH
                  ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-600'
              }`}
              title="Flip Horizontal"
            >
              <FlipHorizontal className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Resize dimensions */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex justify-between items-center mb-3">
            <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">
              Resize Dimensions
            </span>
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded uppercase">
              {resizeUnit === 'px' ? 'Pixels' : 'Percent'}
            </span>
          </div>

          <div className="flex items-center space-x-2 mb-3">
            <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:border-indigo-500 transition-colors">
              <label className="text-[10px] text-slate-400 font-semibold block">
                Width
              </label>
              {resizeUnit === 'px' ? (
                <input
                  type="number"
                  value={resizeWidth || ''}
                  onChange={(e) => handleWidthChange(parseInt(e.target.value))}
                  className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none w-full"
                  placeholder="px"
                />
              ) : (
                <input
                  type="number"
                  value={currentPercentW || ''}
                  onChange={(e) => handleWidthPercentChange(parseInt(e.target.value))}
                  className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none w-full"
                  placeholder="%"
                />
              )}
            </div>
            <div className="text-slate-400 text-xs font-semibold">×</div>
            <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:border-indigo-500 transition-colors">
              <label className="text-[10px] text-slate-400 font-semibold block">
                Height
              </label>
              {resizeUnit === 'px' ? (
                <input
                  type="number"
                  value={resizeHeight || ''}
                  onChange={(e) => handleHeightChange(parseInt(e.target.value))}
                  className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none w-full"
                  placeholder="px"
                />
              ) : (
                <input
                  type="number"
                  value={currentPercentH || ''}
                  onChange={(e) => handleHeightPercentChange(parseInt(e.target.value))}
                  className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none w-full"
                  placeholder="%"
                />
              )}
            </div>
            <button
              onClick={() => setAspectLocked(!aspectLocked)}
              className={`p-2.5 border rounded-xl transition-all cursor-pointer ${
                aspectLocked
                  ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                  : 'border-slate-200 text-slate-400 hover:text-slate-700'
              }`}
              title={aspectLocked ? 'Unlock Aspect Ratio' : 'Lock Aspect Ratio'}
            >
              {aspectLocked ? (
                <Lock className="w-4 h-4" />
              ) : (
                <Unlock className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Unit selection */}
          <div className="relative mb-4">
            <select
              value={resizeUnit}
              onChange={(e) => setResizeUnit(e.target.value as 'px' | '%')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 appearance-none focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="px">pixels (px)</option>
              <option value="%">percentage (%)</option>
            </select>
            <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>

          {/* Quick scale slider */}
          <div className="bg-slate-50/50 rounded-xl p-3 border border-slate-100 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500">
              <span>Quick Scale Factor</span>
              <span className="font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">
                {currentScalePercent}%
              </span>
            </div>
            <input
              type="range"
              min="10"
              max="200"
              value={currentScalePercent}
              onChange={(e) => handleScalePercentSlider(parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
            />
            <div className="grid grid-cols-6 gap-1 pt-1">
              {[25, 50, 75, 100, 150, 200].map((pct) => (
                <button
                  key={pct}
                  onClick={() => handleScalePercentSlider(pct)}
                  className={`py-1 rounded text-[9px] font-bold border transition-all cursor-pointer ${
                    currentScalePercent === pct
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200/80'
                  }`}
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>

          {/* Resolution Breakdown Summary */}
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-200/60 mt-3 space-y-2">
            <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">
              Resolution Breakdown
            </span>
            <div className="space-y-1 text-xs text-slate-600">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-[10px]">Original</span>
                <span className="font-mono font-medium">{originalWidth || '—'} × {originalHeight || '—'} px</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-[10px]">Cropped Area</span>
                <span className="font-mono font-medium text-slate-700">{croppedBaseWidth} × {croppedBaseHeight} px</span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-slate-200/50">
                <span className="text-slate-900 font-medium text-[10px]">Final Size</span>
                <span className="font-mono font-bold text-indigo-600 bg-indigo-50/50 px-1.5 py-0.5 rounded">
                  {resizeWidth || '—'} × {resizeHeight || '—'} px
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Apply crop button CTA */}
      <div className="p-5 border-t border-slate-100 shrink-0 bg-slate-50/50">
        <button
          onClick={onApplyCrop}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-3 rounded-xl shadow-lg shadow-indigo-600/10 transition-colors cursor-pointer"
        >
          Apply Crop & Resize
        </button>
      </div>
    </section>
  );
}

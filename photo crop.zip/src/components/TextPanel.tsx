/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Type, Plus, Trash2, AlignLeft, HelpCircle } from 'lucide-react';
import { TextLayer } from '../types';

interface TextPanelProps {
  layers: TextLayer[];
  onAddLayer: (text: string, color: string, fontSize: number, fontFamily: 'sans' | 'mono' | 'serif') => void;
  onUpdateLayer: (id: string, updates: Partial<TextLayer>) => void;
  onRemoveLayer: (id: string) => void;
}

const COLOR_SWATCHES = [
  '#ffffff', // White
  '#000000', // Black
  '#4f46e5', // Indigo
  '#ef4444', // Red
  '#10b981', // Green
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#06b6d4', // Cyan
  '#8b5cf6', // Violet
];

export default function TextPanel({
  layers,
  onAddLayer,
  onUpdateLayer,
  onRemoveLayer,
}: TextPanelProps) {
  const [inputText, setInputText] = useState('My Headline');
  const [selectedColor, setSelectedColor] = useState('#ffffff');
  const [fontSize, setFontSize] = useState(32);
  const [fontFamily, setFontFamily] = useState<'sans' | 'mono' | 'serif'>('sans');

  const handleAdd = () => {
    if (!inputText.trim()) return;
    onAddLayer(inputText, selectedColor, fontSize, fontFamily);
    setInputText('');
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-2">Text Overlay</h2>
          <p className="text-xs text-slate-400 mb-4">
            Place custom text labels onto your photo canvas. Drag items in the workspace.
          </p>

          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Add New Text
          </span>

          <div className="space-y-4">
            {/* Input message */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:border-indigo-500 transition-colors">
              <label className="text-[10px] text-slate-400 font-semibold block">Text Message</label>
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none w-full"
                placeholder="Type something..."
              />
            </div>

            {/* Font Family selector */}
            <div className="space-y-1">
              <span className="text-xs text-slate-600 block font-medium">Font Style</span>
              <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1 rounded-xl">
                {(['sans', 'mono', 'serif'] as const).map((font) => (
                  <button
                    key={font}
                    onClick={() => setFontFamily(font)}
                    className={`text-xs py-1.5 rounded-lg font-semibold transition-all cursor-pointer capitalize ${
                      fontFamily === font
                        ? 'bg-white text-slate-950 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {font === 'sans' ? 'Inter' : font === 'mono' ? 'Mono' : 'Serif'}
                  </button>
                ))}
              </div>
            </div>

            {/* Font Size slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Size</span>
                <span className="font-mono font-semibold text-slate-800">{fontSize}px</span>
              </div>
              <input
                type="range"
                min="12"
                max="120"
                value={fontSize}
                onChange={(e) => setFontSize(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Color Swatches */}
            <div className="space-y-1">
              <span className="text-xs text-slate-600 block font-medium">Color Swatches</span>
              <div className="flex flex-wrap gap-2">
                {COLOR_SWATCHES.map((color) => {
                  const isSelected = selectedColor === color;
                  return (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      style={{ backgroundColor: color }}
                      className={`w-6 h-6 rounded-full border transition-all cursor-pointer hover:scale-110 ${
                        isSelected
                          ? 'border-indigo-600 ring-2 ring-indigo-600/30 ring-offset-2'
                          : 'border-slate-300'
                      }`}
                      title={color}
                    />
                  );
                })}
              </div>
            </div>

            {/* Add trigger */}
            <button
              onClick={handleAdd}
              disabled={!inputText.trim()}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-sm shadow-indigo-600/10"
            >
              <Plus className="w-4 h-4" />
              <span>Add Text</span>
            </button>
          </div>
        </div>

        {/* Existing active layers */}
        {layers.length > 0 && (
          <div className="pt-4 border-t border-slate-100">
            <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
              Active Labels ({layers.length})
            </span>
            <div className="space-y-2 max-h-[160px] overflow-y-auto">
              {layers.map((layer) => (
                <div
                  key={layer.id}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 hover:border-slate-300 transition-all text-xs"
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <input
                      type="text"
                      value={layer.text}
                      onChange={(e) => onUpdateLayer(layer.id, { text: e.target.value })}
                      className="font-bold text-slate-800 bg-transparent focus:outline-none w-full"
                    />
                    <div className="flex items-center space-x-2 text-[10px] text-slate-400 mt-0.5">
                      <span className="capitalize">{layer.fontFamily}</span>
                      <span>•</span>
                      <span>{layer.fontSize}px</span>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveLayer(layer.id)}
                    className="text-slate-400 hover:text-red-500 p-1 rounded-lg transition-colors cursor-pointer"
                    title="Delete Label"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-start space-x-2 text-slate-400">
          <HelpCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="text-[10px] leading-relaxed">
            Double-click or drag text layers in the dark viewport center to customize placement instantly.
          </span>
        </div>
      </div>
    </aside>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Layers, ShieldCheck, Check, Sparkles, Plus, Trash2, Download } from 'lucide-react';
import { Filters } from '../types';

interface BatchPanelProps {
  currentImageDataUrl: string;
  onApplyFiltersToAll: (filters: Filters) => void;
  onAddBatchImage: (dataUrl: string) => void;
  batchImages: string[];
  onRemoveBatchImage: (index: number) => void;
  filters: Filters;
}

export default function BatchPanel({
  currentImageDataUrl,
  onApplyFiltersToAll,
  onAddBatchImage,
  batchImages,
  onRemoveBatchImage,
  filters,
}: BatchPanelProps) {
  const [applied, setApplied] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onAddBatchImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyToAll = () => {
    onApplyFiltersToAll(filters);
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 mb-2">
            <Layers className="w-5 h-5" />
            <h2 className="text-sm font-semibold text-slate-900">Batch Processor</h2>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Edit multiple photos simultaneously. Queue up your campaign assets, synchronize filters/adjustments, and export them as a batch.
          </p>

          {/* Active Queue */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Batch Asset Queue ({batchImages.length + 1})
              </span>

              {/* File input click trigger */}
              <label className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer flex items-center space-x-1">
                <Plus className="w-3 h-3" />
                <span>Add Photos</span>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            <div className="space-y-2 max-h-52 overflow-y-auto">
              {/* Primary Active Image */}
              <div className="flex items-center justify-between p-2 rounded-xl border border-indigo-200 bg-indigo-50/25">
                <div className="flex items-center space-x-2 min-w-0 flex-1">
                  <img
                    src={currentImageDataUrl}
                    alt="Active Canvas"
                    className="w-10 h-10 object-cover rounded-lg border border-indigo-100"
                  />
                  <div className="min-w-0 flex-1">
                    <span className="text-xs font-bold text-slate-800 block truncate">Active Editor Photo</span>
                    <span className="text-[9px] text-indigo-600 block font-semibold">Active Base Canvas</span>
                  </div>
                </div>
                <span className="bg-indigo-100 text-indigo-800 text-[8px] font-bold px-1.5 py-0.5 rounded-md uppercase tracking-wider shrink-0 mr-1.5">
                  Primary
                </span>
              </div>

              {/* Extra queued images */}
              {batchImages.map((img, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 rounded-xl border border-slate-150 hover:border-slate-200"
                >
                  <div className="flex items-center space-x-2 min-w-0 flex-1">
                    <img
                      src={img}
                      alt={`Queue Item ${index + 1}`}
                      className="w-10 h-10 object-cover rounded-lg border border-slate-100"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="text-xs font-semibold text-slate-700 block truncate">Asset_{index + 1}.png</span>
                      <span className="text-[9px] text-slate-400 block font-mono">Status: Awaiting Sync</span>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveBatchImage(index)}
                    className="p-1 text-slate-400 hover:text-red-500 rounded-lg transition-colors cursor-pointer"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Sync Trigger block */}
          <div className="space-y-4 pt-4 border-t border-slate-100 mt-4">
            <div className="p-3.5 bg-indigo-50/40 border border-indigo-100 rounded-2xl">
              <h4 className="text-[11px] font-bold text-indigo-950 mb-1">Active Synchronization Parameters</h4>
              <p className="text-[10px] text-slate-500 leading-normal">
                Synchronizes: Brightness ({filters.brightness}%), Contrast ({filters.contrast}%), Saturation ({filters.saturation}%), Blur ({filters.blur}px), and Color Tint ({filters.tint}°).
              </p>
            </div>

            <button
              onClick={handleApplyToAll}
              disabled={batchImages.length === 0}
              className={`w-full text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10 ${
                applied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white'
              }`}
            >
              {applied ? (
                <>
                  <Check className="w-4 h-4 animate-bounce" />
                  <span>Synchronized Successfully!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Sync Controls to Batch ({batchImages.length + 1} items)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Pro Batch Suite Unlocked (Free)</span>
        </div>
      </div>
    </aside>
  );
}

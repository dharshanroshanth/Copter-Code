/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Zap, Sun, ShieldCheck } from 'lucide-react';
import { Filters } from '../types';
import { DEFAULT_FILTERS } from '../constants';

interface AdjustPanelProps {
  filters: Filters;
  onChangeFilters: (filters: Filters) => void;
  onApplyAdjustments: () => void;
  onSavePreset: () => void;
}

export default function AdjustPanel({
  filters,
  onChangeFilters,
  onApplyAdjustments,
  onSavePreset,
}: AdjustPanelProps) {
  const handleSliderChange = (key: keyof Filters, value: number) => {
    onChangeFilters({
      ...filters,
      [key]: value,
    });
  };

  const handleReset = () => {
    onChangeFilters({ ...DEFAULT_FILTERS });
  };

  // Quick Action: Clarity (boosts contrast by 30 and saturation by 25)
  const applyClarity = () => {
    onChangeFilters({
      ...filters,
      contrast: Math.min(100, filters.contrast + 30),
      saturation: Math.min(100, filters.saturation + 25),
    });
  };

  // Quick Action: Sharpen (increases contrast slightly, reduces blur to 0)
  const applySharpen = () => {
    onChangeFilters({
      ...filters,
      contrast: Math.min(100, filters.contrast + 15),
      blur: 0,
    });
  };

  return (
    <aside className="w-80 border-l border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        {/* Header containing reset */}
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Adjustments</h2>
          <button
            onClick={handleReset}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer"
          >
            Reset All
          </button>
        </div>

        {/* LIGHT SECTION */}
        <div className="space-y-4">
          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block">
            Light
          </span>

          {/* Brightness */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Brightness</span>
              <span className="font-mono font-semibold text-slate-800">
                {filters.brightness > 0 ? `+${filters.brightness}` : filters.brightness}
              </span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={filters.brightness}
              onChange={(e) => handleSliderChange('brightness', parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Contrast */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Contrast</span>
              <span className="font-mono font-semibold text-slate-800">
                {filters.contrast > 0 ? `+${filters.contrast}` : filters.contrast}
              </span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={filters.contrast}
              onChange={(e) => handleSliderChange('contrast', parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Highlights / Blur */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Highlights (Blur)</span>
              <span className="font-mono font-semibold text-slate-800">
                {filters.blur}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={filters.blur}
              onChange={(e) => handleSliderChange('blur', parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* COLOR SECTION */}
        <div className="space-y-4 pt-4 border-t border-slate-100">
          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block">
            Color
          </span>

          {/* Saturation */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Saturation</span>
              <span className="font-mono font-semibold text-slate-800">
                {filters.saturation > 0 ? `+${filters.saturation}` : filters.saturation}
              </span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={filters.saturation}
              onChange={(e) => handleSliderChange('saturation', parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Tint */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Tint (Hue Rotate)</span>
              <span className="font-mono font-semibold text-slate-800">
                {filters.tint > 0 ? `+${filters.tint}°` : `${filters.tint}°`}
              </span>
            </div>
            <input
              type="range"
              min="-180"
              max="180"
              value={filters.tint}
              onChange={(e) => handleSliderChange('tint', parseInt(e.target.value))}
              className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* EFFECTS QUICK ACTIONS */}
        <div className="pt-4 border-t border-slate-100">
          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Quick Effects
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={applyClarity}
              className="border border-slate-200 hover:bg-slate-50 rounded-xl py-3 px-2 flex flex-col items-center justify-center text-center transition-colors cursor-pointer group"
            >
              <Zap className="w-5 h-5 text-indigo-500 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-semibold text-slate-700">
                Clarity Boost
              </span>
            </button>
            <button
              onClick={applySharpen}
              className="border border-slate-200 hover:bg-slate-50 rounded-xl py-3 px-2 flex flex-col items-center justify-center text-center transition-colors cursor-pointer group"
            >
              <Sun className="w-5 h-5 text-amber-500 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-semibold text-slate-700">
                Sharpen Tone
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="p-5 border-t border-slate-100 bg-slate-50 flex items-center space-x-2 shrink-0">
        <button
          onClick={onSavePreset}
          className="flex-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold py-3 rounded-xl transition-colors cursor-pointer shadow-xs"
        >
          Save Preset
        </button>
        <button
          onClick={onApplyAdjustments}
          className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-3 rounded-xl transition-colors cursor-pointer shadow-md shadow-indigo-600/15"
        >
          Apply Filters
        </button>
      </div>
    </aside>
  );
}

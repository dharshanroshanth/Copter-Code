/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Square, ShieldCheck, Check, Sparkles, Sliders } from 'lucide-react';

export interface FrameStyle {
  id: string;
  name: string;
  description: string;
  icon: string;
  borderWidth: number;
  borderColor: string;
  borderRadius: number;
  shadow: string;
  className?: string;
  hasPolaroidText?: boolean;
}

export const FRAMES_LIST: FrameStyle[] = [
  {
    id: 'frame-none',
    name: 'Borderless Minimal',
    description: 'Perfect edge-to-edge layout with zero visual frame noise.',
    icon: '🔳',
    borderWidth: 0,
    borderColor: 'transparent',
    borderRadius: 0,
    shadow: 'none',
  },
  {
    id: 'frame-polaroid',
    name: 'Vintage Polaroid',
    description: 'An elegant bottom-weighted card layout with space for a caption.',
    icon: '📸',
    borderWidth: 16,
    borderColor: '#fdfbf7',
    borderRadius: 4,
    shadow: '0 20px 25px -5px rgba(0,0,0,0.15)',
    hasPolaroidText: true,
  },
  {
    id: 'frame-film',
    name: 'Cinematic Filmstrip',
    description: 'Black cinema margins decorated with retro camera timestamps.',
    icon: '🎞️',
    borderWidth: 12,
    borderColor: '#111827',
    borderRadius: 0,
    shadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
  },
  {
    id: 'frame-gold',
    name: 'Ornate Gold Frame',
    description: 'Luxury metallic golden bevel frames for classical master artworks.',
    icon: '🏆',
    borderWidth: 14,
    borderColor: '#d97706',
    borderRadius: 2,
    shadow: '0 10px 15px -3px rgba(0,0,0,0.3)',
  },
  {
    id: 'frame-wood',
    name: 'Polished Oak Wood',
    description: 'A cozy natural wooden edge framing with rich timber textures.',
    icon: '🪵',
    borderWidth: 18,
    borderColor: '#78350f',
    borderRadius: 1,
    shadow: '0 8px 10px -2px rgba(0,0,0,0.25)',
  },
  {
    id: 'frame-neon',
    name: 'Cyberpunk Neon',
    description: 'Electric bright futuristic glowing pink border stroke.',
    icon: '⚡',
    borderWidth: 6,
    borderColor: '#ec4899',
    borderRadius: 8,
    shadow: '0 0 15px #ec4899',
  },
];

interface FramesPanelProps {
  activeFrameId: string;
  onSelectFrameId: (frameId: string) => void;
  customBorderWidth: number;
  onSetCustomBorderWidth: (width: number) => void;
  customBorderColor: string;
  onSetCustomBorderColor: (color: string) => void;
  customBorderRadius: number;
  onSetCustomBorderRadius: (radius: number) => void;
}

export default function FramesPanel({
  activeFrameId,
  onSelectFrameId,
  customBorderWidth,
  onSetCustomBorderWidth,
  customBorderColor,
  onSetCustomBorderColor,
  customBorderRadius,
  onSetCustomBorderRadius,
}: FramesPanelProps) {
  const [applied, setApplied] = useState(false);

  const handleApply = () => {
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 mb-2">
            <Square className="w-5 h-5" />
            <h2 className="text-sm font-semibold text-slate-900">Creative Frames</h2>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Wrap your image inside vintage, cinematic, luxury, or customizable modern border frames for beautiful, ready-to-share layout structures.
          </p>

          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-3">
            Choose Frame Style
          </span>

          <div className="space-y-2.5">
            {FRAMES_LIST.map((frame) => {
              const isSelected = activeFrameId === frame.id;
              return (
                <button
                  key={frame.id}
                  onClick={() => onSelectFrameId(frame.id)}
                  className={`w-full flex items-center space-x-3.5 p-3 rounded-xl border text-left transition-all cursor-pointer group ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/40 text-indigo-950 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 text-slate-600'
                  }`}
                >
                  <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-lg group-hover:scale-110 transition-transform shrink-0">
                    {frame.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-slate-800 truncate leading-tight group-hover:text-indigo-600 transition-colors">
                      {frame.name}
                    </h3>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5 leading-relaxed">
                      {frame.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Custom controls */}
          <div className="pt-4 mt-4 border-t border-slate-100 space-y-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Frame Advanced Micro-Adjust
            </span>

            {/* Custom Border Color */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-600 block font-medium">Custom Frame Color</span>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={customBorderColor}
                  onChange={(e) => onSetCustomBorderColor(e.target.value)}
                  className="w-8 h-8 rounded border border-slate-300 cursor-pointer p-0"
                />
                <span className="text-xs font-mono font-semibold text-slate-700">{customBorderColor}</span>
              </div>
            </div>

            {/* Custom Border Width */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Border Width</span>
                <span className="font-mono font-bold text-slate-800">{customBorderWidth}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={customBorderWidth}
                onChange={(e) => onSetCustomBorderWidth(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Custom Border Corner Rounding */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Corner Rounding (Radius)</span>
                <span className="font-mono font-bold text-slate-800">{customBorderRadius}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="48"
                value={customBorderRadius}
                onChange={(e) => onSetCustomBorderRadius(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          <button
            onClick={handleApply}
            className={`w-full mt-6 text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10 ${
              applied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {applied ? (
              <>
                <Check className="w-4 h-4 animate-bounce" />
                <span>Frames Configuration Lock!</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Save Frame Config</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Pro Decorative Framing Unlocked</span>
        </div>
      </div>
    </aside>
  );
}

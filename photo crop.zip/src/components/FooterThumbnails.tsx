/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Plus, Image as ImageIcon, UploadCloud } from 'lucide-react';
import { IMAGE_TEMPLATES } from '../constants';

interface FooterThumbnailsProps {
  activeImageUrl: string;
  onSelectTemplateUrl: (url: string) => void;
  onCustomImageUploaded: (dataUrl: string) => void;
}

export default function FooterThumbnails({
  activeImageUrl,
  onSelectTemplateUrl,
  onCustomImageUploaded,
}: FooterThumbnailsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // File loading mechanism
  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result;
      if (typeof result === 'string') {
        onCustomImageUploaded(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <footer className="h-24 bg-slate-900 border-t border-white/5 flex items-center justify-start space-x-3 px-6 overflow-x-auto shrink-0 z-10 select-none">
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Add New local file uploader with Drag and Drop support */}
      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`h-[68px] w-28 rounded-xl border border-dashed flex flex-col items-center justify-center text-center shrink-0 cursor-pointer transition-all ${
          isDragOver
            ? 'border-indigo-400 bg-indigo-950/40 text-indigo-300 scale-95'
            : 'border-white/20 hover:border-white/40 text-white/50 hover:text-white bg-white/5 hover:bg-white/10'
        }`}
        title="Drag & drop or click to upload photo"
      >
        {isDragOver ? (
          <UploadCloud className="w-4 h-4 mb-1 animate-bounce text-indigo-400" />
        ) : (
          <Plus className="w-4 h-4 mb-1" />
        )}
        <span className="text-[10px] font-medium block">
          {isDragOver ? 'Drop Image!' : 'Add New'}
        </span>
      </div>

      {/* Templates list */}
      <div id="thumbnails-list" className="flex items-center space-x-3">
        {IMAGE_TEMPLATES.map((item) => {
          const isActive = activeImageUrl === item.url;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTemplateUrl(item.url)}
              className={`thumb-btn h-[68px] w-32 rounded-xl relative overflow-hidden flex-shrink-0 group transition-all duration-200 cursor-pointer ${
                isActive ? 'ring-2 ring-indigo-500 scale-[0.98]' : 'border border-white/10'
              }`}
            >
              <img
                src={item.url}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-1.5 text-left">
                <span className="text-[9px] font-semibold text-white/95 truncate block">
                  {item.id}. {item.name}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </footer>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Crop,
  Sliders,
  Palette,
  Type,
  Square,
  Sparkles,
  Smile,
  Image as ImageIcon,
  Layers,
  MoreHorizontal,
} from 'lucide-react';
import { ActiveTool } from '../types';

interface SidebarProps {
  activeTool: ActiveTool;
  onChangeTool: (tool: ActiveTool) => void;
  onOpenUpgrade: () => void;
}

export default function Sidebar({
  activeTool,
  onChangeTool,
  onOpenUpgrade,
}: SidebarProps) {
  const tools = [
    { id: 'crop' as ActiveTool, label: 'Crop & Resize', icon: Crop },
    { id: 'adjust' as ActiveTool, label: 'Adjustments', icon: Sliders },
    { id: 'filters' as ActiveTool, label: 'Filters & Presets', icon: Palette },
    { id: 'text' as ActiveTool, label: 'Text Layers', icon: Type },
    { id: 'elements' as ActiveTool, label: 'Shapes & Elements', icon: Square },
    {
      id: 'ai' as ActiveTool,
      label: 'AI Magic Tools',
      icon: Sparkles,
      isAi: true,
    },
  ];

  const secondaryTools = [
    { id: 'retouch' as ActiveTool, label: 'Skin Retouching', icon: Smile },
    { id: 'background' as ActiveTool, label: 'Background Studio', icon: ImageIcon },
    { id: 'frames' as ActiveTool, label: 'Creative Frames', icon: Square },
    { id: 'batch' as ActiveTool, label: 'Batch Processor', icon: Layers },
    { id: 'more' as ActiveTool, label: 'Special Effects', icon: MoreHorizontal },
  ];

  return (
    <aside className="w-60 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 select-none">
      <div className="py-4 space-y-1 overflow-y-auto flex-1">
        <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-6 block mb-2">
          Image Editing
        </span>

        {/* Core Interactive Tools */}
        {tools.map((tool) => {
          const IconComponent = tool.icon;
          const isActive = activeTool === tool.id;

          return (
            <button
              key={tool.id}
              onClick={() => onChangeTool(tool.id)}
              className={`w-full flex items-center space-x-3 px-6 py-2.5 text-xs font-semibold border-r-2 transition-all cursor-pointer ${
                isActive
                  ? 'text-indigo-600 bg-indigo-50/50 border-indigo-600'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border-transparent'
              }`}
            >
              {tool.isAi ? (
                <span className="text-indigo-500 font-bold text-[10px] bg-indigo-50 px-1 py-0.5 rounded border border-indigo-100 animate-pulse">
                  AI
                </span>
              ) : (
                <IconComponent className="w-4 h-4 shrink-0" />
              )}
              <span>{tool.label}</span>
            </button>
          );
        })}

        <div className="my-2 border-t border-slate-100 mx-4" />

        <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-6 block mb-2">
          Creative Effects
        </span>

        {/* Secondary Tools */}
        {secondaryTools.map((tool) => {
          const IconComponent = tool.icon;
          const isActive = activeTool === tool.id;

          return (
            <button
              key={tool.id}
              onClick={() => onChangeTool(tool.id)}
              className={`w-full flex items-center justify-between px-6 py-2.5 text-xs font-semibold border-r-2 transition-all cursor-pointer ${
                isActive
                  ? 'text-indigo-600 bg-indigo-50/50 border-indigo-600'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border-transparent'
              }`}
            >
              <div className="flex items-center space-x-3">
                <IconComponent className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>{tool.label}</span>
              </div>
            </button>
          );
        })}
      </div>
    </aside>
  );
}

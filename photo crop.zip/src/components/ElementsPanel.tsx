/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, ShieldCheck, Heart, Star, Circle, Square as SquareIcon, Bookmark, Triangle, ArrowUp, MessageSquare, Sliders } from 'lucide-react';
import { ElementLayer } from '../types';

interface ElementsPanelProps {
  layers: ElementLayer[];
  onAddLayer: (type: ElementLayer['type'], color: string, size: number) => void;
  onUpdateLayer: (id: string, updates: Partial<ElementLayer>) => void;
  onRemoveLayer: (id: string) => void;
}

const COLOR_SWATCHES = [
  '#ef4444', // Red
  '#f59e0b', // Amber
  '#10b981', // Green
  '#3b82f6', // Blue
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#ffffff', // White
  '#000000', // Black
];

const SHAPES = [
  { type: 'circle' as const, label: 'Circle', icon: Circle },
  { type: 'square' as const, label: 'Square', icon: SquareIcon },
  { type: 'triangle' as const, label: 'Triangle', icon: Triangle },
  { type: 'arrow' as const, label: 'Arrow', icon: ArrowUp },
  { type: 'message-bubble' as const, label: 'Bubble', icon: MessageSquare },
  { type: 'heart' as const, label: 'Heart', icon: Heart },
  { type: 'star' as const, label: 'Star', icon: Star },
  { type: 'badge' as const, label: 'Badge', icon: Bookmark },
];

export default function ElementsPanel({
  layers,
  onAddLayer,
  onUpdateLayer,
  onRemoveLayer,
}: ElementsPanelProps) {
  const [selectedType, setSelectedType] = useState<ElementLayer['type']>('circle');
  const [selectedColor, setSelectedColor] = useState('#ef4444');
  const [elementSize, setElementSize] = useState(48);

  // Keep track of which active shape layer is selected for editing
  const [activeEditingId, setActiveEditingId] = useState<string | null>(null);

  // Auto-select the newly added layer or first layer
  useEffect(() => {
    if (layers.length > 0) {
      if (!activeEditingId || !layers.some((l) => l.id === activeEditingId)) {
        setActiveEditingId(layers[layers.length - 1].id);
      }
    } else {
      setActiveEditingId(null);
    }
  }, [layers, activeEditingId]);

  const handleAdd = () => {
    onAddLayer(selectedType, selectedColor, elementSize);
  };

  const activeEditingLayer = layers.find((l) => l.id === activeEditingId);

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-2">Graphics & Shapes</h2>
          <p className="text-xs text-slate-400 mb-4">
            Decorate your photos with customizable high-contrast vector overlays.
          </p>

          <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
            Choose Shape To Add
          </span>

          <div className="grid grid-cols-4 gap-1.5 mb-4">
            {SHAPES.map((shape) => {
              const ShapeIcon = shape.icon;
              const isSelected = selectedType === shape.type;
              return (
                <button
                  key={shape.type}
                  onClick={() => setSelectedType(shape.type)}
                  className={`p-2 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-600 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-500 hover:text-slate-800'
                  }`}
                  title={shape.label}
                >
                  <ShapeIcon className="w-5 h-5 shrink-0" />
                  <span className="text-[9px] mt-1 font-medium leading-none truncate w-full text-center">
                    {shape.label}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="space-y-4">
            {/* Colors */}
            <div className="space-y-1">
              <span className="text-xs text-slate-600 block font-medium">Shape Fill Color</span>
              <div className="flex flex-wrap gap-2">
                {COLOR_SWATCHES.map((color) => {
                  const isSelected = selectedColor === color;
                  return (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      style={{ backgroundColor: color }}
                      className={`w-6 h-6 rounded-full border transition-all cursor-pointer hover:scale-110 ${
                        isSelected
                          ? 'border-indigo-600 ring-2 ring-indigo-600/30 ring-offset-2'
                          : 'border-slate-300'
                      }`}
                      title={color}
                    />
                  );
                })}
              </div>
            </div>

            {/* CTA Button */}
            <button
              onClick={handleAdd}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-sm shadow-indigo-600/10"
            >
              <Plus className="w-4 h-4" />
              <span>Add Shape Layer</span>
            </button>
          </div>
        </div>

        {/* Selected Layer Properties Editor */}
        {activeEditingLayer && (
          <div className="pt-4 border-t border-slate-100 space-y-4">
            <div className="flex items-center space-x-1.5 text-indigo-600 mb-2">
              <Sliders className="w-4 h-4 animate-pulse" />
              <span className="text-[11px] font-bold uppercase tracking-wider">
                Shape Settings: {activeEditingLayer.type}
              </span>
            </div>

            {/* Style Type fill, outline, both */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-600 block font-medium">Style Mode</span>
              <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-xl text-[10px]">
                {(['fill', 'outline', 'both'] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => onUpdateLayer(activeEditingLayer.id, { styleType: style })}
                    className={`py-1.5 rounded-lg font-bold text-center capitalize transition-colors cursor-pointer ${
                      (activeEditingLayer.styleType || 'fill') === style
                        ? 'bg-white text-slate-800 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Diameter Size</span>
                <span className="font-mono font-semibold text-slate-800">{activeEditingLayer.size}px</span>
              </div>
              <input
                type="range"
                min="16"
                max="250"
                value={activeEditingLayer.size}
                onChange={(e) => onUpdateLayer(activeEditingLayer.id, { size: parseInt(e.target.value) })}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Rotation Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Rotation Angle</span>
                <span className="font-mono font-semibold text-slate-800">{(activeEditingLayer.rotation || 0)}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={activeEditingLayer.rotation || 0}
                onChange={(e) => onUpdateLayer(activeEditingLayer.id, { rotation: parseInt(e.target.value) })}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Opacity Slider */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Transparency</span>
                <span className="font-mono font-semibold text-slate-800">
                  {Math.round((activeEditingLayer.opacity !== undefined ? activeEditingLayer.opacity : 1) * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={Math.round((activeEditingLayer.opacity !== undefined ? activeEditingLayer.opacity : 1) * 100)}
                onChange={(e) => onUpdateLayer(activeEditingLayer.id, { opacity: parseFloat(e.target.value) / 100 })}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Colors Grid for editing */}
            <div className="space-y-2.5">
              {/* Fill color if filled or both */}
              {(activeEditingLayer.styleType === 'fill' || activeEditingLayer.styleType === 'both' || !activeEditingLayer.styleType) && (
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Fill Color</span>
                  <div className="flex flex-wrap gap-1.5">
                    {COLOR_SWATCHES.map((color) => {
                      const isSelected = activeEditingLayer.color === color;
                      return (
                        <button
                          key={color}
                          onClick={() => onUpdateLayer(activeEditingLayer.id, { color })}
                          style={{ backgroundColor: color }}
                          className={`w-5 h-5 rounded-full border transition-all cursor-pointer hover:scale-110 ${
                            isSelected
                              ? 'border-indigo-600 ring-2 ring-indigo-600/30 ring-offset-1'
                              : 'border-slate-300'
                          }`}
                        />
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Stroke color if outline or both */}
              {(activeEditingLayer.styleType === 'outline' || activeEditingLayer.styleType === 'both') && (
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Border/Outline Color</span>
                  <div className="flex flex-wrap gap-1.5">
                    {COLOR_SWATCHES.map((color) => {
                      const isSelected = (activeEditingLayer.strokeColor || activeEditingLayer.color) === color;
                      return (
                        <button
                          key={color}
                          onClick={() => onUpdateLayer(activeEditingLayer.id, { strokeColor: color })}
                          style={{ backgroundColor: color }}
                          className={`w-5 h-5 rounded-full border transition-all cursor-pointer hover:scale-110 ${
                            isSelected
                              ? 'border-indigo-600 ring-2 ring-indigo-600/30 ring-offset-1'
                              : 'border-slate-300'
                          }`}
                        />
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Stroke Width if outline or both */}
              {(activeEditingLayer.styleType === 'outline' || activeEditingLayer.styleType === 'both') && (
                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Border Width</span>
                    <span className="font-mono font-semibold text-slate-800">{activeEditingLayer.strokeWidth || 2}px</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={activeEditingLayer.strokeWidth || 2}
                    onChange={(e) => onUpdateLayer(activeEditingLayer.id, { strokeWidth: parseInt(e.target.value) })}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Existing active layers list */}
        {layers.length > 0 && (
          <div className="pt-4 border-t border-slate-100">
            <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider block mb-3">
              Active Shapes ({layers.length})
            </span>
            <div className="space-y-2 max-h-[160px] overflow-y-auto">
              {layers.map((layer) => {
                const isEditing = layer.id === activeEditingId;
                return (
                  <div
                    key={layer.id}
                    onClick={() => setActiveEditingId(layer.id)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all text-xs cursor-pointer ${
                      isEditing
                        ? 'border-indigo-600 bg-indigo-50/30 shadow-xs'
                        : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 flex-1 min-w-0">
                      <div
                        style={{ backgroundColor: layer.color }}
                        className="w-4 h-4 rounded-full border border-slate-300 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="font-bold text-slate-800 capitalize block truncate">
                          {layer.type} shape
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          {layer.size}px • {(layer.rotation || 0)}° • {Math.round((layer.opacity !== undefined ? layer.opacity : 1) * 100)}%
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveLayer(layer.id);
                        if (activeEditingId === layer.id) {
                          setActiveEditingId(null);
                        }
                      }}
                      className="text-slate-400 hover:text-red-500 p-1 rounded-lg transition-colors cursor-pointer"
                      title="Remove Shape"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Scale-independent Vectors</span>
        </div>
      </div>
    </aside>
  );
}

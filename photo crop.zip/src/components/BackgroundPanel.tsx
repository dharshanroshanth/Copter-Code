/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ImageIcon, Wand2, ShieldCheck, Check, Sparkles, Sliders, Layout } from 'lucide-react';

interface BackgroundPanelProps {
  onApplyBackground: (updates: { padding: number; color: string; blur: number; isGradient: boolean }) => void;
}

const BG_GRADIENTS = [
  { name: 'Warm Amber', value: 'linear-gradient(135deg, #f59e0b, #ef4444)' },
  { name: 'Aurora Borealis', value: 'linear-gradient(135deg, #10b981, #3b82f6)' },
  { name: 'Cyber Neon', value: 'linear-gradient(135deg, #ec4899, #8b5cf6)' },
  { name: 'Cool Slate', value: 'linear-gradient(135deg, #475569, #1e293b)' },
  { name: 'Fairy Dust', value: 'linear-gradient(135deg, #ffedd5, #fbcfe8)' },
  { name: 'Pure Dark', value: '#111827' },
  { name: 'Studio White', value: '#ffffff' },
];

export default function BackgroundPanel({ onApplyBackground }: BackgroundPanelProps) {
  const [padding, setPadding] = useState(0);
  const [selectedBg, setSelectedBg] = useState('#ffffff');
  const [applied, setApplied] = useState(false);
  const [chromaKeyColor, setChromaKeyColor] = useState('#00ff00');
  const [chromaKeyTolerance, setChromaKeyTolerance] = useState(30);

  const handleApply = () => {
    const isGradient = selectedBg.includes('gradient');
    onApplyBackground({
      padding,
      color: selectedBg,
      blur: padding > 0 ? 5 : 0,
      isGradient,
    });
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col justify-between shrink-0 overflow-y-auto select-none">
      <div className="p-5 space-y-6 flex-1">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 mb-2">
            <ImageIcon className="w-5 h-5" />
            <h2 className="text-sm font-semibold text-slate-900">Background Studio</h2>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Isolate the subject, add canvas padding, and substitute the background with studio colors, linear gradients, or a blurred duplicate.
          </p>

          <div className="space-y-4">
            {/* Canvas Padding Sliders */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 font-semibold">Mockup Margin Padding</span>
                <span className="font-mono font-bold text-slate-800">{padding}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={padding}
                onChange={(e) => setPadding(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[9px] text-slate-400 block leading-tight">
                Shrinks the main photo and wraps it inside the selected background color.
              </span>
            </div>

            {/* Background selections */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Studio Backdrops & Gradients
              </span>
              <div className="grid grid-cols-2 gap-2">
                {BG_GRADIENTS.map((bg) => {
                  const isSelected = selectedBg === bg.value;
                  return (
                    <button
                      key={bg.name}
                      onClick={() => setSelectedBg(bg.value)}
                      className={`p-2 rounded-xl border flex flex-col items-start text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600'
                      }`}
                    >
                      <div
                        style={{ background: bg.value }}
                        className="w-full h-8 rounded-lg mb-1.5 border border-slate-200"
                      />
                      <span className="text-[9px] font-semibold truncate w-full">{bg.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Chroma key controls */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Chroma Key (Color Isolation)
              </span>
              
              <div className="flex items-center space-x-3">
                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 block font-medium">Target Backdrop Color</span>
                  <div className="flex items-center space-x-2 mt-1">
                    <input
                      type="color"
                      value={chromaKeyColor}
                      onChange={(e) => setChromaKeyColor(e.target.value)}
                      className="w-7 h-7 rounded border border-slate-200 cursor-pointer p-0"
                    />
                    <span className="text-xs font-mono font-bold text-slate-700">{chromaKeyColor}</span>
                  </div>
                </div>

                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 block font-medium">Color Tolerance</span>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={chromaKeyTolerance}
                    onChange={(e) => setChromaKeyTolerance(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer mt-2"
                  />
                </div>
              </div>
              <span className="text-[9px] text-slate-400 block leading-tight">
                Instantly isolates the chroma key hue to make that portion of the image transparent.
              </span>
            </div>
          </div>

          <button
            onClick={handleApply}
            className={`w-full mt-6 text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10 ${
              applied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {applied ? (
              <>
                <Check className="w-4 h-4 animate-bounce" />
                <span>Background Applied Successfully!</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Render New Studio Backdrop</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
        <div className="flex items-center space-x-2 text-indigo-600">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span className="text-[10px] font-semibold">Pro Studio Suite Unlocked (Free)</span>
        </div>
      </div>
    </aside>
  );
}

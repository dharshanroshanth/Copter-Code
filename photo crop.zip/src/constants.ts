/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CropPreset, ImageTemplate, Filters } from './types';

export const IMAGE_TEMPLATES: ImageTemplate[] = [
  {
    id: '1',
    name: 'Yosemite Valley',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: '2',
    name: 'Mountain Peak',
    url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: '3',
    name: 'Sandy Beach',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: '4',
    name: 'Sunny Forest',
    url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: '5',
    name: 'Meadow Valley',
    url: 'https://images.unsplash.com/photo-1472214222555-d404758b1c42?auto=format&fit=crop&w=1200&q=80',
  },
];

export const CROP_PRESETS: CropPreset[] = [
  {
    id: 'preset-custom',
    label: 'Custom',
    ratio: null,
    aspectClass: 'aspect-auto',
  },
  {
    id: 'preset-original',
    label: 'Original',
    ratio: -1, // placeholder for original image aspect ratio
    aspectClass: 'aspect-auto',
  },
  {
    id: 'preset-1-1',
    label: '1:1 Square',
    ratio: 1,
    aspectClass: 'aspect-square',
  },
  {
    id: 'preset-16-9',
    label: '16:9 Wide',
    ratio: 16 / 9,
    aspectClass: 'aspect-video',
  },
  {
    id: 'preset-4-5',
    label: '4:5 Portrait',
    ratio: 4 / 5,
    aspectClass: 'aspect-[4/5]',
  },
  {
    id: 'preset-9-16',
    label: '9:16 Story',
    ratio: 9 / 16,
    aspectClass: 'aspect-[9/16]',
  },
];

export const DEFAULT_FILTERS: Filters = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  tint: 0,
  blur: 0,
};

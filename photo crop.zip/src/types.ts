/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Filters {
  brightness: number;  // -100 to 100
  contrast: number;    // -100 to 100
  saturation: number;  // -100 to 100
  tint: number;        // -180 to 180 (hue-rotate)
  blur: number;        // 0 to 100
}

export interface TextLayer {
  id: string;
  text: string;
  x: number; // percentage (0 to 100)
  y: number; // percentage (0 to 100)
  color: string;
  fontSize: number; // in px
  fontFamily: 'sans' | 'mono' | 'serif';
}

export interface ElementLayer {
  id: string;
  type: 'circle' | 'square' | 'heart' | 'star' | 'badge' | 'arrow' | 'triangle' | 'message-bubble';
  x: number; // percentage (0 to 100)
  y: number; // percentage (0 to 100)
  color: string;
  size: number; // in px
  rotation?: number; // degrees 0 to 360
  opacity?: number; // 0 to 1
  styleType?: 'fill' | 'outline' | 'both';
  strokeColor?: string;
  strokeWidth?: number;
}

export interface EditorState {
  dataUrl: string;
  width: number;
  height: number;
  filters: Filters;
  rotation: number; // -180 to 180 or multi 90
  flipH: boolean;
  flipV: boolean;
  textLayers: TextLayer[];
  elementLayers: ElementLayer[];
}

export type ActiveTool =
  | 'crop'
  | 'adjust'
  | 'filters'
  | 'text'
  | 'elements'
  | 'ai'
  | 'retouch'
  | 'background'
  | 'frames'
  | 'batch'
  | 'more';

export interface CropPreset {
  id: string;
  label: string;
  ratio: number | null; // aspect ratio width / height, null for Custom or Original
  aspectClass: string;
}

export interface ImageTemplate {
  id: string;
  name: string;
  url: string;
}

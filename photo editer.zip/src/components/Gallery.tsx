import React, { useRef } from "react";
import { Plus, ChevronRight, ChevronLeft } from "lucide-react";
import { ProjectImage } from "../types";

interface GalleryProps {
  images: ProjectImage[];
  activeImageId: string;
  onSelectImage: (id: string) => void;
  onAddNewImage: (file: File) => void;
}

export default function Gallery({
  images,
  activeImageId,
  onSelectImage,
  onAddNewImage,
}: GalleryProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onAddNewImage(file);
    }
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  const scroll = (direction: "left" | "right") => {
    if (scrollContainerRef.current) {
      const { scrollLeft, clientWidth } = scrollContainerRef.current;
      const scrollAmount = clientWidth * 0.6;
      scrollContainerRef.current.scrollTo({
        left: direction === "left" ? scrollLeft - scrollAmount : scrollLeft + scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <div id="editor-gallery" className="h-28 bg-white border-t border-slate-200 px-6 flex items-center gap-4 shrink-0 font-sans select-none relative">
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Add New Button Card */}
      <button
        id="gallery-add-new-btn"
        onClick={triggerUpload}
        className="w-24 h-[72px] rounded-xl border border-dashed border-slate-300 hover:border-violet-500 hover:bg-violet-50 flex flex-col items-center justify-center text-slate-500 hover:text-violet-600 shrink-0 transition-all duration-200 cursor-pointer active:scale-95 shadow-sm bg-slate-50"
      >
        <Plus className="w-5 h-5 mb-1" />
        <span className="text-[10px] font-bold">Add New</span>
      </button>

      {/* Vertical separator */}
      <div className="h-12 w-px bg-slate-200" />

      {/* Scroll Left Button */}
      <button
        onClick={() => scroll("left")}
        className="absolute left-[138px] z-10 p-1.5 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-500 hover:text-slate-800 rounded-full transition-all cursor-pointer opacity-0 hover:opacity-100 focus:opacity-100 shadow-sm"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {/* Thumbnails list */}
      <div
        ref={scrollContainerRef}
        className="flex-1 flex items-center gap-3 overflow-x-auto h-full py-2 scrollbar-none"
        style={{ scrollbarWidth: "none" }}
      >
        {images.map((img, idx) => {
          const isActive = img.id === activeImageId;
          return (
            <div
              key={img.id}
              onClick={() => onSelectImage(img.id)}
              className={`relative w-32 h-[72px] rounded-xl border overflow-hidden shrink-0 transition-all duration-200 cursor-pointer group hover:scale-102 ${
                isActive
                  ? "border-violet-500 ring-2 ring-violet-500/20 shadow-md shadow-violet-500/5"
                  : "border-slate-200 hover:border-slate-300 bg-slate-50"
              }`}
            >
              {/* Image Preview */}
              <img
                src={img.url}
                alt={img.name}
                className="w-full h-full object-cover select-none"
                referrerPolicy="no-referrer"
              />

              {/* Index and Name tag */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/85 via-slate-950/50 to-transparent p-1 px-2 flex items-center justify-between">
                <span className="text-[9px] font-mono font-bold text-slate-300 shrink-0">
                  {idx + 1}
                </span>
                <span className="text-[9px] font-bold text-white truncate flex-1 text-right pl-2">
                  {img.name.replace(/\.[^/.]+$/, "")}
                </span>
              </div>

              {/* Active Overlay Glow */}
              {isActive && (
                <div className="absolute inset-0 border border-violet-500/30 rounded-xl pointer-events-none" />
              )}
            </div>
          );
        })}
      </div>

      {/* Scroll Right Button */}
      <button
        onClick={() => scroll("right")}
        className="absolute right-4 z-10 p-1.5 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-500 hover:text-slate-800 rounded-full transition-all cursor-pointer shadow-sm"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}

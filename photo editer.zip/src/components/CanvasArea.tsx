import React, { useState, useRef, useEffect } from "react";
import {
  MousePointer,
  Hand,
  ZoomIn,
  Crop,
  Trash2,
  Type,
  Plus,
  X,
  Sparkles,
  ArrowRight,
  Star,
  Square,
  Circle,
  HelpCircle,
} from "lucide-react";
import { ProjectImage, CanvasMode, Layer, CropRect, ToolType, Adjustments } from "../types";

interface CanvasAreaProps {
  activeImage: ProjectImage | null;
  canvasMode: CanvasMode;
  setCanvasMode: (mode: CanvasMode) => void;
  onUpdateImage: (updates: Partial<ProjectImage>) => void;
  zoom: number;
  activeTool?: ToolType | null;
  brushSize?: number;
  brushStrokes?: { points: { x: number; y: number }[] }[];
  setBrushStrokes?: (strokes: { points: { x: number; y: number }[] }[]) => void;
  selectedLayerId: string | null;
  setSelectedLayerId: (id: string | null) => void;
  selectedLayerIds?: string[];
  setSelectedLayerIds?: (ids: string[]) => void;
}

export default function CanvasArea({
  activeImage,
  canvasMode,
  setCanvasMode,
  onUpdateImage,
  zoom,
  activeTool,
  brushSize = 35,
  brushStrokes = [],
  setBrushStrokes,
  selectedLayerId,
  setSelectedLayerId,
  selectedLayerIds = [],
  setSelectedLayerIds = () => {},
}: CanvasAreaProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const cropBoxRef = useRef<HTMLDivElement>(null);

  // Drag states for crop box
  const [isCropping, setIsCropping] = useState(false);
  const [cropBox, setCropBox] = useState<CropRect>({ x: 10, y: 10, width: 80, height: 80 });
  const [activeHandle, setActiveHandle] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0, boxX: 0, boxY: 0, boxW: 0, boxH: 0 });

  // Drag states for text/element layers
  const [isDraggingLayer, setIsDraggingLayer] = useState(false);
  const [isResizingLayer, setIsResizingLayer] = useState(false);
  const [activeLayerHandle, setActiveLayerHandle] = useState<string | null>(null);
  const [layerDragStart, setLayerDragStart] = useState({ x: 0, y: 0, layerX: 0, layerY: 0, layerW: 0, layerH: 0 });
  const [multiDragStarts, setMultiDragStarts] = useState<{[id: string]: { x: number, y: number }}>({});

  // Layer editing values
  const [editingText, setEditingText] = useState("");

  // Local drawing track state
  const [isDrawing, setIsDrawing] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });
  const [isHovering, setIsHovering] = useState(false);

  const isBrushTool = 
    activeTool === "remove_obj" || 
    activeTool === "ai_replace" || 
    activeTool === "blemish" || 
    activeTool === "skin_smooth" || 
    activeTool === "teeth_whiten" || 
    activeTool === "red_eye";

  const getBrushColor = (alpha: number) => {
    switch (activeTool) {
      case "blemish":
        return `rgba(16, 185, 129, ${alpha})`;
      case "skin_smooth":
        return `rgba(244, 63, 94, ${alpha})`;
      case "teeth_whiten":
        return `rgba(245, 158, 11, ${alpha})`;
      case "red_eye":
        return `rgba(239, 68, 68, ${alpha})`;
      case "remove_obj":
        return `rgba(236, 72, 153, ${alpha})`;
      default:
        return `rgba(168, 85, 247, ${alpha})`;
    }
  };

  const getBrushHexColor = () => {
    switch (activeTool) {
      case "blemish":
        return "#10b981";
      case "skin_smooth":
        return "#f43f5e";
      case "teeth_whiten":
        return "#f59e0b";
      case "red_eye":
        return "#ef4444";
      case "remove_obj":
        return "#ec4899";
      default:
        return "#a855f7";
    }
  };

  const handleBrushMouseDown = (e: React.MouseEvent) => {
    if (!imageRef.current || !setBrushStrokes) return;
    setIsDrawing(true);
    const rect = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const newStroke = { points: [{ x, y }] };
    setBrushStrokes([...brushStrokes, newStroke]);
  };

  const handleBrushMouseMove = (e: React.MouseEvent) => {
    if (imageRef.current) {
      const rect = imageRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      setMousePos({ x, y });
    }

    if (!isDrawing || !imageRef.current || !setBrushStrokes) return;
    const rect = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const updatedStrokes = [...brushStrokes];
    if (updatedStrokes.length > 0) {
      const lastStroke = { ...updatedStrokes[updatedStrokes.length - 1] };
      const lastPoint = lastStroke.points[lastStroke.points.length - 1];
      
      const dx = x - lastPoint.x;
      const dy = y - lastPoint.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      // Gate mousemove density to enforce lag-free lightweight vector paths
      if (distance > 0.45 || lastStroke.points.length < 2) {
        lastStroke.points = [...lastStroke.points, { x, y }];
        updatedStrokes[updatedStrokes.length - 1] = lastStroke;
        setBrushStrokes(updatedStrokes);
      }
    }
  };

  const handleBrushMouseUp = () => {
    setIsDrawing(false);
  };

  // Initialize crop coordinates when crop mode is entered
  useEffect(() => {
    if (canvasMode === "crop") {
      if (activeImage?.crop) {
        setCropBox(activeImage.crop);
      } else {
        setCropBox({ x: 10, y: 10, width: 80, height: 80 });
      }
    }
  }, [canvasMode, activeImage]);

  if (!activeImage) {
    return (
      <div id="empty-canvas-state" className="flex-1 flex flex-col items-center justify-center bg-[#111628]/40 border-slate-800 p-8 text-center font-sans">
        <div className="w-16 h-16 rounded-full bg-slate-800/60 flex items-center justify-center text-slate-500 mb-4 animate-pulse">
          <HelpCircle className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-semibold text-white mb-1">No Image Selected</h3>
        <p className="text-xs text-slate-400 max-w-sm mb-4">
          Please select one of our premium starter images below or upload your own to begin editing.
        </p>
      </div>
    );
  }

  // Calculate CSS Filter adjustments
  const adj = activeImage.adjustments;
  const mainClarityAmount = ((adj.clarity || 0) * 0.6 + (adj.sharpen || 0) * 0.9) / 100;

  const filterStyles = {
    filter: [
      (adj.clarity || adj.sharpen) ? "url(#mainClarityFilter)" : "",
      `brightness(${100 + adj.brightness}%)`,
      `contrast(${100 + adj.contrast}%)`,
      `saturate(${100 + adj.saturation + adj.vibrance * 0.5}%)`,
      activeImage.filter === "mono" ? "grayscale(100%)" : "",
      activeImage.filter === "noir" ? "grayscale(100%) contrast(150%)" : "",
      activeImage.filter === "sepia" ? "sepia(80%)" : "",
      activeImage.filter === "vintage" ? "sepia(40%) contrast(110%) saturate(80%)" : "",
      activeImage.filter === "warm" ? "contrast(100%) saturate(110%)" : "",
      activeImage.filter === "cool" ? "contrast(100%) saturate(90%)" : "",
    ]
      .filter(Boolean)
      .join(" "),
  };

  // Temperature and Tint Overlay Styles
  const getOverlayStyle = () => {
    let background = "transparent";
    if (adj.temperature > 0) {
      background = `rgba(245, 158, 11, ${adj.temperature / 400})`; // Orange warm
    } else if (adj.temperature < 0) {
      background = `rgba(59, 130, 246, ${Math.abs(adj.temperature) / 400})`; // Blue cool
    }

    let tintOverlay = "transparent";
    if (adj.tint > 0) {
      tintOverlay = `rgba(236, 72, 153, ${adj.tint / 400})`; // Magenta
    } else if (adj.tint < 0) {
      tintOverlay = `rgba(16, 185, 129, ${Math.abs(adj.tint) / 400})`; // Green
    }

    return {
      background: background,
      mixBlendMode: "color-burn" as const,
      boxShadow: adj.vignette > 0 ? `inset 0 0 ${adj.vignette * 1.5}px rgba(0, 0, 0, 0.85)` : "none",
    };
  };

  const getLayerFilterStyle = (layer: any) => {
    const layerAdj = layer.adjustments;
    if (!layerAdj) return {};
    return {
      filter: [
        (layerAdj.clarity || layerAdj.sharpen) ? `url(#clarityFilter-${layer.id})` : "",
        `brightness(${100 + layerAdj.brightness}%)`,
        `contrast(${100 + layerAdj.contrast}%)`,
        `saturate(${100 + layerAdj.saturation + layerAdj.vibrance * 0.5}%)`,
      ]
        .filter(Boolean)
        .join(" "),
    };
  };

  const getLayerOverlayStyle = (layerAdj?: Adjustments) => {
    if (!layerAdj) return {};
    let background = "transparent";
    if (layerAdj.temperature > 0) {
      background = `rgba(245, 158, 11, ${layerAdj.temperature / 400})`; // Orange warm
    } else if (layerAdj.temperature < 0) {
      background = `rgba(59, 130, 246, ${Math.abs(layerAdj.temperature) / 400})`; // Blue cool
    }

    let tintOverlay = "transparent";
    if (layerAdj.tint > 0) {
      tintOverlay = `rgba(236, 72, 153, ${layerAdj.tint / 400})`; // Magenta
    } else if (layerAdj.tint < 0) {
      tintOverlay = `rgba(16, 185, 129, ${Math.abs(layerAdj.tint) / 400})`; // Green
    }

    return {
      background: background,
      mixBlendMode: "color-burn" as const,
      boxShadow: layerAdj.vignette > 0 ? `inset 0 0 ${layerAdj.vignette * 1.5}px rgba(0, 0, 0, 0.85)` : "none",
    };
  };

  // Transformation rotation, flipping and perspective skewing
  const skewX = activeImage.transform.skewX || 0;
  const skewY = activeImage.transform.skewY || 0;
  const perspectiveVal = activeImage.transform.perspective || 0;

  const transformStyles = {
    transform: [
      (perspectiveVal || skewX || skewY) ? `perspective(${800 - (perspectiveVal || 50) * 6}px) rotateY(${skewX}deg) rotateX(${skewY}deg)` : "",
      `rotate(${activeImage.transform.rotate + (activeImage.transform.straighten || 0)}deg)`,
      activeImage.transform.flipH ? "scaleX(-1)" : "",
      activeImage.transform.flipV ? "scaleY(-1)" : "",
    ]
      .filter(Boolean)
      .join(" "),
    transition: isCropping ? "none" : "transform 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
  };

  // If cropped, style outer container aspect ratio and translation
  const getCroppedContainerStyle = () => {
    if (!activeImage.crop || canvasMode === "crop") return {};
    if (activeImage.bgTreatment && activeImage.bgTreatment !== "crop") {
      return {
        position: "relative" as const,
        width: "100%",
        height: "100%",
      };
    }

    const { x, y, width, height } = activeImage.crop;
    return {
      position: "relative" as const,
      overflow: "hidden" as const,
      width: `${width}%`,
      height: `${height}%`,
      left: `${x}%`,
      top: `${y}%`,
    };
  };

  const getCroppedImageStyle = () => {
    if (!activeImage.crop || canvasMode === "crop") return {};
    if (activeImage.bgTreatment && activeImage.bgTreatment !== "crop") return {};

    const { x, y, width, height } = activeImage.crop;
    const scaleX = 100 / width;
    const scaleY = 100 / height;

    return {
      width: `${scaleX * 100}%`,
      height: `${scaleY * 100}%`,
      transform: `translate(${-x * scaleX}%, ${-y * scaleY}%)`,
      position: "absolute" as const,
    };
  };

  // ----------------------------------------------------
  // INTERACTIVE CROP BOX DRAGGING
  // ----------------------------------------------------
  const handleCropMouseDown = (e: React.MouseEvent, handle: string) => {
    e.stopPropagation();
    e.preventDefault();
    setActiveHandle(handle);
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      boxX: cropBox.x,
      boxY: cropBox.y,
      boxW: cropBox.width,
      boxH: cropBox.height,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (activeHandle && cropBoxRef.current && containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const dx = ((e.clientX - dragStart.x) / containerRect.width) * 100;
      const dy = ((e.clientY - dragStart.y) / containerRect.height) * 100;

      let nextBox = { ...cropBox };

      if (activeHandle === "move") {
        nextBox.x = Math.max(0, Math.min(100 - dragStart.boxW, dragStart.boxX + dx));
        nextBox.y = Math.max(0, Math.min(100 - dragStart.boxH, dragStart.boxY + dy));
      } else {
        // Handle corners
        if (activeHandle.includes("n")) {
          const potentialY = dragStart.boxY + dy;
          const potentialH = dragStart.boxH - dy;
          if (potentialY >= 0 && potentialH >= 5) {
            nextBox.y = potentialY;
            nextBox.height = potentialH;
          }
        }
        if (activeHandle.includes("s")) {
          const potentialH = dragStart.boxH + dy;
          if (dragStart.boxY + potentialH <= 100 && potentialH >= 5) {
            nextBox.height = potentialH;
          }
        }
        if (activeHandle.includes("w")) {
          const potentialX = dragStart.boxX + dx;
          const potentialW = dragStart.boxW - dx;
          if (potentialX >= 0 && potentialW >= 5) {
            nextBox.x = potentialX;
            nextBox.width = potentialW;
          }
        }
        if (activeHandle.includes("e")) {
          const potentialW = dragStart.boxW + dx;
          if (dragStart.boxX + potentialW <= 100 && potentialW >= 5) {
            nextBox.width = potentialW;
          }
        }
      }

      setCropBox(nextBox);
    }

    // Drag Layer
    if (isDraggingLayer && (selectedLayerId || selectedLayerIds.length > 0) && containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const dx = ((e.clientX - layerDragStart.x) / containerRect.width) * 100;
      const dy = ((e.clientY - layerDragStart.y) / containerRect.height) * 100;

      const idsToDrag = selectedLayerIds.length > 0 ? selectedLayerIds : (selectedLayerId ? [selectedLayerId] : []);

      if (idsToDrag.includes("background")) {
        const bgStart = multiDragStarts["background"] || { x: layerDragStart.layerX, y: layerDragStart.layerY };
        const updatedLayers = activeImage.layers.map((layer) => {
          if (idsToDrag.includes(layer.id)) {
            const startPos = multiDragStarts[layer.id] || { x: layer.x, y: layer.y };
            const isJoinSplit = layer.id.includes("join-split");
            const minX = isJoinSplit ? -150 : 0;
            const maxX = isJoinSplit ? 250 : 100 - layer.width;
            const minY = isJoinSplit ? -150 : 0;
            const maxY = isJoinSplit ? 250 : 100 - layer.height;

            return {
              ...layer,
              x: Math.max(minX, Math.min(maxX, startPos.x + dx)),
              y: Math.max(minY, Math.min(maxY, startPos.y + dy)),
            };
          }
          return layer;
        });

        onUpdateImage({
          bgX: Math.max(-50, Math.min(100, bgStart.x + dx)),
          bgY: Math.max(-50, Math.min(100, bgStart.y + dy)),
          layers: updatedLayers,
        });
      } else {
        const updatedLayers = activeImage.layers.map((layer) => {
          if (idsToDrag.includes(layer.id)) {
            const startPos = multiDragStarts[layer.id] || { x: layer.x, y: layer.y };
            const isJoinSplit = layer.id.includes("join-split");
            const minX = isJoinSplit ? -150 : 0;
            const maxX = isJoinSplit ? 250 : 100 - layer.width;
            const minY = isJoinSplit ? -150 : 0;
            const maxY = isJoinSplit ? 250 : 100 - layer.height;

            return {
              ...layer,
              x: Math.max(minX, Math.min(maxX, startPos.x + dx)),
              y: Math.max(minY, Math.min(maxY, startPos.y + dy)),
            };
          }
          return layer;
        });

        onUpdateImage({ layers: updatedLayers });
      }
    }

    // Resize Layer
    if (isResizingLayer && selectedLayerId && containerRef.current && activeLayerHandle) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const dx = ((e.clientX - layerDragStart.x) / containerRect.width) * 100;
      const dy = ((e.clientY - layerDragStart.y) / containerRect.height) * 100;

      if (selectedLayerId === "background") {
        let nextX = layerDragStart.layerX;
        let nextY = layerDragStart.layerY;
        let nextW = layerDragStart.layerW;
        let nextH = layerDragStart.layerH;

        if (activeLayerHandle.includes("n")) {
          nextY = layerDragStart.layerY + dy;
          nextH = Math.max(5, layerDragStart.layerH - dy);
        }
        if (activeLayerHandle.includes("s")) {
          nextH = Math.max(5, layerDragStart.layerH + dy);
        }
        if (activeLayerHandle.includes("w")) {
          nextX = layerDragStart.layerX + dx;
          nextW = Math.max(5, layerDragStart.layerW - dx);
        }
        if (activeLayerHandle.includes("e")) {
          nextW = Math.max(5, layerDragStart.layerW + dx);
        }

        onUpdateImage({
          bgX: nextX,
          bgY: nextY,
          bgWidth: nextW,
          bgHeight: nextH,
        });
      } else {
        const updatedLayers = activeImage.layers.map((layer) => {
          if (layer.id === selectedLayerId) {
            const isJoinSplit = layer.id.includes("join-split");
            let nextX = layerDragStart.layerX;
            let nextY = layerDragStart.layerY;
            let nextW = layerDragStart.layerW;
            let nextH = layerDragStart.layerH;

            if (isJoinSplit) {
              if (activeLayerHandle.includes("n")) {
                nextY = layerDragStart.layerY + dy;
                nextH = Math.max(5, layerDragStart.layerH - dy);
              }
              if (activeLayerHandle.includes("s")) {
                nextH = Math.max(5, layerDragStart.layerH + dy);
              }
              if (activeLayerHandle.includes("w")) {
                nextX = layerDragStart.layerX + dx;
                nextW = Math.max(5, layerDragStart.layerW - dx);
              }
              if (activeLayerHandle.includes("e")) {
                nextW = Math.max(5, layerDragStart.layerW + dx);
              }
            } else {
              if (activeLayerHandle.includes("n")) {
                nextY = Math.max(0, layerDragStart.layerY + dy);
                nextH = Math.max(5, layerDragStart.layerH - (nextY - layerDragStart.layerY));
              }
              if (activeLayerHandle.includes("s")) {
                nextH = Math.max(5, Math.min(100 - layerDragStart.layerY, layerDragStart.layerH + dy));
              }
              if (activeLayerHandle.includes("w")) {
                nextX = Math.max(0, layerDragStart.layerX + dx);
                nextW = Math.max(5, layerDragStart.layerW - (nextX - layerDragStart.layerX));
              }
              if (activeLayerHandle.includes("e")) {
                nextW = Math.max(5, Math.min(100 - layerDragStart.layerX, layerDragStart.layerW + dx));
              }
            }

            return {
              ...layer,
              x: nextX,
              y: nextY,
              width: nextW,
              height: nextH,
            };
          }
          return layer;
        });

        onUpdateImage({ layers: updatedLayers });
      }
    }
  };

  const handleMouseUp = () => {
    setActiveHandle(null);
    setIsDraggingLayer(false);
    setIsResizingLayer(false);
    setActiveLayerHandle(null);
  };

  const applyCrop = () => {
    onUpdateImage({ crop: cropBox });
    setCanvasMode("select");
  };

  const resetCrop = () => {
    onUpdateImage({ crop: null });
    setCanvasMode("select");
  };

  // ----------------------------------------------------
  // TEXT & ELEMENT LAYERS HANDLING
  // ----------------------------------------------------
  const handleLayerMouseDown = (e: React.MouseEvent, layer: Layer) => {
    e.stopPropagation();
    const isCtrl = e.ctrlKey || e.metaKey;
    
    let newSelectedIds: string[];
    if (isCtrl) {
      if (selectedLayerIds.includes(layer.id)) {
        newSelectedIds = selectedLayerIds.filter(id => id !== layer.id);
      } else {
        newSelectedIds = [...selectedLayerIds, layer.id];
      }
    } else {
      if (selectedLayerIds.includes(layer.id)) {
        newSelectedIds = selectedLayerIds;
      } else {
        newSelectedIds = [layer.id];
      }
    }
    
    setSelectedLayerIds(newSelectedIds);
    if (newSelectedIds.length > 0) {
      setSelectedLayerId(newSelectedIds[newSelectedIds.length - 1]);
    } else {
      setSelectedLayerId(null);
    }

    setIsDraggingLayer(true);
    setEditingText(layer.text || "");
    
    const starts: {[id: string]: { x: number, y: number }} = {};
    if (activeImage) {
      activeImage.layers.forEach((l) => {
        if (newSelectedIds.includes(l.id)) {
          starts[l.id] = { x: l.x, y: l.y };
        }
      });
      if (newSelectedIds.includes("background")) {
        starts["background"] = { x: activeImage.bgX ?? 0, y: activeImage.bgY ?? 0 };
      }
    }
    setMultiDragStarts(starts);

    setLayerDragStart({
      x: e.clientX,
      y: e.clientY,
      layerX: layer.x,
      layerY: layer.y,
      layerW: layer.width,
      layerH: layer.height,
    });
  };

  const handleLayerResizeMouseDown = (e: React.MouseEvent, layer: Layer, handle: string) => {
    e.stopPropagation();
    setSelectedLayerId(layer.id);
    setIsResizingLayer(true);
    setActiveLayerHandle(handle);
    setLayerDragStart({
      x: e.clientX,
      y: e.clientY,
      layerX: layer.x,
      layerY: layer.y,
      layerW: layer.width,
      layerH: layer.height,
    });
  };

  const addTextLayer = () => {
    const newLayer: Layer = {
      id: `text-${Date.now()}`,
      type: "text",
      x: 35,
      y: 40,
      width: 30,
      height: 12,
      color: "#ffffff",
      text: "Double-click to type",
      fontSize: 16,
    };
    onUpdateImage({ layers: [...activeImage.layers, newLayer] });
    setSelectedLayerId(newLayer.id);
    setEditingText(newLayer.text || "");
  };

  const addElementLayer = (shapeType: "rect" | "circle" | "arrow" | "star") => {
    const newLayer: Layer = {
      id: `elem-${Date.now()}`,
      type: shapeType,
      x: 40,
      y: 40,
      width: 15,
      height: 15,
      color: "#7c3aed",
    };
    onUpdateImage({ layers: [...activeImage.layers, newLayer] });
    setSelectedLayerId(newLayer.id);
  };

  const deleteSelectedLayer = () => {
    if (selectedLayerId) {
      const remainingLayers = activeImage.layers.filter((l) => l.id !== selectedLayerId);
      onUpdateImage({ layers: remainingLayers });
      setSelectedLayerId(null);
    }
  };

  const updateSelectedLayerText = (text: string) => {
    setEditingText(text);
    const updated = activeImage.layers.map((l) => {
      if (l.id === selectedLayerId) {
        return { ...l, text: text };
      }
      return l;
    });
    onUpdateImage({ layers: updated });
  };

  const updateSelectedLayerColor = (color: string) => {
    const updated = activeImage.layers.map((l) => {
      if (l.id === selectedLayerId) {
        return { ...l, color };
      }
      return l;
    });
    onUpdateImage({ layers: updated });
  };

  return (
    <div
      id="main-canvas-workspace"
      onMouseDown={(e) => {
        if (!isBrushTool) {
          setSelectedLayerId(null);
        }
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className={`flex-1 relative flex items-center justify-center bg-[#f1f5f9] overflow-hidden p-12 transition-all font-sans ${
        canvasMode === "pan" ? "cursor-grab active:cursor-grabbing" : "cursor-default"
      }`}
    >
      {/* Zoom Container Wrapper */}
      <div
        ref={containerRef}
        className="relative max-w-full max-h-full aspect-video flex items-center justify-center border border-slate-200 bg-white shadow-2xl rounded-2xl overflow-hidden transition-transform duration-200"
        style={{
          transform: `scale(${zoom})`,
          width: "80%",
          height: "80%",
        }}
      >
        {/* Core Cropped Container wrapper */}
        <div style={getCroppedContainerStyle()} className="w-full h-full flex items-center justify-center">
          {/* Main Retouched Image Element with Premium Framer */}
          <div
            className="w-full h-full relative flex items-center justify-center transition-all duration-300"
            style={{
              padding: activeImage.frame === "classic" || activeImage.frame === "gold" ? "20px" : activeImage.frame === "film" ? "28px 18px" : activeImage.frame === "neon" ? "12px" : "0px",
              backgroundColor: activeImage.frame === "classic" ? "#ffffff" : activeImage.frame === "gold" ? "#15120d" : activeImage.frame === "film" ? "#0a0a0a" : "transparent",
              border: activeImage.frame === "classic" ? "14px solid #ffffff" : activeImage.frame === "gold" ? "12px solid #b89742" : activeImage.frame === "neon" ? "5px solid #ec4899" : "none",
              boxShadow: activeImage.frame === "classic" ? "0 15px 35px rgba(0,0,0,0.4)" : activeImage.frame === "gold" ? "inset 0 0 15px rgba(0,0,0,0.8), 0 15px 35px rgba(0,0,0,0.6)" : activeImage.frame === "neon" ? "0 0 25px #ec4899, inset 0 0 15px #ec4899" : "none",
              borderRadius: activeImage.frame === "rounded" ? "28px" : "0px",
              overflow: activeImage.frame === "rounded" ? "hidden" : "visible",
              ...getCroppedImageStyle()
            }}
          >
            {activeImage.frame === "film" && (
              <div className="absolute inset-y-0 left-1.5 flex flex-col justify-between py-2 text-[10px] text-white/50 font-mono select-none pointer-events-none z-10">
                {Array.from({ length: 9 }).map((_, i) => <div key={i}>▫️</div>)}
              </div>
            )}
            {activeImage.frame === "film" && (
              <div className="absolute inset-y-0 right-1.5 flex flex-col justify-between py-2 text-[10px] text-white/50 font-mono select-none pointer-events-none z-10">
                {Array.from({ length: 9 }).map((_, i) => <div key={i}>▫️</div>)}
              </div>
            )}
            {activeImage.bgTreatment && activeImage.bgTreatment !== "crop" && activeImage.crop && canvasMode !== "crop" ? (
              <div className="absolute inset-0 w-full h-full overflow-hidden">
                {/* 1. Background Treatment Layer */}
                <div className="absolute inset-0 w-full h-full" style={{ filter: activeImage.bgTreatment === "blur" ? "blur(12px) brightness(90%) contrast(90%)" : activeImage.bgTreatment === "grayscale" ? "grayscale(100%) opacity(60%)" : "none" }}>
                  {activeImage.bgTreatment !== "color_fill" ? (
                    <img
                      src={activeImage.url}
                      alt="AI Background Treatment Backdrop"
                      style={{ ...filterStyles, ...transformStyles }}
                      className="w-full h-full object-contain pointer-events-none select-none"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div 
                      className="absolute inset-0 w-full h-full" 
                      style={{ backgroundColor: activeImage.bgTreatmentColor || "#000000" }} 
                    />
                  )}
                </div>
                {/* 2. Isolated Subject Cutout Layer */}
                <div
                  style={{
                    position: "absolute" as const,
                    overflow: "hidden" as const,
                    left: `${activeImage.crop.x}%`,
                    top: `${activeImage.crop.y}%`,
                    width: `${activeImage.crop.width}%`,
                    height: `${activeImage.crop.height}%`,
                    boxShadow: "0 8px 32px rgba(0,0,0,0.3)",
                    border: "2px solid rgba(255,255,255,0.45)",
                    borderRadius: "12px",
                  }}
                >
                  <img
                    ref={imageRef}
                    src={activeImage.url}
                    alt={activeImage.name}
                    style={{
                      ...filterStyles,
                      ...transformStyles,
                      width: `${(100 / activeImage.crop.width) * 100}%`,
                      height: `${(100 / activeImage.crop.height) * 100}%`,
                      transform: `translate(${-activeImage.crop.x * (100 / activeImage.crop.width)}%, ${-activeImage.crop.y * (100 / activeImage.crop.height)}%) ${transformStyles.transform}`,
                      position: "absolute" as const,
                    }}
                    className="pointer-events-none select-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            ) : activeTool === "join" ? (
              <div
                className={`absolute transition-all duration-200 ${
                  selectedLayerIds.includes("background")
                    ? "border-2 border-violet-500 bg-violet-500/10 shadow-lg cursor-move z-10"
                    : "cursor-pointer"
                }`}
                style={{
                  left: `${activeImage.bgX ?? 0}%`,
                  top: `${activeImage.bgY ?? 0}%`,
                  width: `${activeImage.bgWidth ?? 100}%`,
                  height: `${activeImage.bgHeight ?? 100}%`,
                }}
                onMouseDown={(e) => {
                  e.stopPropagation();
                  const isCtrl = e.ctrlKey || e.metaKey;
                  let newSelectedIds: string[];
                  if (isCtrl) {
                    if (selectedLayerIds.includes("background")) {
                      newSelectedIds = selectedLayerIds.filter(id => id !== "background");
                    } else {
                      newSelectedIds = [...selectedLayerIds, "background"];
                    }
                  } else {
                    if (selectedLayerIds.includes("background")) {
                      newSelectedIds = selectedLayerIds;
                    } else {
                      newSelectedIds = ["background"];
                    }
                  }
                  
                  setSelectedLayerIds(newSelectedIds);
                  if (newSelectedIds.length > 0) {
                    setSelectedLayerId(newSelectedIds[newSelectedIds.length - 1]);
                  } else {
                    setSelectedLayerId(null);
                  }

                  setIsDraggingLayer(true);
                  
                  const starts: {[id: string]: { x: number, y: number }} = {};
                  if (activeImage) {
                    activeImage.layers.forEach((l) => {
                      if (newSelectedIds.includes(l.id)) {
                        starts[l.id] = { x: l.x, y: l.y };
                      }
                    });
                    if (newSelectedIds.includes("background")) {
                      starts["background"] = { x: activeImage.bgX ?? 0, y: activeImage.bgY ?? 0 };
                    }
                  }
                  setMultiDragStarts(starts);

                  setLayerDragStart({
                    x: e.clientX,
                    y: e.clientY,
                    layerX: activeImage.bgX ?? 0,
                    layerY: activeImage.bgY ?? 0,
                    layerW: activeImage.bgWidth ?? 100,
                    layerH: activeImage.bgHeight ?? 100,
                  });
                }}
              >
                <img
                  ref={imageRef}
                  src={activeImage.url}
                  alt={activeImage.name}
                  style={{ ...filterStyles, ...transformStyles }}
                  className="w-full h-full object-cover pointer-events-none select-none rounded-lg"
                  referrerPolicy="no-referrer"
                />
                
                {/* Resize Handles for background photo */}
                {selectedLayerId === "background" && (
                  <>
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setIsResizingLayer(true);
                        setActiveLayerHandle("nw");
                        setLayerDragStart({
                          x: e.clientX,
                          y: e.clientY,
                          layerX: activeImage.bgX ?? 0,
                          layerY: activeImage.bgY ?? 0,
                          layerW: activeImage.bgWidth ?? 100,
                          layerH: activeImage.bgHeight ?? 100,
                        });
                      }}
                      className="absolute -top-1.5 -left-1.5 w-3.5 h-3.5 bg-white border-2 border-violet-500 rounded-full cursor-nwse-resize z-20"
                    />
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setIsResizingLayer(true);
                        setActiveLayerHandle("ne");
                        setLayerDragStart({
                          x: e.clientX,
                          y: e.clientY,
                          layerX: activeImage.bgX ?? 0,
                          layerY: activeImage.bgY ?? 0,
                          layerW: activeImage.bgWidth ?? 100,
                          layerH: activeImage.bgHeight ?? 100,
                        });
                      }}
                      className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 bg-white border-2 border-violet-500 rounded-full cursor-nesw-resize z-20"
                    />
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setIsResizingLayer(true);
                        setActiveLayerHandle("sw");
                        setLayerDragStart({
                          x: e.clientX,
                          y: e.clientY,
                          layerX: activeImage.bgX ?? 0,
                          layerY: activeImage.bgY ?? 0,
                          layerW: activeImage.bgWidth ?? 100,
                          layerH: activeImage.bgHeight ?? 100,
                        });
                      }}
                      className="absolute -bottom-1.5 -left-1.5 w-3.5 h-3.5 bg-white border-2 border-violet-500 rounded-full cursor-nesw-resize z-20"
                    />
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setIsResizingLayer(true);
                        setActiveLayerHandle("se");
                        setLayerDragStart({
                          x: e.clientX,
                          y: e.clientY,
                          layerX: activeImage.bgX ?? 0,
                          layerY: activeImage.bgY ?? 0,
                          layerW: activeImage.bgWidth ?? 100,
                          layerH: activeImage.bgHeight ?? 100,
                        });
                      }}
                      className="absolute -bottom-1.5 -right-1.5 w-3.5 h-3.5 bg-white border-2 border-violet-500 rounded-full cursor-nwse-resize z-20"
                    />
                  </>
                )}
              </div>
            ) : (
              <img
                ref={imageRef}
                src={activeImage.url}
                alt={activeImage.name}
                style={{ ...filterStyles, ...transformStyles }}
                className="w-full h-full object-contain pointer-events-none select-none transition-all duration-200"
                referrerPolicy="no-referrer"
              />
            )}
          </div>

          {/* Double Exposure Texture Overlay */}
          {activeImage.overlayUrl && (
            <div
              className="absolute inset-0 pointer-events-none overflow-hidden z-10"
              style={{
                ...getCroppedImageStyle(),
                opacity: (activeImage.overlayOpacity || 40) / 100,
                mixBlendMode: "screen",
              }}
            >
              <img
                src={activeImage.overlayUrl}
                alt="Double Exposure Overlay Texture"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {/* Cyber Neon Glow backlight layer */}
          {activeImage.showNeonGlow && (
            <div
              className="absolute inset-0 pointer-events-none z-10"
              style={{
                ...getCroppedImageStyle(),
                background: "linear-gradient(135deg, rgba(236, 72, 153, 0.35) 0%, rgba(139, 92, 246, 0.35) 50%, rgba(6, 182, 212, 0.35) 100%)",
                mixBlendMode: "color-dodge",
              }}
            />
          )}

          {/* Bokeh Overlay layer */}
          {activeImage.showBokeh && (
            <div
              className="absolute inset-0 pointer-events-none overflow-hidden z-20"
              style={getCroppedImageStyle()}
            >
              <svg className="w-full h-full opacity-65">
                <circle cx="20%" cy="30%" r="35" fill="rgba(253, 186, 116, 0.4)" filter="blur(8px)" />
                <circle cx="75%" cy="25%" r="50" fill="rgba(244, 114, 182, 0.35)" filter="blur(12px)" />
                <circle cx="45%" cy="65%" r="65" fill="rgba(254, 215, 170, 0.45)" filter="blur(10px)" />
                <circle cx="85%" cy="80%" r="40" fill="rgba(196, 181, 253, 0.3)" filter="blur(6px)" />
                <circle cx="15%" cy="85%" r="30" fill="rgba(251, 113, 133, 0.25)" filter="blur(5px)" />
                <circle cx="60%" cy="45%" r="25" fill="rgba(253, 224, 71, 0.35)" filter="blur(4px)" />
              </svg>
            </div>
          )}

          {/* Color Splash Isolate layer */}
          {activeImage.colorSplashIsolate && (
            <div
              className="absolute inset-0 pointer-events-none z-10"
              style={{
                ...getCroppedImageStyle(),
                background: activeImage.colorSplashIsolate === "red" 
                  ? "radial-gradient(circle, rgba(239, 68, 68, 0.35) 0%, transparent 70%)"
                  : activeImage.colorSplashIsolate === "blue"
                  ? "radial-gradient(circle, rgba(59, 130, 246, 0.35) 0%, transparent 70%)"
                  : activeImage.colorSplashIsolate === "yellow"
                  ? "radial-gradient(circle, rgba(234, 179, 8, 0.35) 0%, transparent 70%)"
                  : "radial-gradient(circle, rgba(16, 185, 129, 0.35) 0%, transparent 70%)",
                mixBlendMode: "overlay",
              }}
            />
          )}

          {/* Temperature/Vignette and Tint filter blend layer */}
          <div
            className="absolute inset-0 pointer-events-none rounded-2xl z-10"
            style={{ ...getOverlayStyle(), ...getCroppedImageStyle() }}
          />

          {/* Mask Drawing Overlay (Active for Remove Obj, AI Replace and Retouching tools) */}
          {isBrushTool && (
            <div
              className="absolute inset-0 z-30 select-none"
              style={{ cursor: "none" }}
              onMouseDown={handleBrushMouseDown}
              onMouseMove={handleBrushMouseMove}
              onMouseUp={handleBrushMouseUp}
              onMouseLeave={() => {
                handleBrushMouseUp();
                setIsHovering(false);
              }}
              onMouseEnter={() => setIsHovering(true)}
            >
              <svg className="w-full h-full absolute inset-0 pointer-events-none">
                {brushStrokes.map((stroke, index) => {
                  if (stroke.points.length < 1) return null;
                  const pathData = stroke.points
                    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x}% ${p.y}%`)
                    .join(" ");

                  return (
                    <path
                      key={index}
                      d={pathData}
                      fill="none"
                      stroke={getBrushColor(0.45)}
                      strokeWidth={`${brushSize / 4}%`}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  );
                })}

                {/* Circular indicator showing current brush diameter on hover */}
                {isHovering && (
                  <circle
                    cx={`${mousePos.x}%`}
                    cy={`${mousePos.y}%`}
                    r={`${brushSize / 8}%`}
                    fill="none"
                    stroke={getBrushHexColor()}
                    strokeWidth="2"
                    strokeDasharray="4 2"
                  />
                )}
              </svg>
            </div>
          )}

          {/* Layer Elements Overlay */}
          {canvasMode !== "crop" && (
            <div className="absolute inset-0 pointer-events-none">
              {activeImage.layers.map((layer) => {
                const isSelected = selectedLayerIds.includes(layer.id);
                return (
                  <div
                    key={layer.id}
                    onMouseDown={(e) => handleLayerMouseDown(e, layer)}
                    className={`absolute flex items-center justify-center cursor-move transition-shadow pointer-events-auto ${
                      layer.id.includes("join-split") ? "p-0" : "p-1"
                    } ${
                      isSelected
                        ? layer.id.includes("join-split")
                          ? "ring-2 ring-violet-500 ring-inset bg-violet-500/10 shadow-lg"
                          : "border-2 border-violet-500 bg-violet-500/10 shadow-lg"
                        : layer.id.includes("join-split")
                        ? "border-0"
                        : "border border-transparent"
                    }`}
                    style={{
                      left: `${layer.x}%`,
                      top: `${layer.y}%`,
                      width: `${layer.width}%`,
                      height: `${layer.height}%`,
                      transform: layer.rotation ? `rotate(${layer.rotation}deg)` : undefined,
                    }}
                  >
                    {/* Delete layer button on top-right of active layer */}
                    {isSelected && (
                      <>
                        <button
                          onClick={deleteSelectedLayer}
                          className="absolute -top-3 -right-3 w-5 h-5 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md z-10"
                        >
                          <X className="w-3 h-3" />
                        </button>
                        
                        {/* Resize Handles */}
                        <div
                          onMouseDown={(e) => handleLayerResizeMouseDown(e, layer, "nw")}
                          className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-white border border-violet-500 rounded-full cursor-nwse-resize"
                        />
                        <div
                          onMouseDown={(e) => handleLayerResizeMouseDown(e, layer, "ne")}
                          className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-white border border-violet-500 rounded-full cursor-nesw-resize"
                        />
                        <div
                          onMouseDown={(e) => handleLayerResizeMouseDown(e, layer, "sw")}
                          className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-white border border-violet-500 rounded-full cursor-nesw-resize"
                        />
                        <div
                          onMouseDown={(e) => handleLayerResizeMouseDown(e, layer, "se")}
                          className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border border-violet-500 rounded-full cursor-nwse-resize"
                        />
                      </>
                    )}

                    {layer.type === "text" ? (
                      <input
                        type="text"
                        value={layer.text || ""}
                        disabled={!isSelected}
                        onChange={(e) => updateSelectedLayerText(e.target.value)}
                        className="bg-transparent text-center focus:outline-none w-full h-full font-bold select-text"
                        style={{ color: layer.color, fontSize: `${layer.fontSize || 16}px` }}
                      />
                    ) : layer.type === "rect" ? (
                      <div className="w-full h-full rounded border-2" style={{ borderColor: layer.color, backgroundColor: `${layer.color}22` }} />
                    ) : layer.type === "circle" ? (
                      <div className="w-full h-full rounded-full border-2" style={{ borderColor: layer.color, backgroundColor: `${layer.color}22` }} />
                    ) : layer.type === "star" ? (
                      <Star className="w-full h-full" style={{ fill: layer.color, stroke: layer.color }} />
                    ) : layer.type === "image" ? (
                      <div className={`relative w-full h-full overflow-hidden ${layer.id.includes("join-split") ? "" : "rounded"}`}>
                        <img 
                          src={layer.url} 
                          alt="Layer" 
                          className={`w-full h-full object-cover pointer-events-none ${layer.id.includes("join-split") ? "" : "rounded"}`} 
                          style={getLayerFilterStyle(layer)}
                        />
                        {layer.adjustments && (
                          <div 
                            className={`absolute inset-0 pointer-events-none ${layer.id.includes("join-split") ? "" : "rounded"}`} 
                            style={getLayerOverlayStyle(layer.adjustments)}
                          />
                        )}
                      </div>
                    ) : (
                      <ArrowRight className="w-full h-full" style={{ color: layer.color }} />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ----------------------------------------------------
            INTERACTIVE CROP GRID OVERLAY (visible in crop mode)
            ---------------------------------------------------- */}
        {canvasMode === "crop" && (
          <div
            ref={cropBoxRef}
            className="absolute border border-white cursor-move bg-black/40 shadow-xl"
            style={{
              left: `${cropBox.x}%`,
              top: `${cropBox.y}%`,
              width: `${cropBox.width}%`,
              height: `${cropBox.height}%`,
            }}
            onMouseDown={(e) => handleCropMouseDown(e, "move")}
          >
            {/* Rule-of-thirds helper lines */}
            <div className="absolute inset-x-0 top-1/3 bottom-1/3 border-y border-white/20 pointer-events-none" />
            <div className="absolute inset-y-0 left-1/3 right-1/3 border-x border-white/20 pointer-events-none" />

            {/* Corner Crop drag Handles */}
            <div
              className="absolute w-3.5 h-3.5 bg-white border border-slate-900 rounded-sm -top-1.5 -left-1.5 cursor-nwse-resize hover:scale-125 transition-transform"
              onMouseDown={(e) => handleCropMouseDown(e, "nw")}
            />
            <div
              className="absolute w-3.5 h-3.5 bg-white border border-slate-900 rounded-sm -top-1.5 -right-1.5 cursor-nesw-resize hover:scale-125 transition-transform"
              onMouseDown={(e) => handleCropMouseDown(e, "ne")}
            />
            <div
              className="absolute w-3.5 h-3.5 bg-white border border-slate-900 rounded-sm -bottom-1.5 -left-1.5 cursor-nesw-resize hover:scale-125 transition-transform"
              onMouseDown={(e) => handleCropMouseDown(e, "sw")}
            />
            <div
              className="absolute w-3.5 h-3.5 bg-white border border-slate-900 rounded-sm -bottom-1.5 -right-1.5 cursor-nwse-resize hover:scale-125 transition-transform"
              onMouseDown={(e) => handleCropMouseDown(e, "se")}
            />

            {/* Edge Handles */}
            <div
              className="absolute w-4 h-1.5 bg-white border border-slate-900 rounded-full -top-1 left-1/2 -translate-x-1/2 cursor-ns-resize"
              onMouseDown={(e) => handleCropMouseDown(e, "n")}
            />
            <div
              className="absolute w-4 h-1.5 bg-white border border-slate-900 rounded-full -bottom-1 left-1/2 -translate-x-1/2 cursor-ns-resize"
              onMouseDown={(e) => handleCropMouseDown(e, "s")}
            />
            <div
              className="absolute w-1.5 h-4 bg-white border border-slate-900 rounded-full -left-1 top-1/2 -translate-y-1/2 cursor-ew-resize"
              onMouseDown={(e) => handleCropMouseDown(e, "w")}
            />
            <div
              className="absolute w-1.5 h-4 bg-white border border-slate-900 rounded-full -right-1 top-1/2 -translate-y-1/2 cursor-ew-resize"
              onMouseDown={(e) => handleCropMouseDown(e, "e")}
            />

            {/* Bottom floating helper box inside crop area */}
            <div className="absolute -bottom-14 left-1/2 -translate-x-1/2 bg-white border border-slate-200 rounded-xl px-4 py-1.5 flex items-center gap-3 shadow-xl text-xs whitespace-nowrap z-50">
              <span className="font-mono text-[10px] text-slate-500">
                {Math.round(cropBox.width)}% × {Math.round(cropBox.height)}%
              </span>
              <div className="h-3 w-px bg-slate-200" />
              <button
                onClick={resetCrop}
                className="text-slate-500 hover:text-slate-900 transition-all text-[11px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={applyCrop}
                className="text-violet-600 hover:text-violet-700 font-bold transition-all text-[11px] cursor-pointer"
              >
                Apply Crop
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Text layer tools toolbar overlay */}
      {selectedLayerId && canvasMode !== "crop" && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white border border-slate-200 rounded-2xl p-3.5 flex items-center gap-4 shadow-2xl z-50 animate-fade-in font-sans">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Color</span>
            <div className="flex items-center gap-1.5">
              {["#ffffff", "#ef4444", "#3b82f6", "#10b981", "#f59e0b", "#7c3aed", "#ec4899"].map((c) => (
                <button
                  key={c}
                  onClick={() => updateSelectedLayerColor(c)}
                  className="w-5 h-5 rounded-full border border-slate-300 shadow-sm cursor-pointer transition-transform hover:scale-110 active:scale-95"
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="h-4 w-px bg-slate-200" />

          <button
            onClick={deleteSelectedLayer}
            className="flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-semibold cursor-pointer hover:bg-rose-50 px-2 py-1 rounded-lg transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete
          </button>
        </div>
      )}

      {/* ----------------------------------------------------
          BOTTOM FLOATING WORKSPACE TOOLBAR (Selector, Pan, Zoom)
          ---------------------------------------------------- */}
      {canvasMode !== "crop" && (
        <div id="canvas-floating-controls" className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white border border-slate-200 rounded-2xl px-5 py-2 flex items-center gap-3.5 shadow-2xl z-40 shrink-0 select-none">
          {/* Select Pointer */}
          <button
            onClick={() => setCanvasMode("select")}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              canvasMode === "select"
                ? "bg-violet-600 text-white"
                : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
            }`}
            title="Select & Move Layers"
          >
            <MousePointer className="w-4 h-4" />
          </button>

          {/* Pan Hand */}
          <button
            onClick={() => setCanvasMode("pan")}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              canvasMode === "pan"
                ? "bg-violet-600 text-white"
                : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
            }`}
            title="Pan Workspace"
          >
            <Hand className="w-4 h-4" />
          </button>

          {/* Add Text overlay helper */}
          <button
            onClick={addTextLayer}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-all cursor-pointer"
            title="Add Text Layer"
          >
            <Type className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-slate-200" />

          {/* Quick Shape Overlay Selector */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => addElementLayer("rect")}
              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition-all cursor-pointer"
              title="Add Rectangle"
            >
              <Square className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => addElementLayer("circle")}
              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition-all cursor-pointer"
              title="Add Circle"
            >
              <Circle className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => addElementLayer("star")}
              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition-all cursor-pointer"
              title="Add Star"
            >
              <Star className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200" />

          {/* Crop Tool Shortcut */}
          <button
            onClick={() => setCanvasMode("crop")}
            className="p-2 rounded-xl transition-all cursor-pointer text-slate-500 hover:text-slate-900 hover:bg-slate-100"
            title="Crop & Grid Overlay"
          >
            <Crop className="w-4 h-4" />
          </button>

          {/* Delete Active Crop */}
          {activeImage.crop && (
            <button
              onClick={resetCrop}
              className="p-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-all cursor-pointer"
              title="Remove Crop"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* Invisible SVG for Dynamic Clarity/Sharpen Filters */}
      <svg style={{ width: 0, height: 0, position: 'absolute' }} aria-hidden="true" focusable="false">
        {/* Main background image filter */}
        <filter id="mainClarityFilter">
          <feConvolveMatrix
            order="3 3"
            preserveAlpha="true"
            kernelMatrix={`0 ${-mainClarityAmount} 0 ${-mainClarityAmount} ${1 + 4 * mainClarityAmount} ${-mainClarityAmount} 0 ${-mainClarityAmount} 0`}
          />
        </filter>
        {/* Dynamic filter for each image layer */}
        {activeImage.layers.filter(l => l.type === "image").map(layer => {
          const lAdj = layer.adjustments;
          const layerAmount = lAdj ? ((lAdj.clarity || 0) * 0.6 + (lAdj.sharpen || 0) * 0.9) / 100 : 0;
          return (
            <filter id={`clarityFilter-${layer.id}`} key={layer.id}>
              <feConvolveMatrix
                order="3 3"
                preserveAlpha="true"
                kernelMatrix={`0 ${-layerAmount} 0 ${-layerAmount} ${1 + 4 * layerAmount} ${-layerAmount} 0 ${-layerAmount} 0`}
              />
            </filter>
          );
        })}
      </svg>
    </div>
  );
}

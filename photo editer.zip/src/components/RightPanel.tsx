import React from "react";
import {
  Sun,
  Contrast as ContrastIcon,
  Sparkles,
  RotateCcw,
  Palette,
  Droplet,
  Flame,
  Eye,
  Heart,
  Lightbulb,
  SlidersHorizontal,
} from "lucide-react";
import { Adjustments } from "../types";

interface RightPanelProps {
  adjustments: Adjustments;
  onChange: (adjustments: Adjustments) => void;
  onReset: () => void;
  aiFeedback: {
    analysis: string;
    tips: string[];
  } | null;
  isAIProcessing: boolean;
  onSavePreset: () => void;
  onApplyImage: () => void;
  isLayerSelected?: boolean;
}

export default function RightPanel({
  adjustments,
  onChange,
  onReset,
  aiFeedback,
  isAIProcessing,
  onSavePreset,
  onApplyImage,
  isLayerSelected = false,
}: RightPanelProps) {
  const handleSliderChange = (key: keyof Adjustments, value: number) => {
    onChange({
      ...adjustments,
      [key]: value,
    });
  };

  const lightSliders = [
    { key: "brightness" as keyof Adjustments, label: "Brightness", min: -100, max: 100 },
    { key: "contrast" as keyof Adjustments, label: "Contrast", min: -100, max: 100 },
    { key: "highlights" as keyof Adjustments, label: "Highlights", min: -100, max: 100 },
    { key: "shadows" as keyof Adjustments, label: "Shadows", min: -100, max: 100 },
    { key: "whites" as keyof Adjustments, label: "Whites", min: -100, max: 100 },
    { key: "blacks" as keyof Adjustments, label: "Blacks", min: -100, max: 100 },
  ];

  const colorSliders = [
    { key: "vibrance" as keyof Adjustments, label: "Vibrance", min: -100, max: 100, trackClass: "bg-gradient-to-r from-teal-500 via-violet-500 to-pink-500" },
    { key: "saturation" as keyof Adjustments, label: "Saturation", min: -100, max: 100, trackClass: "bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500" },
    { key: "temperature" as keyof Adjustments, label: "Temperature", min: -100, max: 100, trackClass: "bg-gradient-to-r from-cyan-500 via-slate-400 to-amber-500" },
    { key: "tint" as keyof Adjustments, label: "Tint", min: -100, max: 100, trackClass: "bg-gradient-to-r from-emerald-500 via-slate-400 to-fuchsia-500" },
  ];

  const effectSliders = [
    { key: "clarity" as keyof Adjustments, label: "Clarity", min: -100, max: 100 },
    { key: "sharpen" as keyof Adjustments, label: "Sharpen", min: 0, max: 100 },
    { key: "dehaze" as keyof Adjustments, label: "Dehaze", min: -100, max: 100 },
    { key: "vignette" as keyof Adjustments, label: "Vignette", min: 0, max: 100 },
  ];

  return (
    <div id="right-adjust-panel" className="w-80 bg-white border-l border-slate-200 flex flex-col h-full overflow-y-auto font-sans select-none scrollbar-thin">
      {/* Header */}
      <div className="p-5 border-b border-slate-200 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-violet-600" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
            {isLayerSelected ? "Layer Adjust" : "Adjustments"}
          </span>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-1 text-slate-500 hover:text-slate-900 hover:bg-slate-100 px-2 py-1 rounded-lg text-xs transition-all cursor-pointer font-semibold"
        >
          <RotateCcw className="w-3 h-3 text-slate-500" />
          Reset
        </button>
      </div>

      <div className="flex-1 p-5 space-y-6">
        {/* Gemini AI Suggestions Panel */}
        {(isAIProcessing || aiFeedback) && (
          <div className="bg-violet-50/70 border border-violet-200 rounded-2xl p-4 space-y-3 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-violet-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-600 animate-spin-slow shrink-0" />
              <span className="font-bold text-xs text-violet-950 tracking-wide">
                Gemini AI Smart Retoucher
              </span>
            </div>

            {isAIProcessing ? (
              <div className="py-2 space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                  <span className="w-1.5 h-1.5 bg-violet-500 rounded-full animate-ping" />
                  Analyzing image histogram & elements...
                </div>
                <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                  <div className="bg-gradient-to-r from-violet-500 to-indigo-500 h-1 rounded-full animate-shimmer w-2/3" />
                </div>
              </div>
            ) : (
              aiFeedback && (
                <div className="space-y-3">
                  <p className="text-[11px] leading-relaxed text-violet-900 bg-violet-100/30 p-2.5 rounded-xl border border-violet-200/50 font-medium">
                    "{aiFeedback.analysis}"
                  </p>
                  {aiFeedback.tips && aiFeedback.tips.length > 0 && (
                    <div className="space-y-1.5 pt-1.5 border-t border-violet-100">
                      <div className="text-[10px] font-bold text-violet-700 uppercase tracking-wider flex items-center gap-1">
                        <Lightbulb className="w-3 h-3 text-amber-500" /> Professional Tips
                      </div>
                      <ul className="space-y-1 text-[10px] text-slate-600 pl-1 font-medium">
                        {aiFeedback.tips.map((tip, idx) => (
                          <li key={idx} className="leading-relaxed list-disc list-inside">
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )
            )}
          </div>
        )}

        {/* Light Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-slate-500" />
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Light</h3>
          </div>

          <div className="space-y-3.5 pl-1">
            {lightSliders.map((slider) => {
              const val = adjustments[slider.key];
              return (
                <div key={slider.key} className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500 font-semibold">
                    <span>{slider.label}</span>
                    <span className="text-slate-800 font-bold font-mono">
                      {val > 0 ? `+${val}` : val}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={slider.min}
                    max={slider.max}
                    value={val}
                    onChange={(e) => handleSliderChange(slider.key, parseInt(e.target.value))}
                    className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer hover:bg-slate-300 transition-all outline-none accent-violet-600"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-slate-200" />

        {/* Color Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-slate-500" />
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Color</h3>
          </div>

          <div className="space-y-3.5 pl-1">
            {colorSliders.map((slider) => {
              const val = adjustments[slider.key];
              return (
                <div key={slider.key} className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500 font-semibold">
                    <span>{slider.label}</span>
                    <span className="text-slate-800 font-bold font-mono">
                      {val > 0 ? `+${val}` : val}
                    </span>
                  </div>
                  <div className="relative flex items-center h-4">
                    <div className={`absolute left-0 right-0 h-1 rounded-full opacity-35 ${slider.trackClass}`} />
                    <input
                      type="range"
                      min={slider.min}
                      max={slider.max}
                      value={val}
                      onChange={(e) => handleSliderChange(slider.key, parseInt(e.target.value))}
                      className="w-full h-1 rounded-lg appearance-none cursor-pointer bg-transparent relative z-10 outline-none accent-violet-600"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-slate-200" />

        {/* Effects Section */}
        <div className="space-y-4 pb-4">
          <div className="flex items-center gap-2">
            <Droplet className="w-4 h-4 text-slate-500" />
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Effects</h3>
          </div>

          <div className="space-y-3.5 pl-1">
            {effectSliders.map((slider) => {
              const val = adjustments[slider.key];
              return (
                <div key={slider.key} className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500 font-semibold">
                    <span>{slider.label}</span>
                    <span className="text-slate-800 font-bold font-mono">
                      {val > 0 ? `+${val}` : val}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={slider.min}
                    max={slider.max}
                    value={val}
                    onChange={(e) => handleSliderChange(slider.key, parseInt(e.target.value))}
                    className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer hover:bg-slate-300 transition-all outline-none accent-violet-600"
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-2 shrink-0">
        <button
          onClick={onSavePreset}
          className="w-full py-2.5 border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 text-xs font-semibold rounded-xl transition-all cursor-pointer active:scale-98"
        >
          Save as Preset
        </button>
        <button
          onClick={onApplyImage}
          className="w-full py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-lg shadow-violet-500/10 cursor-pointer active:scale-98"
        >
          Apply to Image
        </button>
      </div>
    </div>
  );
}

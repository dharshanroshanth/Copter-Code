import React from "react";
import {
  LayoutDashboard,
  Wand2,
  Sparkles,
  Sliders,
  Play,
  Layout,
  FolderOpen,
  FileImage,
  Briefcase,
  Settings,
  Crown,
  CheckCircle2,
  HardDrive,
  FolderClosed,
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onUpgradeClick?: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, onUpgradeClick }: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "quick_tools", label: "Quick Tools", icon: Wand2 },
    { id: "ai_studio", label: "AI Studio", icon: Sparkles },
    { id: "editor", label: "Editor", icon: Sliders },
    { id: "creator_studio", label: "Creator Studio", icon: Play },
    { id: "templates", label: "Templates", icon: Layout },
    { id: "projects", label: "Projects", icon: FolderOpen },
    { id: "files", label: "Files", icon: FileImage },
    { id: "workspace", label: "Workspace", icon: Briefcase },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside id="app-sidebar" className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen select-none shrink-0 font-sans">
      {/* Brand Header */}
      <div className="h-16 flex items-center px-6 border-b border-slate-200 gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-violet-500/20">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <span className="font-display font-bold text-lg text-slate-900 tracking-wide">
          PhotoToolkit
        </span>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer ${
                isActive
                  ? "bg-violet-600/10 text-violet-700 font-semibold border-l-2 border-violet-600 pl-2.5"
                  : "text-slate-500 hover:text-slate-950 hover:bg-slate-50"
              }`}
            >
              <IconComponent className={`w-4 h-4 shrink-0 ${isActive ? "text-violet-600" : "text-slate-400"}`} />
              {item.label}
            </button>
          );
        })}
      </nav>



      {/* Storage Widget */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 shrink-0 font-sans">
        <div className="flex justify-between text-xs font-medium text-slate-500 mb-1.5">
          <span>Storage</span>
          <span className="text-slate-700 font-semibold">8.2 GB of 20 GB used</span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden mb-3">
          <div className="bg-violet-600 h-1.5 rounded-full" style={{ width: "41%" }} />
        </div>
        <button
          id="manage-storage-btn"
          className="w-full flex items-center justify-center gap-2 py-1.5 px-3 border border-slate-200 hover:bg-slate-100 rounded-xl text-xs font-semibold text-slate-600 transition-all duration-200 cursor-pointer"
        >
          <HardDrive className="w-3.5 h-3.5 text-slate-500" />
          Manage Storage
        </button>
      </div>
    </aside>
  );
}

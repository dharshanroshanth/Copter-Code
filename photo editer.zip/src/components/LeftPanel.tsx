import React, { useState } from "react";
import {
  Crop,
  Maximize2,
  RotateCw,
  FlipHorizontal,
  ChevronDown,
  ChevronUp,
  SlidersHorizontal,
  Palette,
  Wand2,
  Type,
  Component,
  Grid3X3,
  Sparkles,
  Scissors,
  ScanFace,
  Brush,
  RefreshCw,
  Image,
  Check,
  Plus,
  Trash2,
  Square,
  Circle,
  Star,
  ArrowRight,
  RefreshCcw,
  Aperture,
  ImagePlus,
  Columns2,
  Split,
} from "lucide-react";
import { ToolType, ProjectImage, CanvasMode, Layer } from "../types";

interface LeftPanelProps {
  activeTool: ToolType | null;
  setActiveTool: (tool: ToolType | null) => void;
  onAIEnhance: () => void;
  onAIBgRemove: () => void;
  onAIReimagineClick: (customPrompt?: string) => void;
  isAIProcessing: boolean;
  activeImage: ProjectImage | null;
  onUpdateImage: (updates: Partial<ProjectImage>) => void;
  canvasMode: CanvasMode;
  setCanvasMode: (mode: CanvasMode) => void;
  brushSize: number;
  setBrushSize: (size: number) => void;
  brushStrokes: any[];
  setBrushStrokes: (strokes: any[]) => void;
  aiReplacePrompt: string;
  setAiReplacePrompt: (prompt: string) => void;
  aiEnhanceIntensity: number;
  setAiEnhanceIntensity: (intensity: number) => void;
  onAIMagicErase: (healMode?: string, denoiseFactor?: number) => void;
  onAIReplaceSubmit: (designTheme?: string) => void;
  onAIExpand: (aspectRatio: string) => void;
  selectedLayerId?: string | null;
  setSelectedLayerId?: (id: string | null) => void;
  selectedLayerIds?: string[];
  setSelectedLayerIds?: (ids: string[]) => void;
}

export default function LeftPanel({
  activeTool,
  setActiveTool,
  onAIEnhance,
  onAIBgRemove,
  onAIReimagineClick,
  isAIProcessing,
  activeImage,
  onUpdateImage,
  canvasMode,
  setCanvasMode,
  brushSize,
  setBrushSize,
  brushStrokes,
  setBrushStrokes,
  aiReplacePrompt,
  setAiReplacePrompt,
  aiEnhanceIntensity,
  setAiEnhanceIntensity,
  onAIMagicErase,
  onAIReplaceSubmit,
  onAIExpand,
  selectedLayerId,
  setSelectedLayerId,
  selectedLayerIds = [],
  setSelectedLayerIds = () => {},
}: LeftPanelProps) {
  const [sections, setSections] = useState({
    retouch: false,
    color: false,
    creative: false,
  });

  // Local state for Resize Inputs
  const [resizeWidth, setResizeWidth] = useState<number>(activeImage?.width || 1920);
  const [resizeHeight, setResizeHeight] = useState<number>(activeImage?.height || 1080);
  const [lockAspectRatio, setLockAspectRatio] = useState<boolean>(true);

  // Fine-tuning parameters for improved AI Tools
  const [healMode, setHealMode] = useState<string>("Content-Aware (Fine)");
  const [denoiseFactor, setDenoiseFactor] = useState<number>(45);
  const [designTheme, setDesignTheme] = useState<string>("Minimalist Light");
  const [joinOption, setJoinOption] = useState<"freeform" | "split">("freeform");
  const [splitPercent, setSplitPercent] = useState<number>(50);

  const updateClarityAndSharpen = (clarityVal: number, sharpenVal: number) => {
    if (!activeImage) return;
    if (selectedLayerIds.length > 1) {
      const updatedLayers = activeImage.layers.map(l => {
        if (selectedLayerIds.includes(l.id)) {
          return {
            ...l,
            adjustments: {
              ...(l.adjustments || {
                brightness: 0,
                contrast: 0,
                saturation: 0,
                vibrance: 0,
                temperature: 0,
                tint: 0,
                shadows: 0,
                highlights: 0,
                whites: 0,
                blacks: 0,
                dehaze: 0,
                vignette: 0,
                clarity: 0,
                sharpen: 0,
              }),
              clarity: clarityVal,
              sharpen: sharpenVal,
            }
          };
        }
        return l;
      });
      const updatedBg = selectedLayerIds.includes("background")
        ? {
            ...activeImage.adjustments,
            clarity: clarityVal,
            sharpen: sharpenVal,
          }
        : activeImage.adjustments;
      onUpdateImage({
        layers: updatedLayers,
        adjustments: updatedBg,
      });
    } else if (selectedLayerId) {
      const updatedLayers = activeImage.layers.map(l => {
        if (l.id === selectedLayerId) {
          return {
            ...l,
            adjustments: {
              ...(l.adjustments || {
                brightness: 0,
                contrast: 0,
                saturation: 0,
                vibrance: 0,
                temperature: 0,
                tint: 0,
                shadows: 0,
                highlights: 0,
                whites: 0,
                blacks: 0,
                dehaze: 0,
                vignette: 0,
                clarity: 0,
                sharpen: 0,
              }),
              clarity: clarityVal,
              sharpen: sharpenVal,
            }
          };
        }
        return l;
      });
      onUpdateImage({ layers: updatedLayers });
    } else {
      onUpdateImage({
        adjustments: {
          ...activeImage.adjustments,
          clarity: clarityVal,
          sharpen: sharpenVal,
        }
      });
    }
  };

  const toggleSection = (section: "retouch" | "color" | "creative") => {
    setSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const basicToolsList = [
    { id: "crop" as ToolType, label: "Crop", icon: Crop },
    { id: "resize" as ToolType, label: "Resize", icon: Maximize2 },
    { id: "rotate" as ToolType, label: "Rotate", icon: RotateCw },
    { id: "flip" as ToolType, label: "Flip", icon: FlipHorizontal },
    { id: "straighten" as ToolType, label: "Straighten", icon: Grid3X3 },
    { id: "perspective" as ToolType, label: "Perspective", icon: Component },
    { id: "adjust" as ToolType, label: "Adjust", icon: SlidersHorizontal },
    { id: "filters" as ToolType, label: "Filters", icon: Palette },
    { id: "effects" as ToolType, label: "Effects", icon: Wand2 },
    { id: "text" as ToolType, label: "Text", icon: Type },
    { id: "elements" as ToolType, label: "Elements", icon: Component },
    { id: "frames" as ToolType, label: "Frames", icon: Image },
    { id: "clarity" as ToolType, label: "4k Clarity", icon: Aperture },
    { id: "join" as ToolType, label: "Join Photos", icon: ImagePlus },
  ];

  const aiToolsList = [
    {
      id: "enhance" as ToolType,
      label: "Enhance",
      icon: Sparkles,
      onClick: () => {
        onAIEnhance();
      },
      color: "from-violet-500 to-fuchsia-500",
    },
    {
      id: "bg_remover" as ToolType,
      label: "BG Remover",
      icon: Scissors,
      onClick: () => {
        onAIBgRemove();
      },
      color: "from-indigo-500 to-violet-500",
    },
    {
      id: "expand" as ToolType,
      label: "Expand",
      icon: Maximize2,
      onClick: () => {},
      color: "from-violet-500 to-indigo-500",
    },
    {
      id: "remove_obj" as ToolType,
      label: "Remove Obj.",
      icon: Brush,
      onClick: () => {},
      color: "from-violet-500 to-fuchsia-500",
    },
    {
      id: "reimagine" as ToolType,
      label: "Reimagine",
      icon: RefreshCw,
      onClick: () => {},
      color: "from-fuchsia-500 to-pink-500",
    },
    {
      id: "ai_replace" as ToolType,
      label: "AI Replace",
      icon: Sparkles,
      onClick: () => {},
      color: "from-purple-500 to-violet-500",
    },
  ];

  if (!activeImage) {
    return (
      <div id="left-tools-panel" className="w-80 bg-white border-r border-slate-200 flex flex-col h-full items-center justify-center p-6 text-center select-none">
        <p className="text-xs text-slate-400">Select or upload a photo to enable toolsets</p>
      </div>
    );
  }

  // ----------------------------------------------------
  // INDIVIDUAL ACTION HELPERS FOR BASIC TOOLS
  // ----------------------------------------------------
  const handleUpdateTransform = (updates: any) => {
    onUpdateImage({
      transform: { ...activeImage.transform, ...updates }
    });
  };

  const handleApplyResize = () => {
    onUpdateImage({ width: resizeWidth, height: resizeHeight });
    alert(`Success: Image resolution successfully resized to ${resizeWidth} x ${resizeHeight} pixels!`);
  };

  const handleWidthChange = (val: number) => {
    setResizeWidth(val);
    if (lockAspectRatio) {
      const ratio = activeImage.height / activeImage.width;
      setResizeHeight(Math.round(val * ratio));
    }
  };

  const handleHeightChange = (val: number) => {
    setResizeHeight(val);
    if (lockAspectRatio) {
      const ratio = activeImage.width / activeImage.height;
      setResizeWidth(Math.round(val * ratio));
    }
  };

  const handleAddText = () => {
    const newLayer: Layer = {
      id: `text-${Date.now()}`,
      type: "text",
      x: 35,
      y: 40,
      width: 30,
      height: 12,
      color: "#000000",
      text: "Double-click to type",
      fontSize: 16,
    };
    onUpdateImage({ layers: [...activeImage.layers, newLayer] });
  };

  const handleAddShape = (shapeType: 'rect' | 'circle' | 'arrow' | 'star') => {
    const newLayer: Layer = {
      id: `elem-${Date.now()}`,
      type: shapeType,
      x: 40,
      y: 40,
      width: 15,
      height: 15,
      color: "#f43f5e",
    };
    onUpdateImage({ layers: [...activeImage.layers, newLayer] });
  };

  return (
    <div id="left-tools-panel" className="w-80 bg-white border-r border-slate-200 flex flex-col h-full overflow-y-auto font-sans select-none scrollbar-thin">
      <div className="p-5 space-y-6">
        {/* Basic Tools Section */}
        <div>
          <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
            Basic Tools
          </h2>
          <div className="grid grid-cols-3 gap-2">
            {basicToolsList.map((tool) => {
              const IconComponent = tool.icon;
              const isActive = activeTool === tool.id;
              return (
                <button
                  key={tool.id}
                  id={`tool-btn-${tool.id}`}
                  onClick={() => {
                    setActiveTool(isActive ? null : tool.id);
                    if (tool.id === "crop") {
                      setCanvasMode("crop");
                    } else {
                      setCanvasMode("select");
                    }
                  }}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 aspect-square cursor-pointer hover:scale-102 ${
                    isActive
                      ? "bg-violet-600/10 border-violet-500/80 text-violet-600 shadow-md shadow-violet-500/5 font-semibold"
                      : "bg-slate-50 border-slate-200/60 text-slate-500 hover:text-slate-900 hover:border-slate-300 hover:bg-slate-100/50"
                  }`}
                >
                  <IconComponent className={`w-5 h-5 mb-1.5 ${isActive ? "text-violet-600" : "text-slate-400"}`} />
                  <span className="text-[10px] text-center font-medium truncate w-full">{tool.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ----------------------------------------------------
            DYNAMIC TOOL CONFIGURATION INTERFACES (ALL 12 BASIC TOOLS)
            ---------------------------------------------------- */}
        {activeTool && (
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4 animate-fade-in shrink-0">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <span className="text-xs font-bold text-slate-800 capitalize flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                {activeTool} Settings
              </span>
              <button
                onClick={() => setActiveTool(null)}
                className="text-[10px] text-slate-500 hover:text-slate-800 hover:bg-slate-200 px-2 py-1 rounded"
              >
                Close
              </button>
            </div>

            {/* CROP CONFIG */}
            {activeTool === "crop" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Drag the grid handles on the canvas or pick standard presets:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { label: "1:1 Square", crop: { x: 10, y: 10, width: 80, height: 80 } },
                    { label: "4:3 Standard", crop: { x: 10, y: 15, width: 80, height: 60 } },
                    { label: "16:9 Cinema", crop: { x: 5, y: 20, width: 90, height: 50 } },
                    { label: "Full Portrait", crop: { x: 25, y: 5, width: 50, height: 90 } },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      onClick={() => onUpdateImage({ crop: preset.crop })}
                      className="p-2 bg-white hover:bg-violet-50 rounded-lg text-[10px] text-slate-700 font-medium transition-all border border-slate-200 hover:border-violet-300 text-left"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      onUpdateImage({ crop: null });
                      setCanvasMode("select");
                    }}
                    className="flex-1 py-1.5 bg-slate-200 text-slate-700 text-[11px] font-semibold rounded-lg hover:bg-slate-300 hover:text-slate-900 transition-all"
                  >
                    Reset Crop
                  </button>
                  <button
                    onClick={() => setCanvasMode("select")}
                    className="flex-1 py-1.5 bg-violet-600 hover:bg-violet-500 text-white text-[11px] font-bold rounded-lg transition-all"
                  >
                    Done Cropping
                  </button>
                </div>
              </div>
            )}

            {/* RESIZE CONFIG */}
            {activeTool === "resize" && (
              <div className="space-y-3.5">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 flex justify-between">
                    <span>Width (px)</span>
                    <span className="text-violet-600 font-semibold">{resizeWidth}px</span>
                  </label>
                  <input
                    type="range"
                    min="320"
                    max="3840"
                    value={resizeWidth}
                    onChange={(e) => handleWidthChange(parseInt(e.target.value))}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 flex justify-between">
                    <span>Height (px)</span>
                    <span className="text-violet-600 font-semibold">{resizeHeight}px</span>
                  </label>
                  <input
                    type="range"
                    min="240"
                    max="2160"
                    value={resizeHeight}
                    onChange={(e) => handleHeightChange(parseInt(e.target.value))}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>

                <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer pt-1 select-none font-medium">
                  <input
                    type="checkbox"
                    checked={lockAspectRatio}
                    onChange={(e) => setLockAspectRatio(e.target.checked)}
                    className="rounded border-slate-300 text-violet-600 bg-white focus:ring-0 focus:ring-offset-0"
                  />
                  <span>Lock Aspect Ratio ({Math.round(activeImage.width)}:{Math.round(activeImage.height)})</span>
                </label>

                <button
                  onClick={handleApplyResize}
                  className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white text-[11px] font-bold rounded-lg transition-all shadow-md shadow-violet-600/10 active:scale-95"
                >
                  Apply New Dimensions
                </button>
              </div>
            )}

            {/* ROTATE CONFIG */}
            {activeTool === "rotate" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Stepwise rotation controls:</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleUpdateTransform({ rotate: (activeImage.transform.rotate + 270) % 360 })}
                    className="py-2 bg-white hover:bg-slate-100 text-xs text-slate-700 font-semibold rounded-lg hover:text-slate-900 border border-slate-200 transition-all flex items-center justify-center gap-1.5"
                  >
                    <RefreshCcw className="w-3.5 h-3.5 text-violet-500" />
                    Left 90°
                  </button>
                  <button
                    onClick={() => handleUpdateTransform({ rotate: (activeImage.transform.rotate + 90) % 360 })}
                    className="py-2 bg-white hover:bg-slate-100 text-xs text-slate-700 font-semibold rounded-lg hover:text-slate-900 border border-slate-200 transition-all flex items-center justify-center gap-1.5"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-violet-500" />
                    Right 90°
                  </button>
                </div>
                <button
                  onClick={() => handleUpdateTransform({ rotate: (activeImage.transform.rotate + 180) % 360 })}
                  className="w-full py-2 bg-white border border-slate-200 hover:bg-slate-100 text-xs text-slate-700 font-semibold rounded-lg hover:text-slate-950 transition-all text-center"
                >
                  Flip 180° Upside Down
                </button>
              </div>
            )}

            {/* FLIP CONFIG */}
            {activeTool === "flip" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Symmetrically invert photo directions:</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleUpdateTransform({ flipH: !activeImage.transform.flipH })}
                    className={`py-2 px-3 border rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeImage.transform.flipH
                        ? "bg-violet-100/50 border-violet-500 text-violet-700"
                        : "bg-white border-slate-200 text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Flip Horiz.
                  </button>
                  <button
                    onClick={() => handleUpdateTransform({ flipV: !activeImage.transform.flipV })}
                    className={`py-2 px-3 border rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeImage.transform.flipV
                        ? "bg-violet-100/50 border-violet-500 text-violet-700"
                        : "bg-white border-slate-200 text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    Flip Vert.
                  </button>
                </div>
              </div>
            )}

            {/* STRAIGHTEN CONFIG */}
            {activeTool === "straighten" && (
              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-slate-500">Straighten Angle</span>
                  <span className="text-xs font-bold text-violet-600">{activeImage.transform.straighten}°</span>
                </div>
                <input
                  type="range"
                  min="-45"
                  max="45"
                  value={activeImage.transform.straighten}
                  onChange={(e) => handleUpdateTransform({ straighten: parseInt(e.target.value) })}
                  className="w-full h-1.5 bg-slate-200 rounded-lg accent-violet-600 cursor-pointer"
                />
                <button
                  onClick={() => handleUpdateTransform({ straighten: 0 })}
                  className="w-full py-1.5 bg-slate-200 text-slate-600 hover:text-slate-900 rounded-lg text-[11px] font-semibold transition-all"
                >
                  Reset Straighten
                </button>
              </div>
            )}

            {/* PERSPECTIVE CONFIG */}
            {activeTool === "perspective" && (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 flex justify-between">
                    <span>3D Perspective Depth</span>
                    <span className="text-violet-600 font-semibold">{activeImage.transform.perspective || 0}%</span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={activeImage.transform.perspective || 0}
                    onChange={(e) => handleUpdateTransform({ perspective: parseInt(e.target.value) })}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 flex justify-between">
                    <span>Horizontal Rotate (Y)</span>
                    <span className="text-violet-600 font-semibold">{activeImage.transform.skewX || 0}°</span>
                  </label>
                  <input
                    type="range"
                    min="-30"
                    max="30"
                    value={activeImage.transform.skewX || 0}
                    onChange={(e) => handleUpdateTransform({ skewX: parseInt(e.target.value) })}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 flex justify-between">
                    <span>Vertical Rotate (X)</span>
                    <span className="text-violet-600 font-semibold">{activeImage.transform.skewY || 0}°</span>
                  </label>
                  <input
                    type="range"
                    min="-30"
                    max="30"
                    value={activeImage.transform.skewY || 0}
                    onChange={(e) => handleUpdateTransform({ skewY: parseInt(e.target.value) })}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>

                <button
                  onClick={() => handleUpdateTransform({ skewX: 0, skewY: 0, perspective: 0 })}
                  className="w-full py-1.5 bg-slate-200 text-slate-600 hover:text-slate-900 rounded-lg text-xs font-semibold transition-all"
                >
                  Reset 3D Transforms
                </button>
              </div>
            )}

            {/* ADJUST HINT */}
            {activeTool === "adjust" && (
              <div className="space-y-2.5">
                <p className="text-[11px] text-slate-500">All precision sliders (Brightness, Contrast, Temperature, Shadow detail) are loaded on the right-side control pane!</p>
                <div className="p-2.5 bg-violet-50 border border-violet-100 rounded-xl space-y-1.5">
                  <span className="text-[10px] font-bold text-violet-600 uppercase tracking-wider block">Quick Presets:</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() => onUpdateImage({ adjustments: { ...activeImage.adjustments, brightness: 15, contrast: 10 } })}
                      className="p-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium transition-all text-center"
                    >
                      Brighten up
                    </button>
                    <button
                      onClick={() => onUpdateImage({ adjustments: { ...activeImage.adjustments, contrast: 25, saturation: 15 } })}
                      className="p-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium transition-all text-center"
                    >
                      High-Vibe
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* FILTERS CONFIG */}
            {activeTool === "filters" && (
              <div className="space-y-3.5">
                <p className="text-[11px] text-slate-500">Click a preset filter card to apply visual grading:</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "normal", label: "Original" },
                    { id: "mono", label: "Silver Mono" },
                    { id: "noir", label: "Midnight Noir" },
                    { id: "sepia", label: "Retro Sepia" },
                    { id: "vintage", label: "Golden Era" },
                    { id: "warm", label: "Desert Warmth" },
                    { id: "cool", label: "Glacier Chill" },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onUpdateImage({ filter: f.id })}
                      className={`p-2 rounded-xl text-left border text-[11px] font-semibold transition-all duration-150 flex items-center justify-between ${
                        activeImage.filter === f.id
                          ? "bg-violet-100/50 border-violet-400 text-violet-700"
                          : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <span>{f.label}</span>
                      {activeImage.filter === f.id && <Check className="w-3.5 h-3.5 text-violet-600" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* EFFECTS CONFIG */}
            {activeTool === "effects" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Apply stunning specialty artistic overlays:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: "blur", label: "Soft Gaussian Blur" },
                    { id: "invert", label: "Color Inversion" },
                    { id: "neon", label: "Cyberpunk Neon" },
                    { id: "pop_art", label: "Acid Pop Art" },
                    { id: "halftone", label: "Retro Halftone" },
                  ].map((eff) => (
                    <button
                      key={eff.id}
                      onClick={() => onUpdateImage({ filter: eff.id })}
                      className={`p-2 rounded-xl text-[10px] font-semibold transition-all text-center border ${
                        activeImage.filter === eff.id
                          ? "bg-fuchsia-100/50 border-fuchsia-400 text-fuchsia-700"
                          : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      {eff.label}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => onUpdateImage({ filter: "normal" })}
                  className="w-full py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-600 hover:text-slate-900 rounded-lg text-xs"
                >
                  Clear Specialty Effects
                </button>
              </div>
            )}

            {/* TEXT CONFIG */}
            {activeTool === "text" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Add dynamic type tags to write over your images:</p>
                <button
                  onClick={handleAddText}
                  className="w-full py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:opacity-90 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-violet-500/20"
                >
                  <Plus className="w-4 h-4" />
                  Insert New Text Box
                </button>
                <p className="text-[10px] text-slate-400 text-center font-medium">Double-click text on the preview canvas to type!</p>
              </div>
            )}

            {/* ELEMENTS CONFIG */}
            {activeTool === "elements" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Place shapes and vector overlays on top of the image:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => handleAddShape("rect")}
                    className="p-2 bg-white hover:bg-slate-100 text-xs text-slate-700 rounded-xl transition-all border border-slate-200 flex items-center justify-center gap-1.5"
                  >
                    <Square className="w-3.5 h-3.5 text-violet-500" />
                    Rectangle
                  </button>
                  <button
                    onClick={() => handleAddShape("circle")}
                    className="p-2 bg-white hover:bg-slate-100 text-xs text-slate-700 rounded-xl transition-all border border-slate-200 flex items-center justify-center gap-1.5"
                  >
                    <Circle className="w-3.5 h-3.5 text-violet-500" />
                    Circle
                  </button>
                  <button
                    onClick={() => handleAddShape("star")}
                    className="p-2 bg-white hover:bg-slate-100 text-xs text-slate-700 rounded-xl transition-all border border-slate-200 flex items-center justify-center gap-1.5"
                  >
                    <Star className="w-3.5 h-3.5 text-amber-500" />
                    Star Badge
                  </button>
                  <button
                    onClick={() => handleAddShape("arrow")}
                    className="p-2 bg-white hover:bg-slate-100 text-xs text-slate-700 rounded-xl transition-all border border-slate-200 flex items-center justify-center gap-1.5"
                  >
                    <ArrowRight className="w-3.5 h-3.5 text-rose-500" />
                    Arrow Vector
                  </button>
                </div>
              </div>
            )}

            {/* FRAMES CONFIG */}
            {activeTool === "frames" && (
              <div className="space-y-3.5">
                <p className="text-[11px] text-slate-500">Choose custom artisan frames to display your work:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: "none", label: "No Border" },
                    { id: "classic", label: "Classic White" },
                    { id: "gold", label: "Artisan Gold" },
                    { id: "film", label: "Retro Film Strip" },
                    { id: "rounded", label: "Modern Rounded" },
                    { id: "neon", label: "Cyber Neon Glow" },
                  ].map((fr) => (
                    <button
                      key={fr.id}
                      onClick={() => onUpdateImage({ frame: fr.id === "none" ? undefined : fr.id })}
                      className={`p-2 rounded-xl text-left border text-[11px] font-semibold transition-all duration-150 flex items-center justify-between ${
                        activeImage.frame === fr.id || (!activeImage.frame && fr.id === "none")
                          ? "bg-violet-100/50 border-violet-400 text-violet-700"
                          : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <span>{fr.label}</span>
                      {(activeImage.frame === fr.id || (!activeImage.frame && fr.id === "none")) && <Check className="w-3.5 h-3.5 text-violet-600" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* JOIN PHOTOS CONFIG */}
            {activeTool === "join" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-[11px] text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <ImagePlus className="w-3.5 h-3.5" />
                    Join Photos Studio
                  </div>
                  Join multiple photos together. Choose Option One for freeform overlay layers, or Option Two to select exactly two photos for a perfect side-by-side split screen!
                </div>

                {/* Option / Layout Selector */}
                <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
                  <button
                    onClick={() => setJoinOption("freeform")}
                    className={`py-2 px-2 rounded-lg text-center text-[11px] font-bold transition-all cursor-pointer ${
                      joinOption === "freeform"
                        ? "bg-white text-violet-700 shadow-sm"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    Option One: Freeform
                  </button>
                  <button
                    onClick={() => setJoinOption("split")}
                    className={`py-2 px-2 rounded-lg text-center text-[11px] font-bold transition-all cursor-pointer ${
                      joinOption === "split"
                        ? "bg-white text-violet-700 shadow-sm"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    Option Two: Split 2
                  </button>
                </div>

                {/* OPTION ONE: FREEFORM COLLAGE */}
                {joinOption === "freeform" ? (
                  <div className="space-y-4">
                    {/* Main Action to Add Photo */}
                    <button
                      onClick={() => {
                        const input = document.createElement("input");
                        input.type = "file";
                        input.accept = "image/*";
                        input.multiple = true;
                        input.onchange = (e) => {
                          const target = e.target as HTMLInputElement;
                          if (target.files && target.files.length > 0) {
                            Array.from(target.files).forEach(file => {
                              const url = URL.createObjectURL(file);
                              const img = new window.Image();
                              img.onload = () => {
                                const aspect = img.width / img.height;
                                let layerW = 40;
                                let layerH = 40;
                                if (aspect > 1) {
                                  layerH = 40 / aspect;
                                } else {
                                  layerW = 40 * aspect;
                                }

                                const newLayer: Layer = {
                                  id: `join-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                                  type: "image",
                                  url: url,
                                  x: 20,
                                  y: 20,
                                  width: layerW,
                                  height: layerH,
                                  color: "transparent",
                                  rotation: 0,
                                };
                                onUpdateImage({
                                  layers: [...(activeImage?.layers || []), newLayer]
                                });
                                if (setSelectedLayerId) {
                                  setSelectedLayerId(newLayer.id);
                                }
                              };
                              img.src = url;
                            });
                          }
                        };
                        input.click();
                      }}
                      className="w-full py-2 px-3 bg-violet-600 text-white hover:bg-violet-700 rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Photo to Join
                    </button>

                    {/* List of Photos inside the canvas */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-700">Photos on Canvas</h4>

                      {/* 1. Main Background Photo */}
                      <div
                        onClick={(e) => {
                          const isCtrl = e.ctrlKey || e.metaKey;
                          if (isCtrl) {
                            const newSelected = selectedLayerIds.includes("background")
                              ? selectedLayerIds.filter(id => id !== "background")
                              : [...selectedLayerIds, "background"];
                            setSelectedLayerIds(newSelected);
                            setSelectedLayerId && setSelectedLayerId(newSelected.length > 0 ? newSelected[newSelected.length - 1] : null);
                          } else {
                            setSelectedLayerIds(["background"]);
                            setSelectedLayerId && setSelectedLayerId("background");
                          }
                        }}
                        className={`p-2 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                          selectedLayerIds.includes("background")
                            ? "bg-violet-100/40 border-violet-400 text-violet-800 font-semibold shadow-sm"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center shrink-0">
                            <img src={activeImage?.url} className="w-full h-full object-cover" />
                          </div>
                          <div className="truncate max-w-[140px]">
                            <p className="font-bold truncate text-[11px] leading-tight text-slate-800">Background Photo</p>
                            <p className="text-[10px] text-slate-400 font-normal">Base Image</p>
                          </div>
                        </div>
                        {selectedLayerIds.includes("background") && (
                          <span className="text-[9px] bg-violet-100 text-violet-700 py-0.5 px-1.5 rounded-full font-bold">
                            Adjusting
                          </span>
                        )}
                      </div>

                  {/* 2. Secondary Photo Layers */}
                  {activeImage?.layers.filter(l => l.type === "image").map((layer, idx) => {
                    const isSelected = selectedLayerIds.includes(layer.id);
                    return (
                      <div
                        key={layer.id}
                        onClick={(e) => {
                          const isCtrl = e.ctrlKey || e.metaKey;
                          if (isCtrl) {
                            const newSelected = selectedLayerIds.includes(layer.id)
                              ? selectedLayerIds.filter(id => id !== layer.id)
                              : [...selectedLayerIds, layer.id];
                            setSelectedLayerIds(newSelected);
                            setSelectedLayerId && setSelectedLayerId(newSelected.length > 0 ? newSelected[newSelected.length - 1] : null);
                          } else {
                            setSelectedLayerIds([layer.id]);
                            setSelectedLayerId && setSelectedLayerId(layer.id);
                          }
                        }}
                        className={`p-2 rounded-xl border text-xs cursor-pointer transition-all flex flex-col gap-2 ${
                          isSelected
                            ? "bg-violet-100/40 border-violet-400 text-violet-800 font-semibold shadow-sm"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center shrink-0">
                              <img src={layer.url} className="w-full h-full object-cover" />
                            </div>
                            <div className="truncate max-w-[120px]">
                              <p className="font-bold truncate text-[11px] leading-tight text-slate-800">Joined Photo {idx + 1}</p>
                              <p className="text-[10px] text-slate-400 font-normal">Layer Photo</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            {isSelected && (
                              <span className="text-[9px] bg-violet-100 text-violet-700 py-0.5 px-1.5 rounded-full font-bold">
                                Adjusting
                              </span>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const remaining = activeImage.layers.filter(l => l.id !== layer.id);
                                onUpdateImage({ layers: remaining });
                                if (isSelected) {
                                  setSelectedLayerIds(selectedLayerIds.filter(id => id !== layer.id));
                                  if (selectedLayerId === layer.id && setSelectedLayerId) {
                                    setSelectedLayerId(null);
                                  }
                                }
                              }}
                              className="p-1 rounded bg-slate-100 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-all cursor-pointer shrink-0"
                              title="Remove Photo"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* If this layer is selected, let's show sizing, rotation, and alignment controls! */}
                        {isSelected && (
                          <div className="border-t border-violet-100/80 pt-2 mt-1 space-y-2 text-[10px]">
                            {/* Layer Scale slider */}
                            <div className="space-y-1">
                              <div className="flex justify-between text-slate-500">
                                <span>Layer Size</span>
                                <span className="font-bold font-mono text-slate-700">{Math.round(layer.width)}%</span>
                              </div>
                              <input
                                type="range"
                                min="5"
                                max="100"
                                value={layer.width}
                                onClick={(e) => e.stopPropagation()}
                                onChange={(e) => {
                                  const newW = parseInt(e.target.value);
                                  const aspect = layer.height / layer.width;
                                  const newH = newW * aspect;
                                  const updated = activeImage.layers.map(l => {
                                    if (l.id === layer.id) {
                                      return { ...l, width: newW, height: newH };
                                    }
                                    return l;
                                  });
                                  onUpdateImage({ layers: updated });
                                }}
                                className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-violet-600 outline-none"
                              />
                            </div>

                            {/* Layer Rotation slider */}
                            <div className="space-y-1">
                              <div className="flex justify-between text-slate-500 font-normal">
                                <span>Rotation Angle</span>
                                <span className="font-bold font-mono text-slate-700">{(layer.rotation || 0)}°</span>
                              </div>
                              <input
                                type="range"
                                min="0"
                                max="360"
                                value={layer.rotation || 0}
                                onClick={(e) => e.stopPropagation()}
                                onChange={(e) => {
                                  const newRot = parseInt(e.target.value);
                                  const updated = activeImage.layers.map(l => {
                                    if (l.id === layer.id) {
                                      return { ...l, rotation: newRot };
                                    }
                                    return l;
                                  });
                                  onUpdateImage({ layers: updated });
                                }}
                                className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-violet-600 outline-none"
                              />
                            </div>

                            {/* Layer Arrangement */}
                            <div className="flex items-center justify-between pt-1">
                              <span className="text-slate-500 font-medium">Order:</span>
                              <div className="flex gap-1.5">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    // Move layer to front (append to end of layers array)
                                    const otherLayers = activeImage.layers.filter(l => l.id !== layer.id);
                                    onUpdateImage({ layers: [...otherLayers, layer] });
                                  }}
                                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[9px] font-bold transition-all cursor-pointer"
                                >
                                  Bring to Front
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    // Move layer to back (prepend to beginning of layers array)
                                    const otherLayers = activeImage.layers.filter(l => l.id !== layer.id);
                                    onUpdateImage({ layers: [layer, ...otherLayers] });
                                  }}
                                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[9px] font-bold transition-all cursor-pointer"
                                >
                                  Send to Back
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-fade-in">
                {/* Large selector action */}
                <button
                  onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file";
                    input.accept = "image/*";
                    input.multiple = true;
                    input.onchange = (e) => {
                      const target = e.target as HTMLInputElement;
                      if (target.files && target.files.length > 0) {
                        const filesArray = Array.from(target.files);
                        const selectedFiles = filesArray.slice(0, 2);
                        const loadedLayers: Layer[] = [];
                        let loadedCount = 0;

                        selectedFiles.forEach((file, index) => {
                          const url = URL.createObjectURL(file);
                          const img = new window.Image();
                          img.onload = () => {
                            const isLeft = index === 0;
                            const curPercent = splitPercent || 50;
                            const width = selectedFiles.length === 1 ? 50 : (isLeft ? curPercent : (100 - curPercent));
                            const x = isLeft ? 0 : curPercent;

                            const newLayer: Layer = {
                              id: `join-split-${index}-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                              type: "image",
                              url: url,
                              x: x,
                              y: 0,
                              width: width,
                              height: 100,
                              color: "transparent",
                              rotation: 0,
                              adjustments: {
                                brightness: 0,
                                contrast: 0,
                                saturation: 0,
                                vibrance: 0,
                                temperature: 0,
                                tint: 0,
                                shadows: 0,
                                highlights: 0,
                                whites: 0,
                                blacks: 0,
                                dehaze: 0,
                                vignette: 0,
                                clarity: 0,
                                sharpen: 0,
                              }
                            };
                            loadedLayers.push(newLayer);
                            loadedCount++;

                            if (loadedCount === selectedFiles.length) {
                              const nonImageLayers = (activeImage?.layers || []).filter(l => l.type !== "image");
                              onUpdateImage({
                                layers: [...nonImageLayers, ...loadedLayers]
                              });
                              if (setSelectedLayerId && loadedLayers.length > 0) {
                                setSelectedLayerId(loadedLayers[0].id);
                              }
                            }
                          };
                          img.src = url;
                        });
                      }
                    };
                    input.click();
                  }}
                  className="w-full py-2.5 px-3.5 bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Split className="w-4 h-4" />
                  Select 2 Photos to Auto-Split
                </button>

                {/* Left and Right Slot Displays */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">Split Slots status</h4>
                  
                  <div className="grid grid-cols-2 gap-2">
                    {/* LEFT SLOT */}
                    {(() => {
                      const imageLayers = activeImage?.layers.filter(l => l.type === "image") || [];
                      const leftLayer = imageLayers.sort((a, b) => a.x - b.x)[0];
                      const isSelected = leftLayer && selectedLayerIds.includes(leftLayer.id);

                      return (
                        <div 
                          onClick={(e) => {
                            if (!leftLayer) return;
                            const isCtrl = e.ctrlKey || e.metaKey;
                            if (isCtrl) {
                              const newSelected = selectedLayerIds.includes(leftLayer.id)
                                ? selectedLayerIds.filter(id => id !== leftLayer.id)
                                : [...selectedLayerIds, leftLayer.id];
                              setSelectedLayerIds(newSelected);
                              setSelectedLayerId && setSelectedLayerId(newSelected.length > 0 ? newSelected[newSelected.length - 1] : null);
                            } else {
                              setSelectedLayerIds([leftLayer.id]);
                              setSelectedLayerId && setSelectedLayerId(leftLayer.id);
                            }
                          }}
                          className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center cursor-pointer transition-all min-h-[100px] ${
                            leftLayer
                              ? isSelected
                                ? "bg-violet-50/70 border-violet-400 text-violet-800"
                                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                              : "bg-slate-50 border-dashed border-slate-300 text-slate-400 hover:bg-slate-100/50"
                          }`}
                        >
                          {leftLayer ? (
                            <div className="w-full space-y-1.5">
                              <div className="w-12 h-12 rounded mx-auto overflow-hidden border border-slate-200">
                                <img src={leftLayer.url} className="w-full h-full object-cover" />
                              </div>
                              <p className="text-[10px] font-bold truncate px-1">Left Photo</p>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const input = document.createElement("input");
                                  input.type = "file";
                                  input.accept = "image/*";
                                  input.onchange = (ev) => {
                                    const target = ev.target as HTMLInputElement;
                                    if (target.files && target.files.length > 0) {
                                      const file = target.files[0];
                                      const url = URL.createObjectURL(file);
                                      const updated = (activeImage?.layers || []).map(l => {
                                        if (l.id === leftLayer.id) {
                                          return { ...l, url };
                                        }
                                        return l;
                                      });
                                      onUpdateImage({ layers: updated });
                                    }
                                  };
                                  input.click();
                                }}
                                className="text-[9px] px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded cursor-pointer font-semibold transition"
                              >
                                Replace
                              </button>
                            </div>
                          ) : (
                            <div 
                              onClick={(e) => {
                                e.stopPropagation();
                                const input = document.createElement("input");
                                input.type = "file";
                                input.accept = "image/*";
                                input.onchange = (ev) => {
                                  const target = ev.target as HTMLInputElement;
                                  if (target.files && target.files.length > 0) {
                                    const url = URL.createObjectURL(target.files[0]);
                                    const newLayer: Layer = {
                                      id: `join-split-left-${Date.now()}`,
                                      type: "image",
                                      url,
                                      x: 0,
                                      y: 0,
                                      width: splitPercent,
                                      height: 100,
                                      color: "transparent",
                                    };
                                    onUpdateImage({ layers: [...(activeImage?.layers || []), newLayer] });
                                  }
                                };
                                input.click();
                              }}
                              className="space-y-1"
                            >
                              <Plus className="w-4 h-4 mx-auto text-slate-400" />
                              <span className="text-[9px] font-bold block text-slate-500">Add Left Photo</span>
                            </div>
                          )}
                        </div>
                      );
                    })()}

                    {/* RIGHT SLOT */}
                    {(() => {
                      const imageLayers = activeImage?.layers.filter(l => l.type === "image") || [];
                      const sorted = [...imageLayers].sort((a, b) => a.x - b.x);
                      const rightLayer = sorted.length >= 2 ? sorted[1] : (sorted.length === 1 && sorted[0].x > 10 ? sorted[0] : null);
                      const isSelected = rightLayer && selectedLayerIds.includes(rightLayer.id);

                      return (
                        <div 
                          onClick={(e) => {
                            if (!rightLayer) return;
                            const isCtrl = e.ctrlKey || e.metaKey;
                            if (isCtrl) {
                              const newSelected = selectedLayerIds.includes(rightLayer.id)
                                ? selectedLayerIds.filter(id => id !== rightLayer.id)
                                : [...selectedLayerIds, rightLayer.id];
                              setSelectedLayerIds(newSelected);
                              setSelectedLayerId && setSelectedLayerId(newSelected.length > 0 ? newSelected[newSelected.length - 1] : null);
                            } else {
                              setSelectedLayerIds([rightLayer.id]);
                              setSelectedLayerId && setSelectedLayerId(rightLayer.id);
                            }
                          }}
                          className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center cursor-pointer transition-all min-h-[100px] ${
                            rightLayer
                              ? isSelected
                                ? "bg-violet-50/70 border-violet-400 text-violet-800"
                                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                              : "bg-slate-50 border-dashed border-slate-300 text-slate-400 hover:bg-slate-100/50"
                          }`}
                        >
                          {rightLayer ? (
                            <div className="w-full space-y-1.5">
                              <div className="w-12 h-12 rounded mx-auto overflow-hidden border border-slate-200">
                                <img src={rightLayer.url} className="w-full h-full object-cover" />
                              </div>
                              <p className="text-[10px] font-bold truncate px-1">Right Photo</p>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const input = document.createElement("input");
                                  input.type = "file";
                                  input.accept = "image/*";
                                  input.onchange = (ev) => {
                                    const target = ev.target as HTMLInputElement;
                                    if (target.files && target.files.length > 0) {
                                      const file = target.files[0];
                                      const url = URL.createObjectURL(file);
                                      const updated = (activeImage?.layers || []).map(l => {
                                        if (l.id === rightLayer.id) {
                                          return { ...l, url };
                                        }
                                        return l;
                                      });
                                      onUpdateImage({ layers: updated });
                                    }
                                  };
                                  input.click();
                                }}
                                className="text-[9px] px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded cursor-pointer font-semibold transition"
                              >
                                Replace
                              </button>
                            </div>
                          ) : (
                            <div 
                              onClick={(e) => {
                                e.stopPropagation();
                                const input = document.createElement("input");
                                input.type = "file";
                                input.accept = "image/*";
                                input.onchange = (ev) => {
                                  const target = ev.target as HTMLInputElement;
                                  if (target.files && target.files.length > 0) {
                                    const url = URL.createObjectURL(target.files[0]);
                                    const newLayer: Layer = {
                                      id: `join-split-right-${Date.now()}`,
                                      type: "image",
                                      url,
                                      x: splitPercent,
                                      y: 0,
                                      width: 100 - splitPercent,
                                      height: 100,
                                      color: "transparent",
                                    };
                                    onUpdateImage({ layers: [...(activeImage?.layers || []), newLayer] });
                                  }
                                };
                                input.click();
                              }}
                              className="space-y-1"
                            >
                              <Plus className="w-4 h-4 mx-auto text-slate-400" />
                              <span className="text-[9px] font-bold block text-slate-500">Add Right Photo</span>
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>

                {/* Split Line Ratio Adjustment Slider */}
                <div className="space-y-1.5 p-3 bg-white border border-slate-100 rounded-xl shadow-sm">
                  <div className="flex justify-between items-center text-[11px]">
                    <span className="font-semibold text-slate-700 font-bold">Split Line Ratio</span>
                    <span className="font-bold text-violet-600 font-mono">
                      {splitPercent}% : {100 - splitPercent}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={splitPercent}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setSplitPercent(val);
                      if (!activeImage) return;
                      
                      const imageLayers = activeImage.layers.filter(l => l.type === "image");
                      if (imageLayers.length > 0) {
                        const sorted = [...imageLayers].sort((a, b) => a.x - b.x);
                        const leftL = sorted[0];
                        const rightL = sorted[1];
                        const updated = activeImage.layers.map(l => {
                          if (leftL && l.id === leftL.id) {
                            return { ...l, x: 0, width: val, height: 100 };
                          }
                          if (rightL && l.id === rightL.id) {
                            return { ...l, x: val, width: 100 - val, height: 100 };
                          }
                          return l;
                        });
                        onUpdateImage({ layers: updated });
                      }
                    }}
                    className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-violet-600 outline-none"
                  />
                  <p className="text-[9px] text-slate-400 font-normal">Drag to adjust the split line balance between Left & Right images.</p>
                </div>

                {/* Quick Utility Actions */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">Quick Layout Utilities</h4>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() => {
                        if (!activeImage) return;
                        const imageLayers = activeImage.layers.filter(l => l.type === "image");
                        if (imageLayers.length >= 2) {
                          const sorted = [...imageLayers].sort((a, b) => a.x - b.x);
                          const leftL = sorted[0];
                          const rightL = sorted[1];
                          const updated = activeImage.layers.map(l => {
                            if (l.id === leftL.id) {
                              return { ...l, url: rightL.url };
                            }
                            if (l.id === rightL.id) {
                              return { ...l, url: leftL.url };
                            }
                            return l;
                          });
                          onUpdateImage({ layers: updated });
                        }
                      }}
                      className="p-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-[10px] text-slate-700 font-bold transition-all text-center flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Columns2 className="w-3.5 h-3.5 text-violet-500" />
                      Swap Sides
                    </button>
                    <button
                      onClick={() => {
                        setSplitPercent(50);
                        if (!activeImage) return;
                        const imageLayers = activeImage.layers.filter(l => l.type === "image");
                        if (imageLayers.length > 0) {
                          const sorted = [...imageLayers].sort((a, b) => a.x - b.x);
                          const leftL = sorted[0];
                          const rightL = sorted[1];
                          const updated = activeImage.layers.map(l => {
                            if (leftL && l.id === leftL.id) {
                              return { ...l, x: 0, width: 50, height: 100 };
                            }
                            if (rightL && l.id === rightL.id) {
                              return { ...l, x: 50, width: 50, height: 100 };
                            }
                            return l;
                          });
                          onUpdateImage({ layers: updated });
                        }
                      }}
                      className="p-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-[10px] text-slate-700 font-bold transition-all text-center flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Split className="w-3.5 h-3.5 text-violet-500" />
                      Equal 50/50
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Helpful Reminder Text */}
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[10px] text-amber-700 leading-relaxed space-y-1 shadow-sm">
              <div className="font-bold flex items-center gap-1 text-amber-800">
                💡 Smart Adjustment Tip
              </div>
              <p>
                Select any photo in the list above or click on them in the canvas to adjust. 
                Once selected, use the <strong>sliders in the right-side Adjust panel</strong> to modify its individual exposure, color saturation, temperature, or vignette.
              </p>
            </div>
          </div>
        )}

            {/* 4K CLARITY CONFIG */}
            {activeTool === "clarity" && (
              <div className="space-y-4 animate-fade-in">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-[11px] text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Aperture className="w-3.5 h-3.5" />
                    4K Studio Clarity Enhancer
                  </div>
                  Apply our dynamic pixel-level micro-contrast convolution filter to achieve pristine 4K resolution clarity on the selected photo.
                </div>

                {/* Target photo display */}
                <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded bg-violet-100 flex items-center justify-center text-[10px] font-bold text-violet-700 shrink-0">
                      🎯
                    </div>
                    <span className="text-[11px] font-semibold text-slate-700">
                      Targeting: {selectedLayerId ? "Joined Photo Layer" : "Main Background Photo"}
                    </span>
                  </div>
                  {selectedLayerId && (
                    <button
                      onClick={() => setSelectedLayerId && setSelectedLayerId(null)}
                      className="text-[10px] text-violet-600 hover:text-violet-700 font-bold transition cursor-pointer"
                    >
                      Switch to Background
                    </button>
                  )}
                </div>

                {/* Clarity slider */}
                <div className="space-y-3.5 p-3 bg-white border border-slate-100 rounded-xl shadow-sm">
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-700">4K Micro-Contrast (Clarity)</span>
                      <span className="font-bold text-violet-600 font-mono">
                        {(selectedLayerId ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.clarity || 0) : (activeImage?.adjustments.clarity || 0))}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="-100"
                      max="100"
                      value={(selectedLayerId ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.clarity || 0) : (activeImage?.adjustments.clarity || 0))}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        const currentSharpen = selectedLayerId 
                          ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.sharpen || 0)
                          : (activeImage?.adjustments.sharpen || 0);
                        updateClarityAndSharpen(val, currentSharpen);
                      }}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-violet-600 outline-none"
                    />
                    <p className="text-[9px] text-slate-400">Enhance local midtone contrast for edge definitions.</p>
                  </div>

                  {/* Sharpen slider */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-100">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-700">Texture Edge Definition (Sharpen)</span>
                      <span className="font-bold text-violet-600 font-mono">
                        {(selectedLayerId ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.sharpen || 0) : (activeImage?.adjustments.sharpen || 0))}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={(selectedLayerId ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.sharpen || 0) : (activeImage?.adjustments.sharpen || 0))}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        const currentClarity = selectedLayerId 
                          ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.clarity || 0)
                          : (activeImage?.adjustments.clarity || 0);
                        updateClarityAndSharpen(currentClarity, val);
                      }}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-violet-600 outline-none"
                    />
                    <p className="text-[9px] text-slate-400">Pristine fine-frequency details pop for ultra HD feel.</p>
                  </div>
                </div>

                {/* Professional Presets */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">4K UHD Studio Presets</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "4k_uhd", label: "4K UHD Master", clarity: 70, sharpen: 60, desc: "Ultra-sharp detail" },
                      { id: "vivid_texture", label: "Vivid Texture", clarity: 90, sharpen: 35, desc: "Boost natural grains" },
                      { id: "portrait_sharp", label: "Studio Portrait", clarity: 35, sharpen: 50, desc: "Crisp fine contours" },
                      { id: "cinematic_pop", label: "Cinematic Pop", clarity: 50, sharpen: 30, desc: "High micro-contrast" },
                      { id: "soft_glow", label: "Dreamy Glow", clarity: -40, sharpen: 30, desc: "Magazine mist glow" },
                      { id: "reset", label: "Restore Original", clarity: 0, sharpen: 0, desc: "Standard definition" },
                    ].map((pr) => {
                      const curC = selectedLayerId 
                        ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.clarity || 0)
                        : (activeImage?.adjustments.clarity || 0);
                      const curS = selectedLayerId 
                        ? (activeImage?.layers.find(l => l.id === selectedLayerId)?.adjustments?.sharpen || 0)
                        : (activeImage?.adjustments.sharpen || 0);
                      const isApplied = curC === pr.clarity && curS === pr.sharpen;

                      return (
                        <button
                          key={pr.id}
                          onClick={() => updateClarityAndSharpen(pr.clarity, pr.sharpen)}
                          className={`p-2 rounded-xl text-left border transition-all duration-150 flex flex-col justify-between cursor-pointer ${
                            isApplied
                              ? "bg-violet-100/50 border-violet-400 text-violet-700 font-semibold"
                              : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
                          }`}
                        >
                          <span className="text-[11px] font-bold block">{pr.label}</span>
                          <span className="text-[9px] text-slate-400 font-normal leading-tight">{pr.desc}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* AI ENHANCE CONFIG */}
            {activeTool === "enhance" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Sparkles className="w-3.5 h-3.5" />
                    Gemini Smart Auto-Enhance
                  </div>
                  Our advanced multi-modal model analyzed your scene's histogram to calculate professional, custom exposure, lighting, and saturation presets.
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-700">AI Blend Intensity</label>
                    <span className="text-xs font-bold text-violet-600 font-mono">{aiEnhanceIntensity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={aiEnhanceIntensity}
                    onChange={(e) => setAiEnhanceIntensity(parseInt(e.target.value))}
                    className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                    <span>Original (0%)</span>
                    <span>Enhanced (100%)</span>
                  </div>
                </div>

                <button
                  onClick={onAIEnhance}
                  disabled={isAIProcessing}
                  className="w-full py-2 px-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAIProcessing ? 'animate-spin' : ''}`} />
                  {isAIProcessing ? 'Analyzing...' : 'Re-Analyze Composition'}
                </button>
              </div>
            )}

            {/* AI BG REMOVER CONFIG */}
            {activeTool === "bg_remover" && (
              <div className="space-y-4">
                <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100 text-xs text-indigo-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-indigo-800">
                    <Scissors className="w-3.5 h-3.5" />
                    Subject Silhouette Extractor
                  </div>
                  Isolate key elements in one click. Adjust edge behavior to soften extraction curves.
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                    <span className="text-xs font-semibold text-slate-700">Enable Isolation Mask</span>
                    <button
                      onClick={() => {
                        if (activeImage?.crop) {
                          onUpdateImage({ crop: null });
                        } else {
                          onAIBgRemove();
                        }
                      }}
                      className={`w-10 h-6 rounded-full p-1 transition-all ${
                        activeImage?.crop ? 'bg-indigo-600' : 'bg-slate-200'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-white transition-all transform ${
                        activeImage?.crop ? 'translate-x-4' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Feather Boundary Radius</label>
                      <span className="text-xs font-bold text-indigo-600 font-mono">8px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="30"
                      defaultValue="8"
                      className="w-full accent-indigo-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  {/* AI BACKGROUND TREATMENTS */}
                  {activeImage?.crop && (
                    <div className="space-y-3 pt-2.5 border-t border-slate-200/50">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-700">AI Background Treatment</label>
                        <span className="px-1.5 py-0.5 bg-indigo-50 text-indigo-700 text-[8px] font-bold rounded font-mono uppercase tracking-wider">NEW</span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { id: "crop", label: "Transparent Crop" },
                          { id: "blur", label: "Portrait Blur" },
                          { id: "grayscale", label: "Black & White BG" },
                          { id: "color_fill", label: "Studio Backdrop" },
                        ].map((item) => {
                          const isActive = (activeImage.bgTreatment || "crop") === item.id;
                          return (
                            <button
                              key={item.id}
                              onClick={() => onUpdateImage({ bgTreatment: item.id as any })}
                              className={`py-1.5 px-2 rounded-lg text-center text-[10px] font-semibold border transition-all duration-150 cursor-pointer ${
                                isActive
                                  ? "bg-indigo-50 border-indigo-500 text-indigo-700 font-bold shadow-sm shadow-indigo-500/5"
                                  : "bg-white border-slate-200 text-slate-500 hover:text-slate-800 hover:border-slate-300"
                              }`}
                            >
                              {item.label}
                            </button>
                          );
                        })}
                      </div>

                      {activeImage.bgTreatment === "color_fill" && (
                        <div className="space-y-2 p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
                          <label className="text-[10px] font-bold text-slate-500 block uppercase tracking-wider">Select Solid Color Backdrop</label>
                          <div className="flex items-center gap-2">
                            <input
                              type="color"
                              value={activeImage.bgTreatmentColor || "#E2E8F0"}
                              onChange={(e) => onUpdateImage({ bgTreatmentColor: e.target.value })}
                              className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200 p-0 overflow-hidden"
                            />
                            <div className="flex gap-1.5 flex-wrap">
                              {["#ffffff", "#000000", "#f8fafc", "#e2e8f0", "#fee2e2", "#dbeafe", "#fef08a", "#dcfce7"].map((c) => (
                                <button
                                  key={c}
                                  onClick={() => onUpdateImage({ bgTreatmentColor: c })}
                                  className="w-5 h-5 rounded-full border border-slate-300 hover:scale-110 active:scale-95 transition-transform"
                                  style={{ backgroundColor: c }}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <button
                  onClick={onAIBgRemove}
                  disabled={isAIProcessing}
                  className="w-full py-2 px-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAIProcessing ? 'animate-spin' : ''}`} />
                  {isAIProcessing ? 'Scanning...' : 'Rerun Object Scanner'}
                </button>
              </div>
            )}

            {/* AI EXPAND CONFIG */}
            {activeTool === "expand" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Maximize2 className="w-3.5 h-3.5" />
                    Generative AI Expand
                  </div>
                  Synthesize background textures and extend margins outside the photograph's original borders.
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-semibold text-slate-700 block">Select Target Aspect Ratio</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "16:9", label: "Widescreen 16:9" },
                      { id: "1:1", label: "Square 1:1" },
                      { id: "9:16", label: "Vertical 9:16" },
                      { id: "4:3", label: "Standard 4:3" },
                    ].map((ratio) => (
                      <button
                        key={ratio.id}
                        onClick={() => onAIExpand(ratio.id)}
                        disabled={isAIProcessing}
                        className="py-2 px-3 bg-white border border-slate-200 hover:border-violet-500 hover:text-violet-700 text-xs text-slate-700 font-semibold rounded-xl text-center transition-all cursor-pointer"
                      >
                        {ratio.label}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Background Texture Softness</label>
                      <span className="text-xs font-bold text-violet-600 font-mono">45%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      defaultValue="45"
                      className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* AI MAGIC ERASER CONFIG */}
            {activeTool === "remove_obj" && (
              <div className="space-y-4">
                <div className="p-3 bg-fuchsia-50/50 rounded-xl border border-fuchsia-100 text-xs text-fuchsia-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-fuchsia-800">
                    <Brush className="w-3.5 h-3.5" />
                    AI Magic Eraser
                  </div>
                  Draw directly over any background pedestrians, power lines, watermarks, or spots to seamlessly heal the canvas context.
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Brush Eraser Diameter</label>
                      <span className="text-xs font-bold text-fuchsia-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-fuchsia-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  {/* Heal Quality Mode */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-700 block">Heal Mode</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {["Content-Aware (Fine)", "AI Texture Synth", "Ambient Blend", "Fast Fill"].map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setHealMode(m)}
                          className={`py-1 px-1.5 rounded-lg text-center text-[10px] font-semibold border transition-all cursor-pointer ${
                            healMode === m
                              ? "bg-fuchsia-50 border-fuchsia-500 text-fuchsia-700 font-bold"
                              : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Denoise Blend Slider */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Denoise Blend</label>
                      <span className="text-xs font-bold text-fuchsia-600 font-mono">{denoiseFactor}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={denoiseFactor}
                      onChange={(e) => setDenoiseFactor(parseInt(e.target.value))}
                      className="w-full accent-fuchsia-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="p-2 bg-slate-100/50 rounded-xl text-center text-slate-500 font-mono text-[10px] border border-dashed border-slate-200">
                    {brushStrokes.length === 0 ? (
                      "No mask strokes applied yet."
                    ) : (
                      <span className="text-fuchsia-600 font-bold">
                        ⚡ {brushStrokes.length} regions selected
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Brush
                  </button>
                  <button
                    onClick={() => onAIMagicErase(healMode, denoiseFactor)}
                    disabled={isAIProcessing || brushStrokes.length === 0}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-700 hover:to-pink-700 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Erase Zone
                  </button>
                </div>
              </div>
            )}

            {/* AI REPLACE CONFIG */}
            {activeTool === "ai_replace" && (
              <div className="space-y-4">
                <div className="p-3 bg-purple-50/50 rounded-xl border border-purple-100 text-xs text-purple-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-purple-800">
                    <Sparkles className="w-3.5 h-3.5" />
                    AI Generative Replace
                  </div>
                  Brush over an element, write what you want to insert or swap in, and let Gemini render it perfectly inside the scene.
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Brush Diameter</label>
                      <span className="text-xs font-bold text-purple-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-purple-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-700 block">Replacement Prompt</label>
                    <input
                      type="text"
                      placeholder="e.g. vintage flower vase, golden sphere..."
                      value={aiReplacePrompt}
                      onChange={(e) => setAiReplacePrompt(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-200 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 rounded-xl text-xs text-slate-800"
                    />
                  </div>

                  {/* Design Theme Selector */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-700 block">Design Theme Guideline</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {["Minimalist Light", "Glow Neon Badge", "Frosted Glass", "Futuristic Hologram"].map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setDesignTheme(t)}
                          className={`py-1 px-1.5 rounded-lg text-center text-[10px] font-semibold border transition-all cursor-pointer ${
                            designTheme === t
                              ? "bg-purple-50 border-purple-500 text-purple-700 font-bold"
                              : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Mask
                  </button>
                  <button
                    onClick={() => onAIReplaceSubmit(designTheme)}
                    disabled={isAIProcessing || !aiReplacePrompt}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Replace
                  </button>
                </div>
              </div>
            )}

            {/* AI REIMAGINE / STYLE TRANSFER CONFIG */}
            {activeTool === "reimagine" && (
              <div className="space-y-4">
                <div className="p-3 bg-fuchsia-50/50 rounded-xl border border-fuchsia-100 text-xs text-fuchsia-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-fuchsia-800">
                    <RefreshCw className="w-3.5 h-3.5" />
                    Artistic Style Reimagine
                  </div>
                  Recompile the photo into classic, modern, or digital artistic styles.
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "watercolor", label: "Watercolor", prompt: "A dreamy, delicate watercolor painting with soft fluid brushstrokes and light washes" },
                    { id: "oil", label: "Impressionist Oil", prompt: "A rich impressionist oil painting with thick texture impasto details" },
                    { id: "cyberpunk", label: "Cyberpunk Glow", prompt: "A futuristic sci-fi scene with glowing neon tubes and dark metallic textures" },
                    { id: "pencil", label: "Pencil Sketch", prompt: "A fine cross-hatched graphite pencil sketch with paper grain texture" },
                  ].map((style) => (
                    <button
                      key={style.id}
                      disabled={isAIProcessing}
                      onClick={() => {
                        onAIReimagineClick(style.prompt);
                      }}
                      className="py-2.5 px-2 bg-white border border-slate-200 hover:border-fuchsia-500 hover:text-fuchsia-700 text-xs font-semibold text-slate-700 rounded-xl text-center transition-all cursor-pointer disabled:opacity-50"
                    >
                      {style.label}
                    </button>
                  ))}
                </div>

                <div className="flex flex-col gap-2 pt-2">
                  <button
                    onClick={() => onAIReimagineClick()}
                    disabled={isAIProcessing}
                    className="w-full py-2 px-3 bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                    Enter Custom Prompt
                  </button>
                </div>
              </div>
            )}

            {/* RETOUCH - BLEMISH FIX */}
            {activeTool === "blemish" && (
              <div className="space-y-4">
                <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-xs text-emerald-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-emerald-800">
                    <ScanFace className="w-3.5 h-3.5" />
                    Precision Blemish Fix
                  </div>
                  Brush over minor skin spots, dust, or background speckles to instantly blend them with surrounding pixels.
                </div>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Heal Brush Diameter</label>
                      <span className="text-xs font-bold text-emerald-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-emerald-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  <div className="p-2 bg-slate-100/50 rounded-xl text-center text-slate-500 font-mono text-[10px] border border-dashed border-slate-200">
                    {brushStrokes.length === 0 ? (
                      "Brush directly on photo regions"
                    ) : (
                      <span className="text-emerald-600 font-bold">
                        🎯 {brushStrokes.length} micro-spots selected
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Brush
                  </button>
                  <button
                    onClick={() => {
                      onUpdateImage({
                        adjustments: { ...activeImage.adjustments, clarity: Math.max(-100, activeImage.adjustments.clarity - 8) }
                      });
                      setBrushStrokes([]);
                      alert("Success: Micro-blemishes blended flawlessly!");
                    }}
                    disabled={brushStrokes.length === 0}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    Apply Fix
                  </button>
                </div>
              </div>
            )}

            {/* RETOUCH - SKIN SMOOTH */}
            {activeTool === "skin_smooth" && (
              <div className="space-y-4">
                <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-100 text-xs text-rose-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-rose-800">
                    <ScanFace className="w-3.5 h-3.5 animate-pulse" />
                    Skin Glow Smooth
                  </div>
                  Soften skin texture to minimize pores and introduce an elegant, glowing cosmetic softness.
                </div>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Smooth Brush Diameter</label>
                      <span className="text-xs font-bold text-rose-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-rose-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  <div className="p-2 bg-slate-100/50 rounded-xl text-center text-slate-500 font-mono text-[10px] border border-dashed border-slate-200">
                    {brushStrokes.length === 0 ? (
                      "Brush over skin areas on the canvas"
                    ) : (
                      <span className="text-rose-600 font-bold">
                        🌸 {brushStrokes.length} skin paths marked
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Brush
                  </button>
                  <button
                    onClick={() => {
                      onUpdateImage({
                        adjustments: { ...activeImage.adjustments, clarity: Math.max(-100, activeImage.adjustments.clarity - 15), vibrance: Math.min(100, activeImage.adjustments.vibrance + 5) }
                      });
                      setBrushStrokes([]);
                      alert("Success: Skin textures smoothed beautifully!");
                    }}
                    disabled={brushStrokes.length === 0}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-rose-600 to-pink-600 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    Smooth Skin
                  </button>
                </div>
              </div>
            )}

            {/* RETOUCH - TEETH WHITEN */}
            {activeTool === "teeth_whiten" && (
              <div className="space-y-4">
                <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-xs text-amber-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-amber-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    Teeth Whiten & Brighten
                  </div>
                  Brush over smiles to lift yellow tones, increase teeth brightness, and boost confidence.
                </div>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Brush Diameter</label>
                      <span className="text-xs font-bold text-amber-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-amber-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  <div className="p-2 bg-slate-100/50 rounded-xl text-center text-slate-500 font-mono text-[10px] border border-dashed border-slate-200">
                    {brushStrokes.length === 0 ? (
                      "Brush over teeth on preview"
                    ) : (
                      <span className="text-amber-600 font-bold">
                        🦷 {brushStrokes.length} smile regions marked
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Brush
                  </button>
                  <button
                    onClick={() => {
                      onUpdateImage({
                        adjustments: { ...activeImage.adjustments, brightness: Math.min(100, activeImage.adjustments.brightness + 10), whites: Math.min(100, activeImage.adjustments.whites + 15), saturation: Math.max(-100, activeImage.adjustments.saturation - 10) }
                      });
                      setBrushStrokes([]);
                      alert("Success: Teeth whitened and brightened!");
                    }}
                    disabled={brushStrokes.length === 0}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-amber-500 to-yellow-500 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    Whiten Teeth
                  </button>
                </div>
              </div>
            )}

            {/* RETOUCH - RED EYE */}
            {activeTool === "red_eye" && (
              <div className="space-y-4">
                <div className="p-3 bg-red-50/50 rounded-xl border border-red-100 text-xs text-red-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-red-800">
                    <ScanFace className="w-3.5 h-3.5 text-red-500" />
                    Red Eye Corrector
                  </div>
                  Dampen red reflections caused by camera flashes in dark ambient conditions.
                </div>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-700">Target Area Diameter</label>
                      <span className="text-xs font-bold text-red-600 font-mono">{brushSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="60"
                      value={brushSize}
                      onChange={(e) => setBrushSize(parseInt(e.target.value))}
                      className="w-full accent-red-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  <div className="p-2 bg-slate-100/50 rounded-xl text-center text-slate-500 font-mono text-[10px] border border-dashed border-slate-200">
                    {brushStrokes.length === 0 ? (
                      "Click on red pupil centers"
                    ) : (
                      <span className="text-red-600 font-bold">
                        👁️ {brushStrokes.length} pupils targeted
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setBrushStrokes([])}
                    className="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Target
                  </button>
                  <button
                    onClick={() => {
                      onUpdateImage({
                        adjustments: { ...activeImage.adjustments, saturation: Math.max(-100, activeImage.adjustments.saturation - 20) }
                      });
                      setBrushStrokes([]);
                      alert("Success: Red-eye reflection neutralized!");
                    }}
                    disabled={brushStrokes.length === 0}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-red-600 to-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    Neutralize Red
                  </button>
                </div>
              </div>
            )}

            {/* COLOR - COLOR MATCH */}
            {activeTool === "color_match" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Palette className="w-3.5 h-3.5 text-violet-500" />
                    Color Match & Style Match
                  </div>
                  Adopt color palettes and lighting moods from classic cinematic references.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "cinema_teal", label: "Hollywood Teal/Orange", adjustments: { temperature: 15, tint: -5, contrast: 10 } },
                    { id: "warm_indie", label: "Warm Indie Gold", adjustments: { temperature: 25, tint: 10, brightness: 5 } },
                    { id: "cool_cyber", label: "Cool Cyber Vapor", adjustments: { temperature: -30, tint: 25, saturation: 15 } },
                    { id: "vintage_doc", label: "Documentary Matte", adjustments: { contrast: -10, saturation: -15, blacks: 10 } },
                  ].map((style) => (
                    <button
                      key={style.id}
                      onClick={() => {
                        onUpdateImage({ adjustments: { ...activeImage.adjustments, ...style.adjustments } });
                        alert(`Cinematic style "${style.label}" matched successfully!`);
                      }}
                      className="p-2.5 bg-white border border-slate-200 hover:border-violet-500 hover:text-violet-700 text-xs font-semibold text-slate-700 rounded-xl text-center transition-all cursor-pointer"
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* COLOR - HUES & TONES */}
            {activeTool === "hues_tones" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <SlidersHorizontal className="w-3.5 h-3.5 text-violet-500" />
                    Hues & Color Tones
                  </div>
                  Calibrate individual slider components to target temperature shifts and vibrance offsets.
                </div>
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>Vibrance Shift</span>
                      <span className="text-violet-600 font-mono">{activeImage.adjustments.vibrance}%</span>
                    </div>
                    <input
                      type="range"
                      min="-100"
                      max="100"
                      value={activeImage.adjustments.vibrance}
                      onChange={(e) => onUpdateImage({ adjustments: { ...activeImage.adjustments, vibrance: parseInt(e.target.value) } })}
                      className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>Temperature Shift</span>
                      <span className="text-violet-600 font-mono">{activeImage.adjustments.temperature}%</span>
                    </div>
                    <input
                      type="range"
                      min="-100"
                      max="100"
                      value={activeImage.adjustments.temperature}
                      onChange={(e) => onUpdateImage({ adjustments: { ...activeImage.adjustments, temperature: parseInt(e.target.value) } })}
                      className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>Tint Shift</span>
                      <span className="text-violet-600 font-mono">{activeImage.adjustments.tint}%</span>
                    </div>
                    <input
                      type="range"
                      min="-100"
                      max="100"
                      value={activeImage.adjustments.tint}
                      onChange={(e) => onUpdateImage({ adjustments: { ...activeImage.adjustments, tint: parseInt(e.target.value) } })}
                      className="w-full accent-violet-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* COLOR - COLOR SPLASH */}
            {activeTool === "color_splash" && (
              <div className="space-y-4">
                <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100 text-xs text-indigo-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-indigo-800">
                    <Palette className="w-3.5 h-3.5 text-indigo-500" />
                    Color Splash Isolate
                  </div>
                  Isolate one primary color while converting the rest of the canvas to dramatic monochrome grayscale.
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: "Red", value: "red", color: "bg-red-500" },
                    { label: "Blue", value: "blue", color: "bg-blue-500" },
                    { label: "Yellow", value: "yellow", color: "bg-yellow-400" },
                    { label: "Green", value: "green", color: "bg-emerald-500" },
                  ].map((color) => {
                    const isSelected = activeImage.colorSplashIsolate === color.value;
                    return (
                      <button
                        key={color.value}
                        onClick={() => {
                          onUpdateImage({ 
                            filter: "mono", 
                            colorSplashIsolate: color.value,
                            adjustments: { ...activeImage.adjustments, saturation: -90, vibrance: -30 } 
                          });
                        }}
                        className={`flex flex-col items-center gap-1 p-2 bg-white border rounded-xl transition-all cursor-pointer ${
                          isSelected ? "border-indigo-500 ring-2 ring-indigo-100 font-bold" : "border-slate-200 hover:border-violet-400"
                        }`}
                      >
                        <span className={`w-5 h-5 rounded-full ${color.color} shadow-inner`} />
                        <span className="text-[9px] font-bold text-slate-600">{color.label}</span>
                      </button>
                    );
                  })}
                </div>
                {activeImage.colorSplashIsolate && (
                  <button
                    onClick={() => {
                      onUpdateImage({ 
                        filter: "normal", 
                        colorSplashIsolate: undefined,
                        adjustments: { ...activeImage.adjustments, saturation: 0, vibrance: 0 } 
                      });
                    }}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200 cursor-pointer"
                  >
                    Reset Color Splash
                  </button>
                )}
              </div>
            )}

            {/* COLOR - REPLACE COLOR */}
            {activeTool === "replace_color" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Palette className="w-3.5 h-3.5 text-violet-500" />
                    Targeted Color Swapper
                  </div>
                  Swap out a target color in the image with another choice.
                </div>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400">Original Hue</label>
                      <input
                        type="color"
                        defaultValue="#f43f5e"
                        className="w-full h-8 rounded-lg cursor-pointer border border-slate-200 p-1 bg-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400">Target Hue</label>
                      <input
                        type="color"
                        defaultValue="#8b5cf6"
                        className="w-full h-8 rounded-lg cursor-pointer border border-slate-200 p-1 bg-white"
                      />
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      onUpdateImage({ 
                        filter: "warm",
                        adjustments: { ...activeImage.adjustments, temperature: 40, tint: -20 }
                      });
                    }}
                    className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-lg transition-all cursor-pointer"
                  >
                    Execute Color Swap
                  </button>
                </div>
              </div>
            )}

            {/* CREATIVE - DOUBLE EXPOSURE */}
            {activeTool === "double_exposure" && (
              <div className="space-y-4">
                <div className="p-3 bg-fuchsia-50/50 rounded-xl border border-fuchsia-100 text-xs text-fuchsia-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-fuchsia-800">
                    <Component className="w-3.5 h-3.5 text-fuchsia-500" />
                    Double Exposure Blend
                  </div>
                  Overlay beautiful organic silhouettes or textures onto your photograph.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "Urban Forest", url: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=600&q=80" },
                    { label: "Night Sky Clouds", url: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80" },
                  ].map((texture) => {
                    const isSelected = activeImage.overlayUrl === texture.url;
                    return (
                      <button
                        key={texture.label}
                        onClick={() => {
                          onUpdateImage({ 
                            overlayUrl: texture.url, 
                            overlayOpacity: activeImage.overlayOpacity || 45,
                            filter: "noir" 
                          });
                        }}
                        className={`p-2 bg-white border rounded-xl text-center text-xs font-semibold transition-all cursor-pointer ${
                          isSelected ? "border-fuchsia-500 ring-2 ring-fuchsia-100 text-fuchsia-700" : "border-slate-200 hover:border-fuchsia-400 text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {texture.label}
                      </button>
                    );
                  })}
                </div>

                {activeImage.overlayUrl && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>Overlay Opacity</span>
                      <span className="text-fuchsia-600 font-mono">{activeImage.overlayOpacity || 45}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={activeImage.overlayOpacity || 45}
                      onChange={(e) => onUpdateImage({ overlayOpacity: parseInt(e.target.value) })}
                      className="w-full accent-fuchsia-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
                    />
                    <button
                      onClick={() => {
                        onUpdateImage({ 
                          overlayUrl: undefined,
                          filter: "normal" 
                        });
                      }}
                      className="w-full mt-2 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200 cursor-pointer"
                    >
                      Clear Double Exposure
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* CREATIVE - NEON GLOW OVERLAY */}
            {activeTool === "neon_glow_overlay" && (
              <div className="space-y-4">
                <div className="p-3 bg-violet-50/50 rounded-xl border border-violet-100 text-xs text-violet-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-violet-800">
                    <Sparkles className="w-3.5 h-3.5 text-violet-500" />
                    Cyber Neon Glow
                  </div>
                  Infuse fluorescent vaporwave backlights with high-contrast, atmospheric colors.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "Tokyo Pink", filter: "neon" },
                    { label: "Cyan Horizon", filter: "cool" },
                  ].map((preset) => {
                    const isSelected = activeImage.showNeonGlow && activeImage.filter === preset.filter;
                    return (
                      <button
                        key={preset.label}
                        onClick={() => {
                          onUpdateImage({ 
                            filter: preset.filter,
                            showNeonGlow: true
                          });
                        }}
                        className={`p-2.5 bg-white border rounded-xl text-center text-xs font-semibold transition-all cursor-pointer ${
                          isSelected ? "border-violet-500 ring-2 ring-violet-100 text-violet-700 font-bold" : "border-slate-200 hover:border-violet-400 text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>
                {activeImage.showNeonGlow && (
                  <button
                    onClick={() => {
                      onUpdateImage({ 
                        showNeonGlow: false,
                        filter: "normal" 
                      });
                    }}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200 cursor-pointer"
                  >
                    Clear Cyber Neon Glow
                  </button>
                )}
              </div>
            )}

            {/* CREATIVE - BOKEH OVERLAY */}
            {activeTool === "bokeh_overlay" && (
              <div className="space-y-4">
                <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-xs text-amber-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-amber-800">
                    <Star className="w-3.5 h-3.5 text-amber-500" />
                    Artistic Bokeh Overlay
                  </div>
                  Add organic, glowing aperture circles to construct premium lens bokeh depths.
                </div>
                <button
                  onClick={() => {
                    onUpdateImage({ 
                      showBokeh: !activeImage.showBokeh,
                      adjustments: { ...activeImage.adjustments, blacks: 10, contrast: 15 } 
                    });
                  }}
                  className={`w-full py-2.5 border rounded-xl text-center text-xs font-semibold transition-all cursor-pointer ${
                    activeImage.showBokeh 
                      ? "bg-amber-50 border-amber-400 text-amber-800 font-bold shadow-sm" 
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  }`}
                >
                  {activeImage.showBokeh ? "✨ Bokeh Enabled (Click to Disable)" : "🌟 Enable Bokeh Circles Overlay"}
                </button>
              </div>
            )}

            {/* CREATIVE - DUOTONE GEN */}
            {activeTool === "duotone_gen" && (
              <div className="space-y-4">
                <div className="p-3 bg-purple-50/50 rounded-xl border border-purple-100 text-xs text-purple-700 leading-relaxed">
                  <div className="font-semibold flex items-center gap-1.5 mb-1 text-purple-800">
                    <Palette className="w-3.5 h-3.5 text-purple-500" />
                    DuoTone Generator
                  </div>
                  Map visual highlights and deep shadows to high-contrast Spotify-esque solid dual-gradients.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "Nordic Teal & Blue", filter: "cool", adjustments: { temperature: -80, tint: 20 } },
                    { label: "Crimson & Amber", filter: "warm", adjustments: { temperature: 80, tint: -20 } },
                    { label: "Classic Black & White", filter: "mono", adjustments: { saturation: -100, contrast: 30 } },
                    { label: "Cyber Punk Purple", filter: "neon", adjustments: { temperature: -40, tint: 80 } },
                  ].map((duo) => {
                    const isSelected = activeImage.filter === duo.filter;
                    return (
                      <button
                        key={duo.label}
                        onClick={() => {
                          onUpdateImage({ 
                            filter: duo.filter,
                            adjustments: { ...activeImage.adjustments, ...duo.adjustments } 
                          });
                        }}
                        className={`p-2.5 bg-white border rounded-xl text-center text-xs font-semibold transition-all cursor-pointer ${
                          isSelected ? "border-purple-500 ring-2 ring-purple-100 text-purple-800 font-bold" : "border-slate-200 hover:border-purple-400 text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {duo.label}
                      </button>
                    );
                  })}
                </div>
                {activeImage.filter !== "normal" && (
                  <button
                    onClick={() => {
                      onUpdateImage({ 
                        filter: "normal",
                        adjustments: { ...activeImage.adjustments, temperature: 0, tint: 0, saturation: 0, contrast: 0 } 
                      });
                    }}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200 cursor-pointer"
                  >
                    Reset DuoTone Filters
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* AI Tools Section */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <h2 className="text-xs font-semibold text-violet-600 uppercase tracking-wider">
              AI Tools
            </h2>
            <span className="px-1.5 py-0.5 bg-violet-100 text-violet-700 text-[9px] font-bold rounded-full uppercase tracking-wider font-mono">
              Smart
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {aiToolsList.map((tool) => {
              const IconComponent = tool.icon;
              const isActive = activeTool === tool.id;
              return (
                <button
                  key={tool.id}
                  id={`tool-btn-${tool.id}`}
                  disabled={isAIProcessing}
                  onClick={() => {
                    const nextActive = isActive ? null : tool.id;
                    setActiveTool(nextActive);
                    if (nextActive && tool.onClick) {
                      tool.onClick();
                    }
                  }}
                  className={`relative flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 aspect-square cursor-pointer hover:scale-102 group ${
                    isActive
                      ? "bg-gradient-to-br from-violet-100 to-fuchsia-100 border-violet-500 text-violet-700 shadow-md shadow-violet-500/10 font-bold"
                      : "bg-slate-50 border-slate-200/60 text-slate-500 hover:text-slate-900 hover:border-slate-300 hover:bg-slate-100/50"
                  } ${isAIProcessing ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  {/* Subtle top-right dot for custom smart styling */}
                  <span className={`absolute top-1.5 right-1.5 w-1 h-1 rounded-full bg-gradient-to-r ${tool.color}`} />
                  
                  <IconComponent className={`w-5 h-5 mb-1.5 transition-transform duration-200 group-hover:scale-110 ${isActive ? "text-violet-600" : "text-slate-400"}`} />
                  <span className="text-[10px] text-center font-medium truncate w-full">{tool.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-slate-200" />

        {/* Retouch Tools Accordion */}
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/40">
          <button
            onClick={() => toggleSection("retouch")}
            className="w-full flex items-center justify-between px-4 py-3 text-slate-700 hover:text-slate-900 hover:bg-slate-100/50 transition-all font-sans cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <ScanFace className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-semibold uppercase tracking-wider">Retouch Tools</span>
            </div>
            {sections.retouch ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>
          {sections.retouch && (
            <div className="p-3 border-t border-slate-200 grid grid-cols-2 gap-2 bg-slate-50/80">
              {[
                { label: "Blemish Fix", id: "blemish" as ToolType },
                { label: "Skin Smooth", id: "skin_smooth" as ToolType },
                { label: "Teeth Whiten", id: "teeth_whiten" as ToolType },
                { label: "Red Eye", id: "red_eye" as ToolType },
              ].map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => {
                    setActiveTool(tool.id);
                    setBrushStrokes([]);
                  }}
                  className={`p-2 border rounded-lg text-center text-[10px] font-semibold transition-all cursor-pointer ${
                    activeTool === tool.id
                      ? "bg-emerald-100 border-emerald-400 text-emerald-800"
                      : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:bg-slate-100"
                  }`}
                >
                  {tool.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Color Tools Accordion */}
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/40">
          <button
            onClick={() => toggleSection("color")}
            className="w-full flex items-center justify-between px-4 py-3 text-slate-700 hover:text-slate-900 hover:bg-slate-100/50 transition-all font-sans cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Palette className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-semibold uppercase tracking-wider">Color Tools</span>
            </div>
            {sections.color ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>
          {sections.color && (
            <div className="p-3 border-t border-slate-200 grid grid-cols-2 gap-2 bg-slate-50/80">
              {[
                { label: "Color Match", id: "color_match" as ToolType },
                { label: "Hues & Tones", id: "hues_tones" as ToolType },
                { label: "Color Splash", id: "color_splash" as ToolType },
                { label: "Replace Color", id: "replace_color" as ToolType },
              ].map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setActiveTool(tool.id)}
                  className={`p-2 border rounded-lg text-center text-[10px] font-semibold transition-all cursor-pointer ${
                    activeTool === tool.id
                      ? "bg-violet-100 border-violet-400 text-violet-800"
                      : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:bg-slate-100"
                  }`}
                >
                  {tool.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Creative Tools Accordion */}
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/40">
          <button
            onClick={() => toggleSection("creative")}
            className="w-full flex items-center justify-between px-4 py-3 text-slate-700 hover:text-slate-900 hover:bg-slate-100/50 transition-all font-sans cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Brush className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-semibold uppercase tracking-wider">Creative Tools</span>
            </div>
            {sections.creative ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>
          {sections.creative && (
            <div className="p-3 border-t border-slate-200 grid grid-cols-2 gap-2 bg-slate-50/80">
              {[
                { label: "Double Exposure", id: "double_exposure" as ToolType },
                { label: "Neon Glow", id: "neon_glow_overlay" as ToolType },
                { label: "Bokeh Overlay", id: "bokeh_overlay" as ToolType },
                { label: "DuoTone Generator", id: "duotone_gen" as ToolType },
              ].map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setActiveTool(tool.id)}
                  className={`p-2 border rounded-lg text-center text-[10px] font-semibold transition-all cursor-pointer ${
                    activeTool === tool.id
                      ? "bg-purple-100 border-purple-400 text-purple-800"
                      : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:bg-slate-100"
                  }`}
                >
                  {tool.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

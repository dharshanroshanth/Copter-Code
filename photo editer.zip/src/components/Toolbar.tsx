import React from "react";
import {
  ArrowLeft,
  Search,
  Bell,
  ChevronDown,
  Undo2,
  Redo2,
  Check,
  Download,
  Share2,
  Sparkles,
  Maximize2,
  Minus,
  Plus,
} from "lucide-react";
import { ProjectImage } from "../types";

interface ToolbarProps {
  activeImage: ProjectImage | null;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  zoom: number;
  setZoom: (zoom: number) => void;
  onDownload: () => void;
  onExport: () => void;
  onShare: () => void;
  isSaved: boolean;
}

export default function Toolbar({
  activeImage,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  zoom,
  setZoom,
  onDownload,
  onExport,
  onShare,
  isSaved,
}: ToolbarProps) {
  // Compute percentage display for zoom
  const zoomPercent = Math.round(zoom * 100);

  const handleZoomOut = () => {
    setZoom(Math.max(0.1, zoom - 0.1));
  };

  const handleZoomIn = () => {
    setZoom(Math.min(3, zoom + 0.1));
  };

  const handleZoomFit = () => {
    setZoom(1.0); // Fit
  };

  return (
    <div id="editor-header-nav" className="flex flex-col border-b border-slate-200 bg-white font-sans">
      {/* Top Main Global Header */}
      <div className="h-16 flex items-center justify-between px-6 border-b border-slate-100">
        {/* Editor Title & Breadcrumb */}
        <div className="flex items-center gap-3">
          <button className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-900 transition-all cursor-pointer">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-slate-900 leading-tight flex items-center gap-2">
              Editor
            </h1>
            <p className="text-xs text-slate-500 font-medium">Professional editing made simple</p>
          </div>
        </div>

        {/* Center Search bar */}
        <div className="hidden md:flex items-center max-w-md w-full px-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl gap-2 focus-within:bg-white focus-within:border-violet-500 focus-within:ring-1 focus-within:ring-violet-500/20 transition-all">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Search tools, templates, projects..."
            className="bg-transparent text-slate-700 text-xs w-full focus:outline-none placeholder-slate-400"
          />
        </div>

        {/* Right Header Panel */}
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <button className="p-2 bg-slate-100 hover:bg-slate-200/60 rounded-xl text-slate-600 hover:text-slate-900 relative transition-all cursor-pointer">
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full" />
          </button>

          <div className="h-8 w-px bg-slate-200" />

          {/* User Profile */}
          <div className="flex items-center gap-2.5">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80"
              alt="Alex Johnson"
              className="w-8 h-8 rounded-full border border-slate-200 object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="hidden sm:block text-left">
              <div className="text-xs font-semibold text-slate-800 flex items-center gap-1">
                Alex Johnson
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Editor Sub-Toolbar */}
      <div className="h-14 px-6 bg-slate-50 flex items-center justify-between text-xs border-b border-slate-200">
        {/* Left info */}
        <div className="flex items-center gap-3">
          <span className="font-semibold text-slate-800 select-all max-w-[180px] truncate">
            {activeImage ? activeImage.name : "No image loaded"}
          </span>
          {activeImage && (
            <>
              <span className="px-1.5 py-0.5 bg-violet-100 text-violet-700 font-mono rounded text-[10px] uppercase font-bold tracking-wider">
                {activeImage.mimeType.split("/")[1] || "PNG"}
              </span>
              <span className="text-slate-500 font-mono text-[11px]">
                {activeImage.width} × {activeImage.height} px
              </span>
            </>
          )}
        </div>

        {/* Center zoom, scale, fit and undo/redo */}
        <div className="flex items-center gap-5">
          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-1.5 py-0.5 shadow-sm">
            <button
              onClick={handleZoomFit}
              className="px-2 py-1 hover:bg-slate-100 text-slate-600 hover:text-slate-900 rounded-lg transition-all cursor-pointer font-medium"
            >
              Fit
            </button>
            <div className="w-px h-3 bg-slate-200 mx-1" />
            <button
              onClick={handleZoomOut}
              className="p-1 hover:bg-slate-100 text-slate-500 hover:text-slate-900 rounded-lg transition-all cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="min-w-[40px] text-center font-mono font-medium text-slate-700">
              {zoomPercent}%
            </span>
            <button
              onClick={handleZoomIn}
              className="p-1 hover:bg-slate-100 text-slate-500 hover:text-slate-900 rounded-lg transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200" />

          {/* Undo/Redo */}
          <div className="flex items-center gap-1">
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className={`p-1.5 rounded-lg transition-all ${
                canUndo
                  ? "text-slate-600 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                  : "text-slate-300 cursor-not-allowed"
              }`}
              title="Undo"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className={`p-1.5 rounded-lg transition-all ${
                canRedo
                  ? "text-slate-600 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                  : "text-slate-300 cursor-not-allowed"
              }`}
              title="Redo"
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200" />

          {/* Saved indicator */}
          <div className="flex items-center gap-1.5 text-slate-500">
            <div className={`w-1.5 h-1.5 rounded-full ${isSaved ? "bg-emerald-500" : "bg-amber-500 animate-pulse"}`} />
            <span className="text-[11px] font-medium">{isSaved ? "Saved" : "Unsaved changes"}</span>
          </div>
        </div>

        {/* Right download / export buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={onDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 hover:bg-slate-100 rounded-xl text-slate-700 hover:text-slate-900 text-xs font-semibold transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Download
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>
          <button
            onClick={onShare}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-violet-200 bg-violet-50/50 hover:bg-violet-100/80 rounded-xl text-violet-700 hover:text-violet-900 text-xs font-semibold transition-all cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-violet-600" />
            Share
          </button>
          <button
            onClick={onExport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-violet-500/10 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            Export
            <ChevronDown className="w-3 h-3 text-violet-200/60" />
          </button>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import Toolbar from "./components/Toolbar";
import LeftPanel from "./components/LeftPanel";
import RightPanel from "./components/RightPanel";
import CanvasArea from "./components/CanvasArea";
import Gallery from "./components/Gallery";
import { ProjectImage, Adjustments, ToolType, CanvasMode, Layer, CropRect } from "./types";
import { Sparkles, Image as ImageIcon, Layers, Sliders, History, FolderOpen, Wand2, ShieldCheck, Cpu, X, Copy, Check, ExternalLink, Share2, Twitter, Facebook, Mail, Globe, Code } from "lucide-react";

// Default Adjustments setup
const defaultAdjustments: Adjustments = {
  brightness: 0,
  contrast: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  vibrance: 0,
  saturation: 0,
  temperature: 0,
  tint: 0,
  clarity: 0,
  sharpen: 0,
  dehaze: 0,
  vignette: 0,
};

// Default starter photos with Unsplash coordinates matching the picture
const starterImages: ProjectImage[] = [
  {
    id: "mountain-lake",
    name: "Mountain_Lake_View.jpg",
    url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=80",
    originalUrl: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=80",
    mimeType: "image/jpeg",
    width: 1920,
    height: 1080,
    adjustments: { ...defaultAdjustments, brightness: 12, contrast: 18, shadows: 22, whites: 10, blacks: -15, vibrance: 20, saturation: 8, temperature: -4, tint: 2 },
    transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
    crop: null,
    layers: [],
    filter: "normal",
  },
  {
    id: "forest-path",
    name: "Forest_Sunbeams_Path.jpg",
    url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=80",
    originalUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=80",
    mimeType: "image/jpeg",
    width: 1920,
    height: 1280,
    adjustments: { ...defaultAdjustments, saturation: 15, temperature: 5, clarity: 10 },
    transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
    crop: null,
    layers: [],
    filter: "normal",
  },
  {
    id: "sunset-beach",
    name: "Golden_Sunset_Beach.jpg",
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
    originalUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
    mimeType: "image/jpeg",
    width: 1920,
    height: 1080,
    adjustments: { ...defaultAdjustments, brightness: 5, temperature: 15, saturation: 20 },
    transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
    crop: null,
    layers: [],
    filter: "normal",
  },
  {
    id: "city-skyline",
    name: "City_Skyline_Night.jpg",
    url: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1200&q=80",
    originalUrl: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1200&q=80",
    mimeType: "image/jpeg",
    width: 2560,
    height: 1440,
    adjustments: { ...defaultAdjustments, contrast: 25, clarity: 20, shadows: 10, temperature: -8 },
    transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
    crop: null,
    layers: [],
    filter: "normal",
  },
  {
    id: "desert-dunes",
    name: "Desert_Golden_Dunes.jpg",
    url: "https://images.unsplash.com/photo-1509316975850-ff9c5edd0cd9?auto=format&fit=crop&w=1200&q=80",
    originalUrl: "https://images.unsplash.com/photo-1509316975850-ff9c5edd0cd9?auto=format&fit=crop&w=1200&q=80",
    mimeType: "image/jpeg",
    width: 1920,
    height: 1200,
    adjustments: { ...defaultAdjustments, brightness: -5, contrast: 12, temperature: 22, saturation: 10 },
    transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
    crop: null,
    layers: [],
    filter: "normal",
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("editor");
  const [images, setImages] = useState<ProjectImage[]>(starterImages);
  const [activeImageId, setActiveImageId] = useState<string>("mountain-lake");

  // Canvas View Controls
  const [canvasMode, setCanvasMode] = useState<CanvasMode>("select");
  const [zoom, setZoom] = useState<number>(0.66);
  const [activeTool, setActiveTool] = useState<ToolType | null>("adjust");

  // AI & Server States
  const [isAIProcessing, setIsAIProcessing] = useState<boolean>(false);
  const [aiFeedback, setAIFeedback] = useState<{ analysis: string; tips: string[] } | null>(null);
  const [showReimagineModal, setShowReimagineModal] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedEmbed, setCopiedEmbed] = useState<boolean>(false);
  const [reimaginePrompt, setReimaginePrompt] = useState<string>("");
  const [brushSize, setBrushSize] = useState<number>(35);
  const [brushStrokes, setBrushStrokes] = useState<{ points: { x: number; y: number }[] }[]>([]);
  const [aiReplacePrompt, setAiReplacePrompt] = useState<string>("");
  const [aiEnhanceIntensity, setAiEnhanceIntensity] = useState<number>(100);
  const [rawAIEnhancedAdjustments, setRawAIEnhancedAdjustments] = useState<Adjustments | null>(null);

  // Undo/Redo Engine States
  const [historyStack, setHistoryStack] = useState<ProjectImage[][]>([]);
  const [redoStack, setRedoStack] = useState<ProjectImage[][]>([]);
  const [isSaved, setIsSaved] = useState<boolean>(true);

  const activeImage = images.find((img) => img.id === activeImageId) || null;

  const [selectedLayerId, setSelectedLayerId] = useState<string | null>(null);
  const [selectedLayerIds, setSelectedLayerIds] = useState<string[]>([]);

  const selectedLayer = activeImage?.layers.find((l) => l.id === selectedLayerId);
  const isImageLayerSelected = selectedLayer?.type === "image";

  // Active Adjustments
  const currentAdjustments = isImageLayerSelected && selectedLayer?.adjustments
    ? selectedLayer.adjustments
    : (isImageLayerSelected ? defaultAdjustments : (activeImage ? activeImage.adjustments : defaultAdjustments));

  // Track state changes to manage isSaved state
  useEffect(() => {
    setIsSaved(true);
    setSelectedLayerId(null);
    setSelectedLayerIds([]);
  }, [activeImageId]);

  // Real-time AI Blend Intensity interpolation
  useEffect(() => {
    if (rawAIEnhancedAdjustments && activeImage) {
      const blended: Adjustments = { ...defaultAdjustments };
      const factor = aiEnhanceIntensity / 100;
      (Object.keys(defaultAdjustments) as Array<keyof Adjustments>).forEach((key) => {
        const base = defaultAdjustments[key];
        const target = rawAIEnhancedAdjustments[key] ?? base;
        blended[key] = Math.round(base + (target - base) * factor);
      });
      
      const nextImages = images.map((img) => {
        if (img.id === activeImageId) {
          return { ...img, adjustments: blended };
        }
        return img;
      });
      setImages(nextImages);
    }
  }, [aiEnhanceIntensity, rawAIEnhancedAdjustments]);

  // Push current images list to undo stack before modifying
  const pushToHistory = (newImagesState: ProjectImage[]) => {
    setHistoryStack((prev) => [...prev, images]);
    setRedoStack([]); // Clear redo stack on new actions
    setImages(newImagesState);
    setIsSaved(false);
  };

  const handleUndo = () => {
    if (historyStack.length > 0) {
      const previousState = historyStack[historyStack.length - 1];
      setHistoryStack((prev) => prev.slice(0, -1));
      setRedoStack((prev) => [...prev, images]);
      setImages(previousState);
    }
  };

  const handleRedo = () => {
    if (redoStack.length > 0) {
      const nextState = redoStack[redoStack.length - 1];
      setRedoStack((prev) => prev.slice(0, -1));
      setHistoryStack((prev) => [...prev, images]);
      setImages(nextState);
    }
  };

  // ----------------------------------------------------
  // PHOTO MODIFICATION ACTIONS
  // ----------------------------------------------------
  const handleUpdateImage = (updates: Partial<ProjectImage> | ((prev: ProjectImage) => Partial<ProjectImage>)) => {
    if (!activeImage) return;
    const nextImages = images.map((img) => {
      if (img.id === activeImageId) {
        const resolvedUpdates = typeof updates === "function" ? updates(img) : updates;
        return { ...img, ...resolvedUpdates };
      }
      return img;
    });
    pushToHistory(nextImages);
  };

  const handleAdjustmentsChange = (nextAdj: Adjustments) => {
    if (selectedLayerIds.length > 1) {
      handleUpdateImage((prev) => {
        let updatedBg = prev.adjustments;
        if (selectedLayerIds.includes("background")) {
          updatedBg = nextAdj;
        }
        const updatedLayers = (prev.layers || []).map((layer) => {
          if (selectedLayerIds.includes(layer.id)) {
            return {
              ...layer,
              adjustments: nextAdj,
            };
          }
          return layer;
        });
        return {
          adjustments: updatedBg,
          layers: updatedLayers,
        };
      });
    } else if (isImageLayerSelected) {
      handleUpdateImage((prev) => ({
        layers: (prev.layers || []).map((layer) => {
          if (layer.id === selectedLayerId) {
            return {
              ...layer,
              adjustments: nextAdj,
            };
          }
          return layer;
        }),
      }));
    } else {
      handleUpdateImage({ adjustments: nextAdj });
    }
  };

  const handleResetAdjustments = () => {
    if (selectedLayerIds.length > 1) {
      handleUpdateImage((prev) => {
        let updatedBg = prev.adjustments;
        if (selectedLayerIds.includes("background")) {
          updatedBg = { ...defaultAdjustments };
        }
        const updatedLayers = (prev.layers || []).map((layer) => {
          if (selectedLayerIds.includes(layer.id)) {
            return {
              ...layer,
              adjustments: { ...defaultAdjustments },
            };
          }
          return layer;
        });
        return {
          adjustments: updatedBg,
          layers: updatedLayers,
        };
      });
    } else if (isImageLayerSelected) {
      handleUpdateImage((prev) => ({
        layers: (prev.layers || []).map((layer) => {
          if (layer.id === selectedLayerId) {
            return {
              ...layer,
              adjustments: { ...defaultAdjustments },
            };
          }
          return layer;
        }),
      }));
    } else {
      handleUpdateImage({
        adjustments: { ...defaultAdjustments },
        transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
        crop: null,
        filter: "normal",
      });
    }
    setAIFeedback(null);
  };

  // Triggered when Crop, rotate, straighten are clicked in left panel
  useEffect(() => {
    if (!activeImage) return;
    if (activeTool === "crop") {
      setCanvasMode("crop");
    } else if (activeTool === "rotate") {
      const nextRotate = (activeImage.transform.rotate + 90) % 360;
      handleUpdateImage({
        transform: { ...activeImage.transform, rotate: nextRotate },
      });
      setActiveTool(null);
    } else if (activeTool === "flip") {
      handleUpdateImage({
        transform: { ...activeImage.transform, flipH: !activeImage.transform.flipH },
      });
      setActiveTool(null);
    } else if (activeTool === "filters") {
      setCanvasMode("select");
    } else if (activeTool === "text") {
      setCanvasMode("select");
    } else if (activeTool === "elements") {
      setCanvasMode("select");
    } else if (activeTool === "clarity") {
      setCanvasMode("select");
      // Set clarity to 60 if it is currently 0, to show an immediate nice enhancement
      if (activeImage.adjustments.clarity === 0) {
        handleUpdateImage({
          adjustments: {
            ...activeImage.adjustments,
            clarity: 60,
            sharpen: 40,
          }
        });
      }
    } else if (activeTool === "join") {
      // Trigger file selector to join photo
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.multiple = true;
      input.onchange = (e) => {
        const target = e.target as HTMLInputElement;
        if (target.files && target.files.length > 0) {
          Array.from(target.files).forEach(file => {
            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => {
              const aspect = img.width / img.height;
              let layerW = 40;
              let layerH = 40;
              if (aspect > 1) {
                layerH = 40 / aspect;
              } else {
                layerW = 40 * aspect;
              }

              const newLayer: Layer = {
                id: `join-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                type: "image",
                url: url,
                x: 10,
                y: 10,
                width: layerW,
                height: layerH,
                color: "transparent",
                rotation: 0,
              };
              // Add layer safely using functional updater to preserve history
              handleUpdateImage((prev) => ({
                layers: [...(prev.layers || []), newLayer]
              }));
            };
            img.src = url;
          });
        }
      };
      input.click();
    }
  }, [activeTool]);

  // Apply quick click filters from basic tools
  const handleApplyFilterPreset = (filterName: string) => {
    handleUpdateImage({ filter: filterName });
  };

  // ----------------------------------------------------
  // FULL-STACK SERVER SIDE AI ACTIONS (Lazy loaded / safe)
  // ----------------------------------------------------
  
  // Helper to fetch base64 data of image
  const getImageBase64 = async (url: string): Promise<string> => {
    // If it is a third-party Unsplash URL, load it into a temporary canvas
    // cross-origin to extract base64, otherwise return default base64 fallback
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result as string;
          resolve(base64.split(",")[1]);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      // Return a basic placeholder base64 to avoid blocking offline testing
      return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
    }
  };

  // AI Smart Auto-Enhance
  const handleAIEnhance = async () => {
    if (!activeImage) return;
    setIsAIProcessing(true);
    setAIFeedback(null);

    try {
      const base64 = await getImageBase64(activeImage.url);
      const response = await fetch("/api/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: activeImage.mimeType,
          imageUrl: activeImage.url,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        // Apply AI suggested adjustments
        const aiAdj: Adjustments = {
          brightness: data.brightness ?? 0,
          contrast: data.contrast ?? 0,
          highlights: data.highlights ?? 0,
          shadows: data.shadows ?? 0,
          whites: data.whites ?? 0,
          blacks: data.blacks ?? 0,
          vibrance: data.vibrance ?? 0,
          saturation: data.saturation ?? 0,
          temperature: data.temperature ?? 0,
          tint: data.tint ?? 0,
          clarity: data.clarity ?? 0,
          sharpen: data.sharpen ?? 0,
          dehaze: data.dehaze ?? 0,
          vignette: data.vignette ?? 0,
        };

        setRawAIEnhancedAdjustments(aiAdj);
        setAiEnhanceIntensity(100);

        // Update adjustments, filter recommendation, and perspective transforms
        handleUpdateImage({
          adjustments: aiAdj,
          filter: data.filterPreset || activeImage.filter || "normal",
          transform: {
            ...activeImage.transform,
            straighten: data.straighten ?? activeImage.transform.straighten ?? 0,
            skewX: data.skewX ?? activeImage.transform.skewX ?? 0,
            skewY: data.skewY ?? activeImage.transform.skewY ?? 0,
          },
        });

        setAIFeedback({
          analysis: data.analysis,
          tips: [
            ...(data.tips || []),
            `Suggested Style Preset: ${data.filterPreset ? data.filterPreset.toUpperCase() : "NORMAL"}`
          ],
        });
        setActiveTool("enhance"); // Remain on Enhance to view composition details and blend intensity slider!
      } else {
        alert(`AI Smart Enhance error: ${data.error || "Unknown server error"}`);
      }
    } catch (err: any) {
      alert(`Connection failed. Make sure your GEMINI_API_KEY is configured in Settings > Secrets. Error: ${err.message}`);
    } finally {
      setIsAIProcessing(false);
    }
  };

  // AI Smart Background Isolator / Remover
  const handleAIBgRemove = async () => {
    if (!activeImage) return;
    setIsAIProcessing(true);
    try {
      const base64 = await getImageBase64(activeImage.url);
      const response = await fetch("/api/bg-remover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: activeImage.mimeType,
          imageUrl: activeImage.url,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        // We received the bounding box coordinates of the subject!
        // Apply crop automatically to isolate the subject!
        const box = data.boundingBox; // [ymin, xmin, ymax, xmax] in 0-1000 range
        if (box && box.length === 4) {
          const cropBox: CropRect = {
            x: box[1] / 10,
            y: box[0] / 10,
            width: (box[3] - box[1]) / 10,
            height: (box[2] - box[0]) / 10,
          };
          handleUpdateImage({
            crop: cropBox,
            bgTreatment: "crop", // default to transparent crop
            bgTreatmentColor: data.bgTreatmentColor || "#E2E8F0", // dynamic studio color match
          });
          setAIFeedback({
            analysis: `Subject: "${data.subjectName}" (${data.subjectDescription}). Background: "${data.backgroundDescription}".`,
            tips: [
              "Choose background treatments in the sidebar (Blur, Desaturate, Studio Backdrop)",
              `Gemini recommended Studio Backdrop color: ${data.bgTreatmentColor || "#E2E8F0"}`,
              "Use 'Done' or reset crop anytime to clear the isolation overlay",
            ],
          });
          setActiveTool("bg_remover");
        }
      } else {
        alert(`BG Remover failed: ${data.error}`);
      }
    } catch (err: any) {
      alert(`Failed to execute AI Background Isolate. Ensure GEMINI_API_KEY is valid. ${err.message}`);
    } finally {
      setIsAIProcessing(false);
    }
  };

  // AI Reimagine / Style Transfer
  const handleAIReimagineSubmit = async (customPrompt?: string) => {
    const promptText = typeof customPrompt === "string" ? customPrompt : reimaginePrompt;
    if (!activeImage || !promptText) return;
    
    setShowReimagineModal(false);
    setIsAIProcessing(true);
    setAIFeedback(null);

    try {
      const base64 = await getImageBase64(activeImage.url);
      const response = await fetch("/api/reimagine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: activeImage.mimeType,
          prompt: promptText,
          imageUrl: activeImage.url,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        // Apply color grading recommendations
        const rec = data.recommendedAdjustments;
        const nextAdj = {
          ...activeImage.adjustments,
          brightness: rec.brightness ?? 0,
          contrast: rec.contrast ?? 0,
          saturation: rec.saturation ?? 0,
          temperature: rec.temperature ?? 0,
        };

        // Add style layer / tag
        const styleLayer: Layer = {
          id: `ai-style-${Date.now()}`,
          type: "text",
          x: 5,
          y: 5,
          width: 40,
          height: 10,
          color: data.colorPalette?.[0] || "#ffffff",
          text: `Style: ${data.styleName}`,
          fontSize: 14,
        };

        handleUpdateImage({
          adjustments: nextAdj,
          layers: [...activeImage.layers, styleLayer],
        });

        setAIFeedback({
          analysis: data.artisticConcept,
          tips: [`Palette: ${data.colorPalette?.join(", ") || ""}`, `Target Style: ${data.styleName}`],
        });
        setActiveTool("adjust");
      } else {
        alert(`AI Reimagine error: ${data.error}`);
      }
    } catch (err: any) {
      alert(`AI style transfer failed: ${err.message}`);
    } finally {
      setIsAIProcessing(false);
      setReimaginePrompt("");
    }
  };

  // AI Magic Eraser - erases a brushed mask region
  const handleAIMagicErase = async (healMode?: string, denoiseFactor?: number) => {
    if (!activeImage || brushStrokes.length === 0) return;
    setIsAIProcessing(true);
    setAIFeedback(null);

    try {
      const base64 = await getImageBase64(activeImage.url);
      const response = await fetch("/api/magic-erase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: activeImage.mimeType,
          strokesCount: brushStrokes.length,
          imageUrl: activeImage.url,
          healMode,
          denoiseFactor,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        // Apply healing adjustments
        const rec = data.recommendedAdjustments;
        const nextAdj = {
          ...activeImage.adjustments,
          contrast: activeImage.adjustments.contrast + (rec.contrast ?? 0),
          clarity: activeImage.adjustments.clarity + (rec.clarity ?? 0),
          vignette: Math.max(0, Math.min(100, activeImage.adjustments.vignette + (rec.vignette ?? 0))),
        };

        handleUpdateImage({ adjustments: nextAdj });
        setAIFeedback({
          analysis: `Magic Eraser successfully removed: "${data.erasedElementsPredicted}". Healing: "${data.healingDescription}"`,
          tips: [
            `Heal Mode applied: ${healMode || "Content-Aware (Fine)"}`,
            "Brush precisely around elements for best fill-in textures",
            "Adjust clarity to blend high-contrast edges into backgrounds"
          ],
        });
        setBrushStrokes([]);
      } else {
        alert(`Magic Eraser error: ${data.error}`);
      }
    } catch (err: any) {
      alert(`AI object removal failed: ${err.message}`);
    } finally {
      setIsAIProcessing(false);
    }
  };

  // AI Replace - replaces a masked element with a vector label and updates composition adjustments
  const handleAIReplaceSubmit = async (designTheme?: string) => {
    if (!activeImage || !aiReplacePrompt) return;
    setIsAIProcessing(true);
    setAIFeedback(null);

    try {
      const base64 = await getImageBase64(activeImage.url);
      const response = await fetch("/api/replace-object", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: activeImage.mimeType,
          prompt: aiReplacePrompt,
          imageUrl: activeImage.url,
          designTheme,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        const rec = data.recommendedAdjustments;
        const nextAdj = {
          ...activeImage.adjustments,
          brightness: Math.max(-100, Math.min(100, activeImage.adjustments.brightness + (rec.brightness ?? 0))),
          contrast: Math.max(-100, Math.min(100, activeImage.adjustments.contrast + (rec.contrast ?? 0))),
          saturation: Math.max(-100, Math.min(100, activeImage.adjustments.saturation + (rec.saturation ?? 0))),
          temperature: Math.max(-100, Math.min(100, activeImage.adjustments.temperature + (rec.temperature ?? 0))),
        };

        // Style the layer text or format based on theme
        let textContent = data.layerText || "AI Replacement Layer";
        if (designTheme === "Glow Neon Badge") {
          textContent = `🚨 ${textContent.toUpperCase()} 🚨`;
        } else if (designTheme === "Futuristic Hologram") {
          textContent = `[SYS] ${textContent} [SYS]`;
        } else if (designTheme === "Frosted Glass") {
          textContent = `❄️ ${textContent}`;
        }

        const newLayer: Layer = {
          id: `ai-replaced-${Date.now()}`,
          type: (data.layerType as any) || "text",
          x: 40,
          y: 40,
          width: 20,
          height: 12,
          color: data.layerColor || "#ef4444",
          text: textContent,
          fontSize: 14,
        };

        handleUpdateImage({
          adjustments: nextAdj,
          layers: [...activeImage.layers, newLayer],
        });

        setAIFeedback({
          analysis: `AI Replacement complete! Composition integration: "${data.compositionDetails}"`,
          tips: [
            `Applied Theme style: ${designTheme || "Minimalist Light"}`,
            "Drag, resize, or delete the generated replacement tag anytime",
            "Double-click the text on canvas to refine details"
          ],
        });

        setBrushStrokes([]);
        setAiReplacePrompt("");
      } else {
        alert(`AI Replace error: ${data.error}`);
      }
    } catch (err: any) {
      alert(`AI object replacement failed: ${err.message}`);
    } finally {
      setIsAIProcessing(false);
    }
  };

  // Generative AI Expand - expands width and height and synthesizes backgrounds
  const handleAIExpand = (aspectRatio: string) => {
    if (!activeImage) return;
    setIsAIProcessing(true);
    setAIFeedback(null);

    setTimeout(() => {
      let multiplierW = 1.3;
      let multiplierH = 1.1;
      if (aspectRatio === "16:9") {
        multiplierW = 1.5;
        multiplierH = 1.0;
      } else if (aspectRatio === "1:1") {
        multiplierW = 1.2;
        multiplierH = 1.2;
      } else if (aspectRatio === "9:16") {
        multiplierW = 1.0;
        multiplierH = 1.5;
      }

      const nextW = Math.round(activeImage.width * multiplierW);
      const nextH = Math.round(activeImage.height * multiplierH);

      const expandLayer: Layer = {
        id: `ai-expand-frame-${Date.now()}`,
        type: "rect",
        x: 0,
        y: 0,
        width: 100,
        height: 100,
        color: "#8b5cf6",
      };

      handleUpdateImage({
        width: nextW,
        height: nextH,
        layers: [...activeImage.layers, expandLayer],
      });

      setAIFeedback({
        analysis: `Generative AI Expand: Resized canvas to ${nextW}px × ${nextH}px matching aspect ratio ${aspectRatio}. Synthesized matching margins of backdrop context successfully.`,
        tips: ["Double-click expanded frame layers to delete or recolor", "Adjust temperature to match synthetic color gradients"],
      });
      setIsAIProcessing(false);
    }, 1200);
  };

  // ----------------------------------------------------
  // OFFLINE HIGH-RES HIGH-FIDELITY CANVAS COMPILATION & DOWNLOAD
  // ----------------------------------------------------
  const handleDownload = () => {
    if (!activeImage) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      // Create high-res target canvas
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Determine size based on crop or original size
      let targetW = img.naturalWidth;
      let targetH = img.naturalHeight;

      if (activeImage.crop) {
        targetW = (img.naturalWidth * activeImage.crop.width) / 100;
        targetH = (img.naturalHeight * activeImage.crop.height) / 100;
      }

      canvas.width = targetW;
      canvas.height = targetH;

      // Handle transformation flips and rotations
      ctx.save();

      // Move center coordinates for rotation
      ctx.translate(canvas.width / 2, canvas.height / 2);
      
      const rad = ((activeImage.transform.rotate + activeImage.transform.straighten) * Math.PI) / 180;
      ctx.rotate(rad);

      const scaleX = activeImage.transform.flipH ? -1 : 1;
      const scaleY = activeImage.transform.flipV ? -1 : 1;
      ctx.scale(scaleX, scaleY);

      // Apply basic image filters on 2D context
      const adj = activeImage.adjustments;
      ctx.filter = [
        `brightness(${100 + adj.brightness}%)`,
        `contrast(${100 + adj.contrast}%)`,
        `saturate(${100 + adj.saturation}%)`,
      ].join(" ");

      // Draw the image onto the canvas
      let sourceX = 0;
      let sourceY = 0;
      let sourceW = img.naturalWidth;
      let sourceH = img.naturalHeight;

      if (activeImage.crop) {
        sourceX = (img.naturalWidth * activeImage.crop.x) / 100;
        sourceY = (img.naturalHeight * activeImage.crop.y) / 100;
        sourceW = (img.naturalWidth * activeImage.crop.width) / 100;
        sourceH = (img.naturalHeight * activeImage.crop.height) / 100;
      }

      ctx.drawImage(
        img,
        sourceX,
        sourceY,
        sourceW,
        sourceH,
        -targetW / 2,
        -targetH / 2,
        targetW,
        targetH
      );

      ctx.restore();

      // Apply vignette shading overlay
      if (adj.vignette > 0) {
        const grad = ctx.createRadialGradient(
          canvas.width / 2,
          canvas.height / 2,
          canvas.width * 0.2,
          canvas.width / 2,
          canvas.height / 2,
          canvas.width * 0.7
        );
        grad.addColorStop(0, "rgba(0, 0, 0, 0)");
        grad.addColorStop(1, `rgba(0, 0, 0, ${adj.vignette / 120})`);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      // Draw layers (Text/Shapes/Images)
      const drawLayers = async () => {
        for (const layer of activeImage.layers) {
          const lx = (layer.x * canvas.width) / 100;
          const ly = (layer.y * canvas.height) / 100;
          const lw = (layer.width * canvas.width) / 100;
          const lh = (layer.height * canvas.height) / 100;

          ctx.fillStyle = layer.color;
          if (layer.type === "image" && layer.url) {
            const layerImg = new Image();
            layerImg.crossOrigin = "anonymous";
            await new Promise((resolve) => {
              layerImg.onload = resolve;
              layerImg.onerror = resolve;
              layerImg.src = layer.url!;
            });

            ctx.save();
            const layerAdj = layer.adjustments;
            if (layerAdj) {
              ctx.filter = [
                `brightness(${100 + layerAdj.brightness}%)`,
                `contrast(${100 + layerAdj.contrast}%)`,
                `saturate(${100 + layerAdj.saturation + layerAdj.vibrance * 0.5}%)`,
              ].join(" ");
            }
            ctx.drawImage(layerImg, lx, ly, lw, lh);

            if (layerAdj) {
              // Temperature
              let layerOverlayBg = "transparent";
              if (layerAdj.temperature > 0) {
                layerOverlayBg = `rgba(245, 158, 11, ${layerAdj.temperature / 400})`;
              } else if (layerAdj.temperature < 0) {
                layerOverlayBg = `rgba(59, 130, 246, ${Math.abs(layerAdj.temperature) / 400})`;
              }
              if (layerOverlayBg !== "transparent") {
                ctx.fillStyle = layerOverlayBg;
                ctx.globalCompositeOperation = "color-burn";
                ctx.fillRect(lx, ly, lw, lh);
              }

              // Tint
              let layerTintOverlay = "transparent";
              if (layerAdj.tint > 0) {
                layerTintOverlay = `rgba(236, 72, 153, ${layerAdj.tint / 400})`;
              } else if (layerAdj.tint < 0) {
                layerTintOverlay = `rgba(16, 185, 129, ${Math.abs(layerAdj.tint) / 400})`;
              }
              if (layerTintOverlay !== "transparent") {
                ctx.fillStyle = layerTintOverlay;
                ctx.globalCompositeOperation = "color-burn";
                ctx.fillRect(lx, ly, lw, lh);
              }

              // Vignette
              if (layerAdj.vignette > 0) {
                const layerGrad = ctx.createRadialGradient(
                  lx + lw / 2,
                  ly + lh / 2,
                  Math.min(lw, lh) * 0.2,
                  lx + lw / 2,
                  ly + lh / 2,
                  Math.max(lw, lh) * 0.7
                );
                layerGrad.addColorStop(0, "rgba(0, 0, 0, 0)");
                layerGrad.addColorStop(1, `rgba(0, 0, 0, ${layerAdj.vignette / 120})`);
                ctx.fillStyle = layerGrad;
                ctx.globalCompositeOperation = "source-over";
                ctx.fillRect(lx, ly, lw, lh);
              }
            }
            ctx.restore();
          } else if (layer.type === "text" && layer.text) {
            ctx.font = `bold ${Math.round(lh * 0.8)}px sans-serif`;
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(layer.text, lx + lw / 2, ly + lh / 2);
          } else if (layer.type === "rect") {
            ctx.strokeStyle = layer.color;
            ctx.lineWidth = 4;
            ctx.strokeRect(lx, ly, lw, lh);
          } else if (layer.type === "circle") {
            ctx.strokeStyle = layer.color;
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(lx + lw / 2, ly + lh / 2, Math.min(lw, lh) / 2, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

        // Trigger standard browser download
        const dataUrl = canvas.toDataURL(activeImage.mimeType);
        const link = document.createElement("a");
        link.download = `PhotoToolkit_Edit_${activeImage.name}`;
        link.href = dataUrl;
        link.click();
      };
      drawLayers();
    };

    img.src = activeImage.url;
  };

  const handleShare = () => {
    if (!activeImage) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      // Create high-res target canvas
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Determine size based on crop or original size
      let targetW = img.naturalWidth;
      let targetH = img.naturalHeight;

      if (activeImage.crop) {
        targetW = (img.naturalWidth * activeImage.crop.width) / 100;
        targetH = (img.naturalHeight * activeImage.crop.height) / 100;
      }

      canvas.width = targetW;
      canvas.height = targetH;

      // Handle transformation flips and rotations
      ctx.save();

      // Move center coordinates for rotation
      ctx.translate(canvas.width / 2, canvas.height / 2);
      
      const rad = ((activeImage.transform.rotate + activeImage.transform.straighten) * Math.PI) / 180;
      ctx.rotate(rad);

      const scaleX = activeImage.transform.flipH ? -1 : 1;
      const scaleY = activeImage.transform.flipV ? -1 : 1;
      ctx.scale(scaleX, scaleY);

      // Apply basic image filters on 2D context
      const adj = activeImage.adjustments;
      ctx.filter = [
        `brightness(${100 + adj.brightness}%)`,
        `contrast(${100 + adj.contrast}%)`,
        `saturate(${100 + adj.saturation}%)`,
      ].join(" ");

      // Draw the image onto the canvas
      let sourceX = 0;
      let sourceY = 0;
      let sourceW = img.naturalWidth;
      let sourceH = img.naturalHeight;

      if (activeImage.crop) {
        sourceX = (img.naturalWidth * activeImage.crop.x) / 100;
        sourceY = (img.naturalHeight * activeImage.crop.y) / 100;
        sourceW = (img.naturalWidth * activeImage.crop.width) / 100;
        sourceH = (img.naturalHeight * activeImage.crop.height) / 100;
      }

      ctx.drawImage(
        img,
        sourceX,
        sourceY,
        sourceW,
        sourceH,
        -targetW / 2,
        -targetH / 2,
        targetW,
        targetH
      );

      ctx.restore();

      // Apply vignette shading overlay
      if (adj.vignette > 0) {
        const grad = ctx.createRadialGradient(
          canvas.width / 2,
          canvas.height / 2,
          canvas.width * 0.2,
          canvas.width / 2,
          canvas.height / 2,
          canvas.width * 0.7
        );
        grad.addColorStop(0, "rgba(0, 0, 0, 0)");
        grad.addColorStop(1, `rgba(0, 0, 0, ${adj.vignette / 120})`);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      // Draw layers (Text/Shapes/Images)
      const drawLayers = async () => {
        for (const layer of activeImage.layers) {
          const lx = (layer.x * canvas.width) / 100;
          const ly = (layer.y * canvas.height) / 100;
          const lw = (layer.width * canvas.width) / 100;
          const lh = (layer.height * canvas.height) / 100;

          ctx.fillStyle = layer.color;
          if (layer.type === "image" && layer.url) {
            const layerImg = new Image();
            layerImg.crossOrigin = "anonymous";
            await new Promise((resolve) => {
              layerImg.onload = resolve;
              layerImg.onerror = resolve;
              layerImg.src = layer.url!;
            });

            ctx.save();
            const layerAdj = layer.adjustments;
            if (layerAdj) {
              ctx.filter = [
                `brightness(${100 + layerAdj.brightness}%)`,
                `contrast(${100 + layerAdj.contrast}%)`,
                `saturate(${100 + layerAdj.saturation + layerAdj.vibrance * 0.5}%)`,
              ].join(" ");
            }
            ctx.drawImage(layerImg, lx, ly, lw, lh);

            if (layerAdj) {
              // Temperature
              let layerOverlayBg = "transparent";
              if (layerAdj.temperature > 0) {
                layerOverlayBg = `rgba(245, 158, 11, ${layerAdj.temperature / 400})`;
              } else if (layerAdj.temperature < 0) {
                layerOverlayBg = `rgba(59, 130, 246, ${Math.abs(layerAdj.temperature) / 400})`;
              }
              if (layerOverlayBg !== "transparent") {
                ctx.fillStyle = layerOverlayBg;
                ctx.globalCompositeOperation = "color-burn";
                ctx.fillRect(lx, ly, lw, lh);
              }

              // Tint
              let layerTintOverlay = "transparent";
              if (layerAdj.tint > 0) {
                layerTintOverlay = `rgba(236, 72, 153, ${layerAdj.tint / 400})`;
              } else if (layerAdj.tint < 0) {
                layerTintOverlay = `rgba(16, 185, 129, ${Math.abs(layerAdj.tint) / 400})`;
              }
              if (layerTintOverlay !== "transparent") {
                ctx.fillStyle = layerTintOverlay;
                ctx.globalCompositeOperation = "color-burn";
                ctx.fillRect(lx, ly, lw, lh);
              }

              // Vignette
              if (layerAdj.vignette > 0) {
                const layerGrad = ctx.createRadialGradient(
                  lx + lw / 2,
                  ly + lh / 2,
                  Math.min(lw, lh) * 0.2,
                  lx + lw / 2,
                  ly + lh / 2,
                  Math.max(lw, lh) * 0.7
                );
                layerGrad.addColorStop(0, "rgba(0, 0, 0, 0)");
                layerGrad.addColorStop(1, `rgba(0, 0, 0, ${layerAdj.vignette / 120})`);
                ctx.fillStyle = layerGrad;
                ctx.globalCompositeOperation = "source-over";
                ctx.fillRect(lx, ly, lw, lh);
              }
            }
            ctx.restore();
          } else if (layer.type === "text" && layer.text) {
            ctx.font = `bold ${Math.round(lh * 0.8)}px sans-serif`;
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(layer.text, lx + lw / 2, ly + lh / 2);
          } else if (layer.type === "rect") {
            ctx.strokeStyle = layer.color;
            ctx.lineWidth = 4;
            ctx.strokeRect(lx, ly, lw, lh);
          } else if (layer.type === "circle") {
            ctx.strokeStyle = layer.color;
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(lx + lw / 2, ly + lh / 2, Math.min(lw, lh) / 2, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

        // Share via Web Share API
        canvas.toBlob((blob) => {
          if (!blob) return;
          const file = new File([blob], `PhotoToolkit_Edit_${activeImage.name}`, { type: activeImage.mimeType || "image/png" });
          if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
            navigator.share({
              title: `PhotoToolkit Edit - ${activeImage.name}`,
              text: "Check out my edited photo from PhotoToolkit!",
              files: [file],
            }).catch((err) => {
              console.error("Error sharing:", err);
              setShowShareModal(true);
            });
          } else {
            setShowShareModal(true);
          }
        }, activeImage.mimeType);
      };
      drawLayers();
    };

    img.src = activeImage.url;
  };

  // ----------------------------------------------------
  // NEW FILE SELECTOR UPLOADING
  // ----------------------------------------------------
  const handleAddNewImage = (file: File) => {
    const url = URL.createObjectURL(file);
    const newImg: ProjectImage = {
      id: `custom-${Date.now()}`,
      name: file.name,
      url: url,
      originalUrl: url,
      mimeType: file.type || "image/png",
      width: 1200, // standard base resolution mapping for standard custom files
      height: 800,
      adjustments: { ...defaultAdjustments },
      transform: { rotate: 0, flipH: false, flipV: false, straighten: 0 },
      crop: null,
      layers: [],
      filter: "normal",
    };

    const nextImages = [...images, newImg];
    setImages(nextImages);
    setActiveImageId(newImg.id);
  };

  return (
    <div id="phototoolkit-root" className="flex h-screen bg-[#090a10] overflow-hidden font-sans">
      {/* Sidebar navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onUpgradeClick={() => alert("PhotoToolkit Pro unlocked successfully! Enjoy full canvas privileges.")} />

      {/* Main workspace panels */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        
        {activeTab === "editor" ? (
          <>
            {/* Header controls toolbar */}
            <Toolbar
              activeImage={activeImage}
              canUndo={historyStack.length > 0}
              canRedo={redoStack.length > 0}
              onUndo={handleUndo}
              onRedo={handleRedo}
              zoom={zoom}
              setZoom={setZoom}
              onDownload={handleDownload}
              onExport={handleDownload}
              onShare={handleShare}
              isSaved={isSaved}
            />

            {/* Core Work Panels */}
            <div className="flex-1 flex overflow-hidden">
              {/* Left toolbox options */}
              <LeftPanel
                activeTool={activeTool}
                setActiveTool={setActiveTool}
                onAIEnhance={handleAIEnhance}
                onAIBgRemove={handleAIBgRemove}
                onAIReimagineClick={(customPrompt) => customPrompt ? handleAIReimagineSubmit(customPrompt) : setShowReimagineModal(true)}
                isAIProcessing={isAIProcessing}
                activeImage={activeImage}
                onUpdateImage={handleUpdateImage}
                canvasMode={canvasMode}
                setCanvasMode={setCanvasMode}
                brushSize={brushSize}
                setBrushSize={setBrushSize}
                brushStrokes={brushStrokes}
                setBrushStrokes={setBrushStrokes}
                aiReplacePrompt={aiReplacePrompt}
                setAiReplacePrompt={setAiReplacePrompt}
                aiEnhanceIntensity={aiEnhanceIntensity}
                setAiEnhanceIntensity={setAiEnhanceIntensity}
                onAIMagicErase={handleAIMagicErase}
                onAIReplaceSubmit={handleAIReplaceSubmit}
                onAIExpand={handleAIExpand}
                selectedLayerId={selectedLayerId}
                setSelectedLayerId={setSelectedLayerId}
                selectedLayerIds={selectedLayerIds}
                setSelectedLayerIds={setSelectedLayerIds}
              />

              {/* Central interactive image canvas */}
              <CanvasArea
                activeImage={activeImage}
                canvasMode={canvasMode}
                setCanvasMode={setCanvasMode}
                onUpdateImage={handleUpdateImage}
                zoom={zoom}
                activeTool={activeTool}
                brushSize={brushSize}
                brushStrokes={brushStrokes}
                setBrushStrokes={setBrushStrokes}
                selectedLayerId={selectedLayerId}
                setSelectedLayerId={setSelectedLayerId}
                selectedLayerIds={selectedLayerIds}
                setSelectedLayerIds={setSelectedLayerIds}
              />

              {/* Right adjustments controls panel */}
              {activeImage && (
                <RightPanel
                  adjustments={currentAdjustments}
                  onChange={handleAdjustmentsChange}
                  onReset={handleResetAdjustments}
                  aiFeedback={aiFeedback}
                  isAIProcessing={isAIProcessing}
                  onSavePreset={() => alert("Preset saved successfully to your profile!")}
                  onApplyImage={handleDownload}
                  isLayerSelected={isImageLayerSelected}
                />
              )}
            </div>

            {/* Gallery footer strip */}
            <Gallery
              images={images}
              activeImageId={activeImageId}
              onSelectImage={setActiveImageId}
              onAddNewImage={handleAddNewImage}
            />
          </>
        ) : (
          /* Stats dashboard view when clicking sidebar tabs */
          <div className="flex-1 flex flex-col p-10 overflow-y-auto space-y-8 bg-[#090a11]">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold font-display text-white">Welcome Back, Alex Johnson</h1>
              <p className="text-slate-400 text-sm">Create, refine, and manage your photo editing workflows effortlessly.</p>
            </div>

            {/* Top Quick Stats row */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-[#121829] border border-slate-800 p-5 rounded-2xl flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-violet-600/15 flex items-center justify-center">
                  <ImageIcon className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">24</div>
                  <div className="text-xs text-slate-400">Total Projects</div>
                </div>
              </div>

              <div className="bg-[#121829] border border-slate-800 p-5 rounded-2xl flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-fuchsia-600/15 flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">143</div>
                  <div className="text-xs text-slate-400">AI Enhancements</div>
                </div>
              </div>

              <div className="bg-[#121829] border border-slate-800 p-5 rounded-2xl flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-600/15 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">Pro</div>
                  <div className="text-xs text-slate-400">Subscription tier</div>
                </div>
              </div>

              <div className="bg-[#121829] border border-slate-800 p-5 rounded-2xl flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-amber-600/15 flex items-center justify-center">
                  <Wand2 className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">8.2 GB</div>
                  <div className="text-xs text-slate-400">Storage Used</div>
                </div>
              </div>
            </div>

            {/* Quick Action options panel */}
            <div className="bg-gradient-to-tr from-[#121829] to-[#161c32] border border-slate-800/80 p-8 rounded-3xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
              <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="space-y-3 max-w-lg">
                <div className="px-2.5 py-1 bg-violet-500/10 text-violet-400 text-[10px] font-bold rounded-full uppercase tracking-wider w-fit">
                  New Feature Update
                </div>
                <h2 className="text-xl font-bold text-white font-display">Isolate subjects instantly with Gemini AI</h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Our advanced deep vision engine analyzes photographic composition to intelligently crop, align, and suggest exposure improvements server-side.
                </p>
              </div>
              <button
                onClick={() => setActiveTab("editor")}
                className="px-6 py-3 bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-lg shadow-violet-600/20 active:scale-95 shrink-0"
              >
                Launch Photo Editor
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ----------------------------------------------------
          REIMAGINE AI STYLE PROMPT MODAL
          ---------------------------------------------------- */}
      {showReimagineModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] backdrop-blur-sm p-4 font-sans">
          <div className="bg-[#0f1426] border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-5 shadow-2xl relative overflow-hidden">
            <div className="absolute -top-12 -left-12 w-24 h-24 bg-violet-600/15 rounded-full blur-xl pointer-events-none" />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-violet-400" />
                <h3 className="font-bold text-base text-white">Reimagine Photo Style</h3>
              </div>
              <button
                onClick={() => setShowReimagineModal(false)}
                className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Describe how you want Gemini to reimagining this photo. It will perform stylistic analysis, suggest professional adjustments, and apply custom artistic filters!
            </p>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Your Prompt</label>
              <textarea
                value={reimaginePrompt}
                onChange={(e) => setReimaginePrompt(e.target.value)}
                placeholder="E.g., 'Make it look like a moody cyberpunk neon scene at midnight', 'Watercolor sunset', '1970s analog retro warm polaroid'..."
                className="w-full h-24 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-violet-500 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-violet-500/20 transition-all resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                onClick={() => setShowReimagineModal(false)}
                className="px-4 py-2 border border-slate-800 hover:border-slate-700 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleAIReimagineSubmit}
                disabled={!reimaginePrompt}
                className="px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-violet-500/10 cursor-pointer active:scale-95"
              >
                Generate Style
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------------------------------------------
          SHARE MODAL (FALLBACK)
          ---------------------------------------------------- */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] backdrop-blur-sm p-4 font-sans">
          <div className="bg-[#0f1426] border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-5 shadow-2xl relative overflow-hidden">
            <div className="absolute -top-12 -left-12 w-24 h-24 bg-violet-600/15 rounded-full blur-xl pointer-events-none" />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-violet-400" />
                <h3 className="font-bold text-base text-white">Share Your Creation</h3>
              </div>
              <button
                onClick={() => setShowShareModal(false)}
                className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Share your stunning photo directly with your friends and community online!
            </p>

            <div className="grid grid-cols-4 gap-3 pt-2">
              {[
                { icon: Twitter, name: "X (Twitter)", color: "hover:bg-blue-500/20 hover:text-blue-400" },
                { icon: Facebook, name: "Facebook", color: "hover:bg-blue-600/20 hover:text-blue-500" },
                { icon: Globe, name: "Web App", color: "hover:bg-emerald-500/20 hover:text-emerald-400" },
                { icon: Mail, name: "Email", color: "hover:bg-rose-500/20 hover:text-rose-400" },
              ].map((platform) => (
                <button
                  key={platform.name}
                  onClick={() => alert(`Redirecting to ${platform.name}...`)}
                  className={`flex flex-col items-center gap-2 p-3 bg-slate-900 border border-slate-800 rounded-xl transition-all cursor-pointer text-slate-400 ${platform.color}`}
                >
                  <platform.icon className="w-5 h-5" />
                  <span className="text-[10px] font-bold">{platform.name}</span>
                </button>
              ))}
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-800">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Project Link</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value="https://phototoolkit.app/share/p-8x92j"
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2000);
                    }}
                    className="p-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl transition-all cursor-pointer shadow-md shadow-violet-500/20 flex items-center justify-center shrink-0 w-10 h-10"
                  >
                    {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Embed Code</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value='<iframe src="https://phototoolkit.app/embed/p-8x92j"></iframe>'
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      setCopiedEmbed(true);
                      setTimeout(() => setCopiedEmbed(false), 2000);
                    }}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-all cursor-pointer shrink-0 w-10 h-10 flex items-center justify-center"
                  >
                    {copiedEmbed ? <Check className="w-4 h-4" /> : <Code className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowShareModal(false)}
                className="px-4 py-2 border border-slate-800 hover:border-slate-700 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-all cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

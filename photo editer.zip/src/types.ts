export interface Adjustments {
  // Light
  brightness: number;   // -100 to 100 (Default: 0)
  contrast: number;     // -100 to 100 (Default: 0)
  highlights: number;   // -100 to 100 (Default: 0)
  shadows: number;      // -100 to 100 (Default: 0)
  whites: number;       // -100 to 100 (Default: 0)
  blacks: number;       // -100 to 100 (Default: 0)

  // Color
  vibrance: number;     // -100 to 100 (Default: 0)
  saturation: number;   // -100 to 100 (Default: 0)
  temperature: number;  // -100 to 100 (Default: 0)
  tint: number;         // -100 to 100 (Default: 0)

  // Effects
  clarity: number;      // -100 to 100 (Default: 0)
  sharpen: number;      // 0 to 100 (Default: 0)
  dehaze: number;       // -100 to 100 (Default: 0)
  vignette: number;     // 0 to 100 (Default: 0)
}

export interface ImageTransform {
  rotate: number;       // 0, 90, 180, 270
  flipH: boolean;
  flipV: boolean;
  straighten: number;   // -45 to 45
  skewX?: number;       // -30 to 30
  skewY?: number;       // -30 to 30
  perspective?: number; // 0 to 100
}

export interface CropRect {
  x: number;            // Percentage of width 0-100
  y: number;            // Percentage of height 0-100
  width: number;        // Percentage 0-100
  height: number;       // Percentage 0-100
}

export interface Layer {
  id: string;
  type: 'text' | 'rect' | 'circle' | 'arrow' | 'star' | 'image';
  x: number;            // percentage of image width
  y: number;            // percentage of image height
  width: number;        // percentage
  height: number;       // percentage
  color: string;
  text?: string;
  url?: string;
  fontSize?: number;
  rotation?: number;
  adjustments?: Adjustments;
}

export interface ProjectImage {
  id: string;
  name: string;
  url: string;
  originalUrl: string;  // For reset
  mimeType: string;
  width: number;
  height: number;
  adjustments: Adjustments;
  transform: ImageTransform;
  crop: CropRect | null;
  layers: Layer[];
  filter: string;       // name of selected filter preset
  frame?: string;       // premium border frame style
  overlayUrl?: string;  // For double exposure textures
  overlayOpacity?: number; // 0 to 100
  showBokeh?: boolean;  // For Bokeh Overlay
  showNeonGlow?: boolean; // For Cyber Neon Glow
  colorSplashIsolate?: string; // e.g. "red", "blue", "yellow", "green"
  bgTreatment?: 'crop' | 'blur' | 'grayscale' | 'color_fill'; // For AI background remover isolation
  bgTreatmentColor?: string; // Hex color for color_fill backdrop
  bgX?: number;              // Percentage offset for draggable background image in Join mode
  bgY?: number;
  bgWidth?: number;
  bgHeight?: number;
}

export type ToolType =
  | 'crop'
  | 'resize'
  | 'rotate'
  | 'flip'
  | 'straighten'
  | 'perspective'
  | 'adjust'
  | 'filters'
  | 'effects'
  | 'text'
  | 'elements'
  | 'frames'
  | 'clarity'
  | 'enhance'
  | 'bg_remover'
  | 'expand'
  | 'remove_obj'
  | 'reimagine'
  | 'ai_replace'
  | 'blemish'
  | 'skin_smooth'
  | 'teeth_whiten'
  | 'red_eye'
  | 'color_match'
  | 'hues_tones'
  | 'color_splash'
  | 'replace_color'
  | 'double_exposure'
  | 'neon_glow_overlay'
  | 'bokeh_overlay'
  | 'duotone_gen'
  | 'join';

export type CanvasMode = 'select' | 'pan' | 'crop' | 'text' | 'element';

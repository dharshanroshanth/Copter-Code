import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Increase payload size limit to accept base64 image data
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

let aiInstance: GoogleGenAI | null = null;

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error(
      "GEMINI_API_KEY is not configured. Please add your Gemini API Key in the Settings > Secrets menu."
    );
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Robust Server-side Base64 Image Resolver to bypass CORS blocks for third-party URLs (e.g. Unsplash)
async function resolveImageBase64(imageBase64: string, imageUrl?: string): Promise<string> {
  if (imageUrl && imageUrl.startsWith("http")) {
    try {
      console.log(`Server-side fetching imageUrl: ${imageUrl}`);
      const response = await fetch(imageUrl);
      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        const base64 = Buffer.from(arrayBuffer).toString("base64");
        if (base64 && base64.length > 100) {
          console.log(`Successfully fetched and converted ${imageUrl} to base64 (${base64.length} bytes).`);
          return base64;
        }
      } else {
        console.warn(`Server-side fetch for ${imageUrl} returned status: ${response.status}`);
      }
    } catch (e) {
      console.error(`Failed to fetch imageUrl server-side: ${imageUrl}`, e);
    }
  }
  return imageBase64.replace(/^data:image\/\w+;base64,/, "");
}

// ----------------------------------------------------
// API ENDPOINTS
// ----------------------------------------------------

// Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date() });
});

// AI Enhance Route
app.post("/api/enhance", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, imageUrl } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 payload" });
    }

    const ai = getGeminiClient();
    const resolvedData = await resolveImageBase64(imageBase64, imageUrl);

    // Prepare image payload for gemini-3.5-flash
    const imagePart = {
      inlineData: {
        data: resolvedData,
        mimeType: mimeType || "image/jpeg",
      },
    };

    const textPart = {
      text: `You are an expert, professional photo retoucher, structural editor, and colorist.
Analyze this photo and determine the optimal professional light and color adjustments to make it look stunning. 
Also evaluate whether the photo's horizon is tilted or its lines are skewed, and suggest minor structural alignments (straighten angle and skew offsets). Recommend a complementary filter preset that best fits the scene.
Provide slider values (from -100 to 100 for adjustments, and 0 to 100 for sharpen/vignette) and explain your creative reasoning.

Return your response in strict JSON matching the requested schema.
Be bold and precise with your slider values based on the photo's content. E.g., if it's underexposed, boost brightness/whites. If it's warm, decrease temperature. If it's flat, boost contrast and clarity.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: [
            "brightness",
            "contrast",
            "highlights",
            "shadows",
            "whites",
            "blacks",
            "vibrance",
            "saturation",
            "temperature",
            "tint",
            "clarity",
            "sharpen",
            "dehaze",
            "vignette",
            "straighten",
            "skewX",
            "skewY",
            "filterPreset",
            "analysis",
            "tips",
          ],
          properties: {
            brightness: { type: Type.INTEGER, description: "Brightness slider from -100 to 100." },
            contrast: { type: Type.INTEGER, description: "Contrast slider from -100 to 100." },
            highlights: { type: Type.INTEGER, description: "Highlights slider from -100 to 100." },
            shadows: { type: Type.INTEGER, description: "Shadows slider from -100 to 100." },
            whites: { type: Type.INTEGER, description: "Whites slider from -100 to 100." },
            blacks: { type: Type.INTEGER, description: "Blacks slider from -100 to 100." },
            vibrance: { type: Type.INTEGER, description: "Vibrance slider from -100 to 100." },
            saturation: { type: Type.INTEGER, description: "Saturation slider from -100 to 100." },
            temperature: { type: Type.INTEGER, description: "Temperature slider from -100 to 100 (negative is cooler/blue, positive is warmer/amber)." },
            tint: { type: Type.INTEGER, description: "Tint slider from -100 to 100 (negative is greener, positive is magenta)." },
            clarity: { type: Type.INTEGER, description: "Clarity/midtone contrast slider from -100 to 100." },
            sharpen: { type: Type.INTEGER, description: "Sharpening detail slider from 0 to 100." },
            dehaze: { type: Type.INTEGER, description: "Dehaze atmospheric clarity from -100 to 100." },
            vignette: { type: Type.INTEGER, description: "Vignette dark border radius from 0 to 100." },
            straighten: { type: Type.INTEGER, description: "Suggested straighten rotation correction from -15 to 15 degrees if the image is tilted. Return 0 if aligned." },
            skewX: { type: Type.INTEGER, description: "Horizontal perspective skew angle correction from -15 to 15 to balance lines. Return 0 if straight." },
            skewY: { type: Type.INTEGER, description: "Vertical perspective skew angle correction from -15 to 15 to balance lines. Return 0 if straight." },
            filterPreset: { type: Type.STRING, description: "Recommended preset filter matching the mood. Must be one of: 'normal', 'warm', 'cool', 'mono', 'sepia', 'vintage'." },
            analysis: { type: Type.STRING, description: "A detailed 2-3 sentence artistic and professional analysis of the original photo and the edits made." },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "2-3 high-level photographic/composition tips to help the user capture similar scenes better in the future.",
            },
          },
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Enhance error:", error);
    res.status(500).json({
      error: error.message || "Failed to analyze image with Gemini AI",
    });
  }
});

// AI BG Remover - returns subject analysis, key subject bounding box, and transparent mask assistance
app.post("/api/bg-remover", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, imageUrl } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 payload" });
    }

    const ai = getGeminiClient();
    const resolvedData = await resolveImageBase64(imageBase64, imageUrl);

    const imagePart = {
      inlineData: {
        data: resolvedData,
        mimeType: mimeType || "image/jpeg",
      },
    };

    const textPart = {
      text: `Identify the main subject in this photograph. Help us isolate it from the background.
Describe the main focal subject in detail (including color, shape) and identify what the background is.
Also, define a standardized bounding box [ymin, xmin, ymax, xmax] of the main subject where 0 is top/left and 1000 is bottom/right.
In addition, suggest a professional complementary hex color code (e.g. '#A1B2C3') that would make an excellent, elegant studio backdrop fill for this subject.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["subjectName", "subjectDescription", "backgroundDescription", "boundingBox", "bgTreatmentColor"],
          properties: {
            subjectName: { type: Type.STRING, description: "Name of the main subject (e.g. 'Wooden boat', 'Mountain peak')." },
            subjectDescription: { type: Type.STRING, description: "Detailed description of the subject." },
            backgroundDescription: { type: Type.STRING, description: "Detailed description of what constitutes the background." },
            boundingBox: {
              type: Type.ARRAY,
              items: { type: Type.INTEGER },
              description: "A 4-element integer array [ymin, xmin, ymax, xmax] from 0 to 1000 representing the coordinate boundaries of the primary subject.",
            },
            bgTreatmentColor: {
              type: Type.STRING,
              description: "A gorgeous, elegant complementary hex color code (like '#E2E8F0') to fill the background behind the subject if solid color treatment is chosen.",
            },
          },
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("BG Remover error:", error);
    res.status(500).json({
      error: error.message || "Failed to analyze background removal with Gemini AI",
    });
  }
});

// AI Reimagine / AI Replace
app.post("/api/reimagine", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, prompt, imageUrl } = req.body;
    if (!imageBase64 || !prompt) {
      return res.status(400).json({ error: "Missing imageBase64 or prompt payload" });
    }

    const ai = getGeminiClient();
    const resolvedData = await resolveImageBase64(imageBase64, imageUrl);

    const imagePart = {
      inlineData: {
        data: resolvedData,
        mimeType: mimeType || "image/jpeg",
      },
    };

    const textPart = {
      text: `The user wants to reimagine this photo or replace elements of it based on this prompt: "${prompt}".
As an AI photo artistic director, describe step-by-step how we should modify this photo's style, colors, and textures to achieve this artistic result.
Provide specific styling attributes we should inject: a recommended color palette (3 hex colors), a target photographic style (e.g., 'surrealist', 'cyberpunk', 'vintage analog', 'watercolor painting'), and specific adjustment adjustments to apply on canvas.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["artisticConcept", "styleName", "colorPalette", "recommendedAdjustments"],
          properties: {
            artisticConcept: { type: Type.STRING, description: "Detailed narrative describing how this image is reimagined according to the prompt." },
            styleName: { type: Type.STRING, description: "The name of the visual style (e.g. 'Cyberpunk Synthwave', 'Retro Polaroid')." },
            colorPalette: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3 HEX color values representing the reimagined palette.",
            },
            recommendedAdjustments: {
              type: Type.OBJECT,
              required: ["brightness", "contrast", "saturation", "temperature"],
              properties: {
                brightness: { type: Type.INTEGER },
                contrast: { type: Type.INTEGER },
                saturation: { type: Type.INTEGER },
                temperature: { type: Type.INTEGER },
              },
            },
          },
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Reimagine error:", error);
    res.status(500).json({
      error: error.message || "Failed to reimagine photo with Gemini AI",
    });
  }
});

// AI Magic Eraser - erases unwanted objects based on mask strokes
app.post("/api/magic-erase", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, strokesCount, imageUrl, healMode, denoiseFactor } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 payload" });
    }

    const ai = getGeminiClient();
    const resolvedData = await resolveImageBase64(imageBase64, imageUrl);

    const imagePart = {
      inlineData: {
        data: resolvedData,
        mimeType: mimeType || "image/jpeg",
      },
    };

    const textPart = {
      text: `The user has used the Magic Eraser tool to brush over ${strokesCount || 1} regions of this image to erase unwanted elements, specifying heal mode "${healMode || "Content-Aware (Fine)"}" and denoise blend of ${denoiseFactor ?? 45}%.
      Analyze the photograph's overall composition. Predict what objects or distractions were most likely in the brushed zones, and explain how the surrounding colors, lighting, and textures should seamlessly merge/heal to fill the empty space under this specific heal configuration.
      Return your response in strict JSON matching the schema.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["erasedElementsPredicted", "healingDescription", "recommendedAdjustments"],
          properties: {
            erasedElementsPredicted: { type: Type.STRING, description: "A brief phrase naming the predicted erased items (e.g. 'stray leaves', 'background pedestrians', 'lens flare')." },
            healingDescription: { type: Type.STRING, description: "A detailed 2-sentence description of how adjacent textures, light gradients, and patterns merge to heal the zone." },
            recommendedAdjustments: {
              type: Type.OBJECT,
              required: ["contrast", "clarity", "vignette"],
              properties: {
                contrast: { type: Type.INTEGER, description: "Suggested contrast tweak to blend the healed region (-20 to 20)." },
                clarity: { type: Type.INTEGER, description: "Suggested clarity tweak to soften or sharpen the healed area (-30 to 30)." },
                vignette: { type: Type.INTEGER, description: "Suggested vignette tweak to draw attention away from the edges (0 to 30)." },
              },
            },
          },
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Magic Erase error:", error);
    res.status(500).json({
      error: error.message || "Failed to process Magic Eraser with Gemini AI",
    });
  }
});

// AI Replace - replaces a masked element with a specified object or texture
app.post("/api/replace-object", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, prompt, imageUrl, designTheme } = req.body;
    if (!imageBase64 || !prompt) {
      return res.status(400).json({ error: "Missing imageBase64 or replacement prompt" });
    }

    const ai = getGeminiClient();
    const resolvedData = await resolveImageBase64(imageBase64, imageUrl);

    const imagePart = {
      inlineData: {
        data: resolvedData,
        mimeType: mimeType || "image/jpeg",
      },
    };

    const textPart = {
      text: `The user wants to replace a highlighted portion of this image with this target element: "${prompt}", using a design tag theme of "${designTheme || "Standard"}".
      Analyze the photograph's current lighting angles, shadows, colors, and perspective. Describe how we should seamlessly composite "${prompt}" into the scene.
      Then, map this replacement into a beautiful stylized vector/text layer representation to place on the canvas matching the "${designTheme || "Standard"}" theme guidelines, along with recommended photo adjustments.
      Return your response in strict JSON matching the schema.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["compositionDetails", "layerType", "layerColor", "layerText", "recommendedAdjustments"],
          properties: {
            compositionDetails: { type: Type.STRING, description: "A detailed description of how the new object integrates with the scene's ambient lighting and shadows." },
            layerType: { type: Type.STRING, description: "The type of vector layer that fits best as a stylized tag representation (must be one of: 'rect', 'circle', 'star', 'arrow', 'text')." },
            layerColor: { type: Type.STRING, description: "A beautiful, highly-contrasting hex color picked from the scene to style the replacement layer." },
            layerText: { type: Type.STRING, description: "A professional label or caption representing the newly inserted element (e.g. '✨ Golden Trophy', '🌙 Vintage Crescent Moon')." },
            recommendedAdjustments: {
              type: Type.OBJECT,
              required: ["brightness", "contrast", "saturation", "temperature"],
              properties: {
                brightness: { type: Type.INTEGER, description: "Adjustment to brightness to integrate the object (-30 to 30)." },
                contrast: { type: Type.INTEGER, description: "Adjustment to contrast to match depth (-30 to 30)." },
                saturation: { type: Type.INTEGER, description: "Adjustment to saturation to blend colors (-30 to 30)." },
                temperature: { type: Type.INTEGER, description: "Adjustment to temperature to match warm/cool lighting (-30 to 30)." },
              },
            },
          },
        },
      },
    });

    const resultText = response.text || "{}";
    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("AI Replace error:", error);
    res.status(500).json({
      error: error.message || "Failed to execute AI Replace with Gemini AI",
    });
  }
});

// ----------------------------------------------------
// DEV / PROD SERVER BOOTSTRAP
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development mode: Run Vite middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware loaded.");
  } else {
    // Production mode: Serve compiled bundle
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static files from dist/ directory.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT} in ${process.env.NODE_ENV || "development"} mode.`);
  });
}

startServer();
